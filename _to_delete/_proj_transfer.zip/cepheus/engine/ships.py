"""ships.py -- Cepheus Engine starships: standard designs, travel & economics.

Combines three things from SRD book 2:
  * Standard ship reference stats (engine/data/ships.json, parsed from the
    Common Vessels chapter by scripts/parse_ships.py).
  * Interstellar travel mechanics: jump time, the jump success roll.
  * Starship operations economics: passages, freight, mail, charters, crew
    salaries, fuel, life support, port fees, maintenance and mortgage, plus the
    Available Freight & Passengers table by starport class.

All constants are taken straight from the SRD text.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional

from . import dice

_DATA = os.path.join(os.path.dirname(__file__), "data", "ships.json")

# ---- economics constants (SRD Starship Expenses / Revenue) -----------------
PASSAGE_PRICE = {"high": 10000, "middle": 8000, "low": 1000}     # Cr, per jump
FREIGHT_PER_TON = 1000                 # Cr per ton, paid on delivery
MAIL_FEE = 25000                       # Cr per trip (needs 5t hold, armed+gunner)
FUEL_REFINED = 500                     # Cr/ton at class A/B starport
FUEL_UNREFINED = 100                   # Cr/ton at class A/B/C starport
FUEL_FERRY_SURCHARGE = 100             # Cr/ton if ferried out to the ship
LIFE_SUPPORT_STATEROOM = 2000          # Cr/stateroom/month
LIFE_SUPPORT_LOWBERTH = 100            # Cr/low berth/month
PORT_FEE_BASE = 100                    # Cr for first 6 days, then Cr100/day

SALARIES = {                           # Cr/month
    "master": 6000, "pilot": 6000, "navigator": 5000, "engineer": 4000,
    "steward": 3000, "purser": 3000, "medic": 2000, "gunner": 1000,
    "other": 1000,
}

# Charter (per 2-week block).
CHARTER_PER_CARGO_TON = 900
CHARTER_PER_HIGH_BERTH = 9000
CHARTER_PER_LOW_BERTH = 900

# Available Freight & Passengers by starport class (dice expressions, SRD).
AVAILABLE = {
    "A": {"freight": "3D6×10", "high": "3D6",   "mid": "3D6",   "low": "3D6×3"},
    "B": {"freight": "3D6×5",  "high": "2D6",   "mid": "3D6",   "low": "3D6×3"},
    "C": {"freight": "3D6×2",  "high": "1D6-1", "mid": "2D6",   "low": "3D6"},
    "D": {"freight": "3D6",    "high": "0",     "mid": "1D6-1", "low": "2D6"},
    "E": {"freight": "1D6",    "high": "0",     "mid": "1D3-1", "low": "1D6-1"},
    "X": {"freight": "0",      "high": "0",     "mid": "0",     "low": "0"},
}


def roll_expr(expr: str) -> int:
    """Roll a dice expression like '3D6×10', '1D6-1', '1D3-1', '0'."""
    expr = expr.replace("×", "x").replace("X", "x").strip()
    if expr == "0":
        return 0
    m = re.match(r"(\d+)[dD](\d+)(?:\s*x\s*(\d+))?(?:\s*([+-]\d+))?", expr)
    if not m:
        return 0
    n, sides = int(m.group(1)), int(m.group(2))
    mult = int(m.group(3)) if m.group(3) else 1
    mod = int(m.group(4)) if m.group(4) else 0
    return max(0, dice.roll(n, sides) * mult + mod)


# ---- ship reference data ---------------------------------------------------

@dataclass
class Ship:
    name: str
    tl: Optional[int]
    tonnage: Optional[int]
    jump: Optional[int]            # None = no jump drive (in-system craft)
    maneuver_g: Optional[int]
    cargo_tons: Optional[int]
    staterooms: Optional[int]
    low_berths: Optional[int]
    crew: Optional[int]
    cost_mcr: Optional[float]
    high_passengers: Optional[int]
    low_passengers: Optional[int]
    description: str = ""

    @property
    def cost_cr(self) -> Optional[int]:
        return int(self.cost_mcr * 1_000_000) if self.cost_mcr else None

    @property
    def jump_capable(self) -> bool:
        return bool(self.jump)

    def monthly_mortgage(self) -> int:
        """Standard mortgage: 1/240th of cash price per month (SRD)."""
        return round(self.cost_cr / 240) if self.cost_cr else 0

    def monthly_maintenance(self) -> int:
        """0.1% of ship cost per year, paid monthly (SRD)."""
        return round(self.cost_cr * 0.001 / 12) if self.cost_cr else 0

    def __str__(self):
        j = "J{}".format(self.jump) if self.jump else "no jump"
        return "{} (TL{} {}t {} {}G, cargo {}t, MCr{})".format(
            self.name, self.tl, self.tonnage, j, self.maneuver_g,
            self.cargo_tons, self.cost_mcr)


def _load() -> Dict[str, Ship]:
    out = {}
    for s in json.load(open(_DATA, encoding="utf-8")):
        out[s["name"]] = Ship(
            name=s["name"], tl=s["tl"], tonnage=s["tonnage"], jump=s["jump"],
            maneuver_g=s["maneuver_g"], cargo_tons=s["cargo_tons"],
            staterooms=s["staterooms"], low_berths=s["low_berths"],
            crew=s["crew"], cost_mcr=s["cost_mcr"],
            high_passengers=s["high_passengers"],
            low_passengers=s["low_passengers"], description=s["description"])
    return out


SHIPS: Dict[str, Ship] = _load()


def ship(name: str) -> Ship:
    if name not in SHIPS:
        raise KeyError("Unknown ship: {!r}".format(name))
    return SHIPS[name]


def ship_names() -> List[str]:
    return list(SHIPS)


# ---- travel mechanics ------------------------------------------------------

def jump_time_hours() -> int:
    """A jump takes 148 + 6D6 hours (~1 week) (SRD)."""
    return 148 + dice.roll(6)


def jump_success(engineering_effect: int = 0, plot_months_old: int = 0,
                 drive_hits: int = 0, unrefined_fuel: bool = False,
                 within_limit: bool = False) -> Dict:
    """Roll the Jump Success roll (SRD). Returns dict with result and outcome.

    <=0 misjump, 8+ accurate, otherwise inaccurate.
    """
    natural = dice.roll(2)
    result = (natural + engineering_effect - plot_months_old
              - 2 * drive_hits - (2 if unrefined_fuel else 0)
              - (8 if within_limit else 0))
    if result <= 0:
        outcome = "misjump"
    elif result >= 8:
        outcome = "accurate"
    else:
        outcome = "inaccurate"
    return {"natural": natural, "result": result, "outcome": outcome}


# ---- operations economics --------------------------------------------------

def roll_available(starport_class: str) -> Dict[str, int]:
    """Roll the Available Freight & Passengers table for a starport class."""
    spec = AVAILABLE.get(starport_class.upper(), AVAILABLE["X"])
    return {k: roll_expr(v) for k, v in spec.items()}


def crew_salaries(crew: Dict[str, int]) -> int:
    """Monthly salary total for a crew dict like {'pilot':1,'engineer':2}."""
    total = 0
    for role, n in crew.items():
        total += SALARIES.get(role, SALARIES["other"]) * n
    return total


def fuel_cost(tons: int, refined: bool = True, ferried: bool = False) -> int:
    base = FUEL_REFINED if refined else FUEL_UNREFINED
    if ferried:
        base += FUEL_FERRY_SURCHARGE
    return base * tons


def passenger_revenue(high: int = 0, middle: int = 0, low: int = 0) -> int:
    return (high * PASSAGE_PRICE["high"] + middle * PASSAGE_PRICE["middle"]
            + low * PASSAGE_PRICE["low"])


def freight_revenue(tons: int) -> int:
    return tons * FREIGHT_PER_TON


def life_support_monthly(staterooms: int, low_berths: int = 0) -> int:
    return (staterooms * LIFE_SUPPORT_STATEROOM
            + low_berths * LIFE_SUPPORT_LOWBERTH)


@dataclass
class VoyageResult:
    revenue: int
    expenses: int
    breakdown: Dict[str, int]

    @property
    def profit(self) -> int:
        return self.revenue - self.expenses

    def __str__(self):
        lines = ["Voyage economics:"]
        for k, v in self.breakdown.items():
            lines.append("  {:22} Cr{:>12,}".format(k, v))
        lines.append("  {:22} Cr{:>12,}".format("REVENUE", self.revenue))
        lines.append("  {:22} Cr{:>12,}".format("EXPENSES", self.expenses))
        lines.append("  {:22} Cr{:>12,}".format("PROFIT", self.profit))
        return "\n".join(lines)


def voyage_economics(s: Ship, high: int = 0, middle: int = 0, low: int = 0,
                     freight_tons: int = 0, mail: bool = False,
                     fuel_tons: Optional[int] = None, refined: bool = True,
                     crew: Optional[Dict[str, int]] = None,
                     include_mortgage: bool = True) -> VoyageResult:
    """Rough one-jump (one month) profit/loss for a ship (SRD economics).

    Revenue: passages + freight + optional mail. Expenses: crew salaries (1mo),
    fuel, life support (1mo), maintenance (1mo), and optional mortgage (1mo).
    """
    rev_pax = passenger_revenue(high, middle, low)
    rev_freight = freight_revenue(freight_tons)
    rev_mail = MAIL_FEE if mail else 0
    revenue = rev_pax + rev_freight + rev_mail

    if fuel_tons is None:
        # Assume a full jump's fuel ~= 10% of hull per jump number (rough).
        fuel_tons = int((s.tonnage or 0) * 0.1 * (s.jump or 1))
    exp_fuel = fuel_cost(fuel_tons, refined=refined)
    exp_salary = crew_salaries(crew) if crew else 0
    exp_life = life_support_monthly(s.staterooms or 0, s.low_berths or 0)
    exp_maint = s.monthly_maintenance()
    exp_mort = s.monthly_mortgage() if include_mortgage else 0
    expenses = exp_fuel + exp_salary + exp_life + exp_maint + exp_mort

    breakdown = {
        "passengers": rev_pax, "freight": rev_freight, "mail": rev_mail,
        "fuel": -exp_fuel, "salaries": -exp_salary, "life support": -exp_life,
        "maintenance": -exp_maint, "mortgage": -exp_mort,
    }
    return VoyageResult(revenue, expenses, breakdown)
