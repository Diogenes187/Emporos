"""equipment.py -- weapons and armor for the Cepheus Engine.

Loads the data parsed from the SRD (engine/data/weapons.json, armor.json) into
Weapon and Armor objects used by the combat module. Numbers come straight from
the SRD equipment chapter via scripts/parse_equipment.py.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

_WDATA = os.path.join(os.path.dirname(__file__), "data", "weapons.json")
_ADATA = os.path.join(os.path.dirname(__file__), "data", "armor.json")

# Weapon classes that are melee (everything else is ranged for difficulty).
MELEE_CLASSES = {"close quarters", "extended reach"}


@dataclass
class Weapon:
    name: str
    category: str                 # melee | ranged | grenade | heavy
    classes: List[str]            # e.g. ['pistol'] or ['close quarters','thrown']
    damage_dice: Optional[int]    # number of D6 (None for "see description")
    damage_raw: str
    tl: str = ""
    cost: Optional[int] = None
    weight_kg: Optional[float] = None
    type: Optional[str] = None    # P, S, B, E, P/S ...
    rof: Optional[str] = None
    recoil: Optional[str] = None
    law_level: Optional[str] = None

    @property
    def is_melee(self) -> bool:
        return any(c in MELEE_CLASSES for c in self.classes)

    @property
    def is_thrown(self) -> bool:
        return "thrown" in self.classes

    def primary_class(self) -> str:
        return self.classes[0] if self.classes else "rifle"

    def __str__(self) -> str:
        return "{} ({}, {} dmg)".format(self.name, self.primary_class(),
                                        self.damage_raw)


@dataclass
class Armor:
    name: str
    ar: int                       # primary armor rating (damage reduction)
    ar_raw: str
    tl: str = ""
    cost: Optional[int] = None
    weight_kg: Optional[float] = None
    skill_required: Optional[str] = None

    def __str__(self) -> str:
        return "{} (AR {})".format(self.name, self.ar_raw)


def _ar_primary(ar_raw: str) -> int:
    m = re.match(r"^\s*(\d+)", ar_raw or "")
    return int(m.group(1)) if m else 0


def _load() -> None:
    global WEAPONS, ARMORS
    WEAPONS = {}
    for w in json.load(open(_WDATA, encoding="utf-8")):
        WEAPONS[w["name"]] = Weapon(
            name=w["name"], category=w["category"], classes=w["classes"],
            damage_dice=w["damage"]["dice"], damage_raw=w["damage"]["raw"],
            tl=w["tl"], cost=w["cost"], weight_kg=w["weight_kg"],
            type=w["type"], rof=w["rof"], recoil=w["recoil"],
            law_level=w["law_level"],
        )
    ARMORS = {}
    for a in json.load(open(_ADATA, encoding="utf-8")):
        ARMORS[a["name"]] = Armor(
            name=a["name"], ar=_ar_primary(a["ar_raw"]), ar_raw=a["ar_raw"],
            tl=a["tl"], cost=a["cost"], weight_kg=a["weight_kg"],
            skill_required=(None if a["skill_required"] in (None, "—")
                            else a["skill_required"]),
        )


WEAPONS: Dict[str, Weapon] = {}
ARMORS: Dict[str, Armor] = {}
_load()

# Convenient default unarmed attack.
UNARMED = WEAPONS.get("Unarmed Strike")


def weapon(name: str) -> Weapon:
    if name not in WEAPONS:
        raise KeyError("Unknown weapon: {!r}".format(name))
    return WEAPONS[name]


def armor(name: str) -> Armor:
    if name not in ARMORS:
        raise KeyError("Unknown armor: {!r}".format(name))
    return ARMORS[name]


def weapon_names() -> List[str]:
    return list(WEAPONS)


def armor_names() -> List[str]:
    return list(ARMORS)
