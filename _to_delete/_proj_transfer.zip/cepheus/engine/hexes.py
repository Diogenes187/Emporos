"""hexes.py -- THE hex geometry for the whole engine. One implementation.

Traveller sector maps number hexes 'CCRR' (column, row) on a flat-top grid
where EVEN columns are drawn half a hex LOWER than odd ones. In offset-coord
terms that is 'even-q'. Get this wrong by one convention and most pairs still
agree -- it is only the diagonals that break, which is exactly how a wrong
offset hides for months and then refuses a jump the map shows as adjacent.

Everything that measures the sector imports from here: the map renderer, the
jump validator, the bearing text, the world dossier. If this file is right,
they cannot disagree with each other.

  distance(a, b)  -> parsecs between two 'CCRR' hexes
  bearing(a, b)   -> '1 parsec rimward', '2 parsecs coreward-spinward', ...
  neighbours(h)   -> the six adjacent hexes
  within(h, n)    -> every hex within n parsecs (inclusive), nearest first

Compass: LOWER column = spinward, HIGHER = trailing.
         LOWER row    = coreward, HIGHER = rimward.
"""
from __future__ import annotations

from typing import List, Optional, Tuple


def parse(h) -> Optional[Tuple[int, int]]:
    """'1914' -> (19, 14). None if it isn't a hex."""
    s = str(h or "").strip()
    if len(s) < 4 or not s[:4].isdigit():
        return None
    return int(s[:2]), int(s[2:4])


def to_cube(col: int, row: int) -> Tuple[int, int, int]:
    """even-q offset -> cube. Matches how the map is DRAWN (even columns are
    shifted down half a hex in render.svgmap._center)."""
    x = col
    z = row - (col + (col & 1)) // 2
    return x, -x - z, z


def distance(a, b) -> Optional[int]:
    """Parsecs between two hexes, or None if either is unparseable."""
    pa, pb = parse(a), parse(b)
    if not pa or not pb:
        return None
    ax, ay, az = to_cube(*pa)
    bx, by, bz = to_cube(*pb)
    return max(abs(ax - bx), abs(ay - by), abs(az - bz))


def bearing(from_hex, to_hex) -> str:
    """Plain-language direction and distance, e.g. '2 parsecs rimward-trailing'."""
    pa, pb = parse(from_hex), parse(to_hex)
    if not pa or not pb:
        return "unknown bearing"
    (c1, r1), (c2, r2) = pa, pb
    if (c1, r1) == (c2, r2):
        return "the same hex"
    parts = []
    if r2 < r1:
        parts.append("coreward")
    elif r2 > r1:
        parts.append("rimward")
    if c2 < c1:
        parts.append("spinward")
    elif c2 > c1:
        parts.append("trailing")
    d = distance(from_hex, to_hex)
    return "{} parsec{} {}".format(d, "" if d == 1 else "s", "-".join(parts))


def neighbours(h) -> List[str]:
    """The six hexes adjacent to this one (off-grid ones included; callers
    filter by what actually exists in their sector)."""
    p = parse(h)
    if not p:
        return []
    col, row = p
    down = 1 if col % 2 == 0 else 0        # even columns sit half a hex lower
    out = [(col, row - 1), (col, row + 1),
           (col - 1, row - 1 + down), (col - 1, row + down),
           (col + 1, row - 1 + down), (col + 1, row + down)]
    return ["{:02d}{:02d}".format(c, r) for c, r in out if c > 0 and r > 0]


def within(h, n: int) -> List[str]:
    """Every hex within n parsecs of h (excluding h), nearest first."""
    p = parse(h)
    if not p or n < 1:
        return []
    col, row = p
    found = []
    for c in range(max(1, col - n - 1), col + n + 2):
        for r in range(max(1, row - n - 1), row + n + 2):
            t = "{:02d}{:02d}".format(c, r)
            d = distance(h, t)
            if d is not None and 0 < d <= n:
                found.append((d, t))
    found.sort()
    return [t for _, t in found]
