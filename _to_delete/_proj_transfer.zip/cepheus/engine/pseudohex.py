"""pseudohex.py -- convert integers to/from Traveller pseudo-hexadecimal.

Cepheus/Traveller encode values 0-33 as a single character so a whole UWP or
UPP fits in a compact string. The sequence is the digits 0-9 followed by the
uppercase letters, SKIPPING 'I' and 'O' (to avoid confusion with 1 and 0):

    0123456789 ABCDEFGH JKLMN PQRSTUVWXYZ

So 10 -> 'A', 17 -> 'H', 18 -> 'J', 22 -> 'N', 23 -> 'P', ... 33 -> 'Z'.

Adapted from the orffen Cepheus toolbox (reference/toolbox/pseudohex.py).
"""

from __future__ import annotations

_PSEUDOHEX = (
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "A", "B", "C", "D", "E", "F", "G", "H",
    "J", "K", "L", "M", "N",
    "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
)


def to_pseudohex(value: int) -> str:
    """Convert an int (0..33) to its single pseudo-hex character."""
    if not 0 <= value < len(_PSEUDOHEX):
        raise ValueError(
            "Value {} out of pseudo-hex range 0..{}".format(
                value, len(_PSEUDOHEX) - 1
            )
        )
    return _PSEUDOHEX[value]


def from_pseudohex(value: str) -> int:
    """Convert a single pseudo-hex character back to its int value."""
    try:
        return _PSEUDOHEX.index(value.upper())
    except ValueError:
        raise ValueError("Not a pseudo-hex character: {!r}".format(value))
