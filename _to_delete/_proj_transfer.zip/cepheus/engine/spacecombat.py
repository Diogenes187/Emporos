"""spacecombat.py -- Cepheus Engine ship-to-ship (space) combat.

Implements the SRD space-combat chapter (book 2): range bands and the weapon
range-difficulty table, initiative, gunnery attacks (built on the 2D6 task
system), the damage table, armor, and the hit-location tables with Hull /
Structure / Armor and system damage.

Ship damage capacity (SRD): Hull = tonnage // 50, Structure = max(tonnage // 50, 1).
A ship at Structure 0 is destroyed; at Hull 0, further hits go internal.

NOTE: the SRD turret table omits Beam Laser ship-scale damage, but its personal-
scale entry ("Beam Laser 1D6x50") implies a 1D6 base, so BEAM_LASER_DAMAGE_DICE
defaults to 1. Beam Laser also has no range fall-off (it fires at every band).
Pulse Laser, Particle Beam and missiles have explicit SRD damage.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from . import dice
from . import tasks
from .tasks import Difficulty


class Range(Enum):
    ADJACENT = "Adjacent"
    CLOSE = "Close"
    SHORT = "Short"
    MEDIUM = "Medium"
    LONG = "Long"
    VERY_LONG = "Very Long"
    DISTANT = "Distant"


_D = Difficulty
# Weapon range-difficulty table (SRD). Missing entry = cannot fire at that range.
RANGE_DIFFICULTY: Dict[str, Dict[Range, Difficulty]] = {
    "Pulse Laser": {Range.ADJACENT: _D.DIFFICULT, Range.CLOSE: _D.DIFFICULT,
                    Range.SHORT: _D.AVERAGE, Range.MEDIUM: _D.DIFFICULT,
                    Range.LONG: _D.DIFFICULT, Range.VERY_LONG: _D.VERY_DIFFICULT},
    "Beam Laser": {Range.ADJACENT: _D.DIFFICULT, Range.CLOSE: _D.DIFFICULT,
                   Range.SHORT: _D.DIFFICULT, Range.MEDIUM: _D.AVERAGE,
                   Range.LONG: _D.DIFFICULT, Range.VERY_LONG: _D.DIFFICULT,
                   Range.DISTANT: _D.DIFFICULT},
    "Particle Beam": {Range.ADJACENT: _D.VERY_DIFFICULT, Range.CLOSE: _D.DIFFICULT,
                      Range.SHORT: _D.DIFFICULT, Range.MEDIUM: _D.DIFFICULT,
                      Range.LONG: _D.AVERAGE, Range.VERY_LONG: _D.DIFFICULT,
                      Range.DISTANT: _D.DIFFICULT},
    "Fusion Gun": {Range.ADJACENT: _D.DIFFICULT, Range.CLOSE: _D.DIFFICULT,
                   Range.SHORT: _D.DIFFICULT, Range.MEDIUM: _D.AVERAGE,
                   Range.LONG: _D.DIFFICULT, Range.VERY_LONG: _D.DIFFICULT,
                   Range.DISTANT: _D.DIFFICULT},
    "Meson Gun": {Range.ADJACENT: _D.VERY_DIFFICULT, Range.CLOSE: _D.VERY_DIFFICULT,
                  Range.SHORT: _D.DIFFICULT, Range.MEDIUM: _D.DIFFICULT,
                  Range.LONG: _D.AVERAGE, Range.VERY_LONG: _D.DIFFICULT,
                  Range.DISTANT: _D.DIFFICULT},
    "Sandcaster": {Range.ADJACENT: _D.SIMPLE, Range.CLOSE: _D.AVERAGE,
                   Range.SHORT: _D.DIFFICULT},   # 'Routine' -> SIMPLE? see below
}
# SRD Sandcaster Adjacent is 'Routine' which is ROUTINE (+2), not Simple.
RANGE_DIFFICULTY["Sandcaster"][Range.ADJACENT] = _D.ROUTINE

# The SRD turret table omits Beam Laser ship-scale damage, but its personal-scale
# entry is "Beam Laser 1D6x50", implying a 1D6 ship-scale base -- so we use 1D6.
# (Beam Laser also has no range fall-off; see RANGE_DIFFICULTY. House-rule extras
# such as a flat accuracy bonus or "sustained damage" criticals are NOT SRD and
# are intentionally not applied here.)
BEAM_LASER_DAMAGE_DICE: Optional[int] = 1


@dataclass
class Weapon:
    name: str
    damage_dice: Optional[int]    # number of D6 (None = unspecified/special)
    attack_dm: int = 0            # e.g. Pulse Laser -2
    mount: str = "turret"         # turret | bay
    radiation: bool = False
    ignores_armor: bool = False   # meson
    note: str = ""

    def damage_value(self) -> Optional[int]:
        if self.name == "Beam Laser" and self.damage_dice is None:
            return BEAM_LASER_DAMAGE_DICE
        return self.damage_dice


# SRD turret + bay weapon stats (damage in D6).
WEAPONS: Dict[str, Weapon] = {
    "Pulse Laser": Weapon("Pulse Laser", 2, attack_dm=-2,
                          note="inaccurate: DM-2 to attack"),
    "Beam Laser": Weapon("Beam Laser", None,
                         note="1D6 ship-scale (inferred from SRD personal-scale "
                              "1D6x50); accurate, no range fall-off"),
    "Particle Beam": Weapon("Particle Beam", 3, radiation=True),
    # Bay weapons:
    "Particle Beam Bay": Weapon("Particle Beam Bay", 6, mount="bay", radiation=True),
    "Meson Gun": Weapon("Meson Gun", 5, mount="bay", radiation=True,
                        ignores_armor=True),
    "Fusion Gun": Weapon("Fusion Gun", 5, mount="bay"),
}

# Missiles (SRD): fired from a Missile Rack; damage in D6.
MISSILES = {
    "Standard": {"dice": 1, "radiation": False},
    "Smart": {"dice": 1, "radiation": False},
    "Nuclear": {"dice": 2, "radiation": True},
}


def damage_to_hits(dmg: int) -> List[int]:
    """Convert post-armor damage to a list of hit magnitudes (SRD Damage table).

    Each element is the number of points applied to one rolled hit location:
    1 = Single Hit, 2 = Double Hit, 3 = Triple Hit.
    """
    if dmg <= 0:
        return []
    table = [
        (4, [1]), (8, [1, 1]), (12, [2]), (16, [1, 1, 1]), (20, [1, 1, 2]),
        (24, [2, 2]), (28, [3]), (32, [3, 1]), (36, [3, 2]), (40, [3, 2, 1]),
        (44, [3, 3]),
    ]
    for hi, hits in table:
        if dmg <= hi:
            return list(hits)
    # Beyond 44: base [3,3] then +1 Single per extra 3 points (SRD extension).
    extra = dmg - 44
    hits = [3, 3] + [1] * (extra // 3)
    return hits


# Hit-location tables (2D6) (SRD Space Combat Hit Location).
HIT_LOCATION_EXTERNAL = {
    2: "Hull", 3: "Sensors", 4: "M-Drive", 5: "Turret", 6: "Hull",
    7: "Armor", 8: "Hull", 9: "Fuel", 10: "M-Drive", 11: "Sensors", 12: "Hull",
}
HIT_LOCATION_INTERNAL = {
    2: "Structure", 3: "Power Plant", 4: "J-Drive", 5: "Bay", 6: "Structure",
    7: "Crew", 8: "Structure", 9: "Hold", 10: "J-Drive", 11: "Power Plant",
    12: "Bridge",
}
HIT_LOCATION_SMALLCRAFT = {
    2: "Hull", 3: "Power Plant", 4: "Hold", 5: "Fuel", 6: "Hull",
    7: "Armor", 8: "Hull", 9: "Turret", 10: "M-Drive", 11: "Crew", 12: "Bridge",
}


@dataclass
class ShipCombatant:
    name: str
    tonnage: int
    armor: int = 0
    thrust: int = 1
    weapons: List[Weapon] = field(default_factory=list)
    gunner_skill: int = 0
    computer_dm: int = 0           # computer/targeting + sensor DMs
    hull: int = 0
    structure: int = 0
    initiative: int = 0
    destroyed: bool = False
    systems: Dict[str, int] = field(default_factory=dict)   # damage counters
    log: List[str] = field(default_factory=list)

    def __post_init__(self):
        if self.hull == 0:
            self.hull = self.tonnage // 50
        if self.structure == 0:
            self.structure = max(self.tonnage // 50, 1)

    @property
    def small_craft(self) -> bool:
        return self.tonnage < 100

    @classmethod
    def from_ship(cls, s, weapons: List[str], armor: int = 0,
                  gunner_skill: int = 1, computer_dm: int = 0):
        ws = [WEAPONS[w] for w in weapons]
        return cls(name=s.name, tonnage=s.tonnage or 100, armor=armor,
                   thrust=s.maneuver_g or 1, weapons=ws,
                   gunner_skill=gunner_skill, computer_dm=computer_dm)

    def hit_location_table(self):
        if self.small_craft:
            return HIT_LOCATION_SMALLCRAFT
        return HIT_LOCATION_EXTERNAL if self.hull > 0 else HIT_LOCATION_INTERNAL

    def apply_hit(self, magnitude: int):
        """Apply one rolled hit of the given magnitude to a random location."""
        loc = self.hit_location_table()[dice.roll(2)]
        self.systems[loc] = self.systems.get(loc, 0) + magnitude
        if loc == "Structure":
            self.structure -= magnitude
            if self.structure <= 0:
                self.structure = 0
                self.destroyed = True
        elif loc == "Hull":
            self.hull -= magnitude
            if self.hull < 0:
                # Overflow goes internal: apply remainder as Structure hits.
                self.structure += self.hull   # hull is negative
                self.hull = 0
                if self.structure <= 0:
                    self.structure = 0
                    self.destroyed = True
        elif loc == "Armor":
            if self.armor > 0:
                self.armor = max(self.armor - magnitude, 0)
            else:
                self.hull = max(self.hull - magnitude, 0)
        self.log.append("  hit: {} (-{})".format(loc, magnitude))
        return loc


def initiative(c: ShipCombatant, opponents_thrust: int = 0,
               tactics_effect: int = 0) -> int:
    natural = dice.roll(2)
    dm = 1 if c.thrust > opponents_thrust else 0
    c.initiative = natural + dm + tactics_effect
    return c.initiative


@dataclass
class SpaceAttackResult:
    weapon: str
    hit: bool
    check: Optional[tasks.CheckResult]
    raw_damage: int = 0
    applied_damage: int = 0
    note: str = ""

    def __str__(self):
        if self.note:
            return "{}: {}".format(self.weapon, self.note)
        return "{}: {} (Effect {:+d}) raw {} -> {} after armor".format(
            self.weapon, "HIT" if self.hit else "MISS",
            self.check.effect if self.check else 0,
            self.raw_damage, self.applied_damage)


def attack(attacker: ShipCombatant, defender: ShipCombatant, weapon: Weapon,
           rng: Range, sand_dice: int = 0) -> SpaceAttackResult:
    """Resolve one gunnery attack with a single weapon (SRD)."""
    diff_map = RANGE_DIFFICULTY.get(weapon.name, {})
    if rng not in diff_map:
        return SpaceAttackResult(weapon.name, False, None,
                                 note="cannot fire at {} range".format(rng.value))
    difficulty = diff_map[rng]
    res = tasks.check(characteristic_dm=attacker.computer_dm,
                      skill_dm=attacker.gunner_skill,
                      difficulty=difficulty,
                      other_dm=weapon.attack_dm,
                      unskilled=(attacker.gunner_skill <= 0))
    if not res.success:
        return SpaceAttackResult(weapon.name, False, res)

    dice_n = weapon.damage_value()
    if dice_n is None:
        return SpaceAttackResult(weapon.name, True, res,
                                 note="HIT but weapon damage is unspecified "
                                      "(set BEAM_LASER_DAMAGE_DICE)")
    raw = dice.roll(dice_n) + res.effect
    # Sandcaster defense reduces beam-weapon damage by 1D6 per sand fired.
    if sand_dice and weapon.name in ("Pulse Laser", "Beam Laser",
                                      "Particle Beam"):
        raw -= dice.roll(sand_dice)
    armor = 0 if weapon.ignores_armor else defender.armor
    dmg = max(raw - armor, 0)
    hits = damage_to_hits(dmg)
    applied = 0
    for mag in hits:
        defender.apply_hit(mag)
        applied += mag
    return SpaceAttackResult(weapon.name, True, res, raw_damage=raw,
                             applied_damage=applied)


def ship_turn(attacker: ShipCombatant, defender: ShipCombatant, rng: Range,
              verbose: bool = False):
    for w in attacker.weapons:
        if defender.destroyed:
            break
        if w.mount == "turret" and w.name == "Sandcaster":
            continue   # defensive only
        r = attack(attacker, defender, w, rng)
        if verbose:
            print("  {} fires {}: {}".format(attacker.name, w.name, r))


def ship_duel(a: ShipCombatant, b: ShipCombatant, rng: Range = Range.SHORT,
              max_turns: int = 50, verbose: bool = False) -> ShipCombatant:
    """Run a ship-to-ship duel to destruction. Returns the survivor."""
    initiative(a, b.thrust)
    initiative(b, a.thrust)
    order = sorted([a, b], key=lambda c: (-c.initiative, -c.thrust))
    turns = 0
    while not a.destroyed and not b.destroyed and turns < max_turns:
        turns += 1
        if verbose:
            print("--- turn {} ---".format(turns))
        for atk in order:
            dfn = b if atk is a else a
            if atk.destroyed:
                continue
            ship_turn(atk, dfn, rng, verbose)
            if dfn.destroyed:
                if verbose:
                    print("  {} DESTROYED".format(dfn.name))
                break
    if a.destroyed and b.destroyed:
        return a if not a.destroyed else b
    return b if a.destroyed else a
