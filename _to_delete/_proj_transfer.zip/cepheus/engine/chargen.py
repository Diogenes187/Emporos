"""chargen.py -- Cepheus Engine character generation (the career term loop).

Implements Chapter 1 of the SRD: roll characteristics, take background skills,
then pursue careers term by term (qualify/draft, basic training, survival,
commission, advancement, skills & training, injury, aging) until the character
musters out. All numbers come from the SRD; the per-career tables come from
engine/data/careers.json via careers.py.

Decisions are delegated to a Chooser object. The default RandomChooser plays a
plausible automated character; a later UI/LLM layer can subclass Chooser to put
a human (or model) in the loop without touching the rules.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import dice
from . import careers as careers_mod
from . import skills as skills_mod
from .careers import Career
from .characteristics import Characteristics, Characteristic, ORDER

STARTING_AGE = 18
AGING_ONSET_TERM = 4          # aging rolls begin at the END of the 4th term
MAX_TERMS = 7                 # must retire after 7 terms (SRD default)

PHYSICAL = [Characteristic.STR, Characteristic.DEX, Characteristic.END]
MENTAL = [Characteristic.INT, Characteristic.EDU, Characteristic.SOC]

DRAFT_TABLE = {
    1: "Aerospace Defense", 2: "Marine", 3: "Maritime Defense",
    4: "Navy", 5: "Scout", 6: "Surface Defense",
}
RETIREMENT_PAY = {5: 10000, 6: 12000, 7: 14000, 8: 16000}

HOMEWORLD_LAW_SKILL = {
    "no": "Gun Combat", "low": "Gun Combat", "medium": "Gun Combat",
    "high": "Melee Combat",
}
HOMEWORLD_TRADE_SKILL = {
    "Agricultural": "Animals", "Asteroid": "Zero-G", "Desert": "Survival",
    "Fluid Oceans": "Watercraft", "Garden": "Animals",
    "High Technology": "Computer", "High Population": "Streetwise",
    "Ice-Capped": "Zero-G", "Industrial": "Broker", "Low Technology": "Survival",
    "Poor": "Animals", "Rich": "Carousing", "Water World": "Watercraft",
    "Vacuum": "Zero-G",
}
PRIMARY_EDUCATION_SKILLS = [
    "Admin", "Advocate", "Animals", "Carousing", "Comms", "Computer",
    "Electronics", "Engineering", "Life Sciences", "Linguistics", "Mechanics",
    "Medicine", "Physical Sciences", "Social Sciences", "Space Sciences",
]


@dataclass
class CareerStint:
    career: str
    terms: int = 0
    rank: int = 0
    commissioned: bool = False
    benefits_lost: bool = False


@dataclass
class Character:
    name: str = "Unnamed"
    chars: Characteristics = field(default_factory=Characteristics)
    skills: Dict[str, int] = field(default_factory=dict)
    age: int = STARTING_AGE
    credits: int = 0
    debt: int = 0
    pension: int = 0
    benefits: List[str] = field(default_factory=list)
    history: List[CareerStint] = field(default_factory=list)
    alive: bool = True
    cause_of_death: Optional[str] = None
    log: List[str] = field(default_factory=list)

    @property
    def total_terms(self) -> int:
        return sum(s.terms for s in self.history)

    def add_skill(self, name: str, levels: int = 1) -> None:
        if not name:
            return
        name = skills_mod.normalize(name)
        if name not in self.skills:
            self.skills[name] = 0
        if levels:
            self.skills[name] += levels

    def _log(self, msg: str) -> None:
        self.log.append(msg)

    def sheet(self) -> str:
        lines = ["=" * 56, "{}  (age {})".format(self.name, self.age),
                 str(self.chars)]
        if not self.alive:
            lines.append("** DECEASED: {} **".format(self.cause_of_death))
        career_bits = ", ".join(
            "{} ({} term{}{})".format(
                s.career, s.terms, "" if s.terms == 1 else "s",
                ", rank {}".format(s.rank) if s.rank else "")
            for s in self.history)
        lines.append("Careers: {}".format(career_bits or "none"))
        if self.skills:
            sk = ", ".join("{}-{}".format(k, v)
                           for k, v in sorted(self.skills.items()))
            lines.append("Skills: {}".format(sk))
        money = "Cr{:,}".format(self.credits)
        if self.debt:
            money += "  (debt Cr{:,})".format(self.debt)
        if self.pension:
            money += "  (pension Cr{:,}/yr)".format(self.pension)
        lines.append("Funds: {}".format(money))
        if self.benefits:
            lines.append("Benefits: {}".format(", ".join(self.benefits)))
        lines.append("=" * 56)
        return "\n".join(lines)


class Chooser:
    """Decision hooks for character generation. Subclass to inject a human/LLM."""

    def choose_career(self, char, available): raise NotImplementedError
    def choose_background_skills(self, char, options, count): raise NotImplementedError
    def choose_basic_training_skill(self, char, career, options): raise NotImplementedError
    def choose_skill_table(self, char, career, tables): raise NotImplementedError
    def choose_specialization(self, char, cascade, options): raise NotImplementedError
    def choose_characteristic_boost(self, char): raise NotImplementedError
    def attempt_commission(self, char, career): return True
    def attempt_advancement(self, char, career): return True
    def reenlist(self, char, career): raise NotImplementedError
    def start_new_career(self, char): raise NotImplementedError


class RandomChooser(Chooser):
    """Automated player: prefers skills, climbs ranks, serves ~target_terms."""

    def __init__(self, target_terms: int = 4, rng: Optional[random.Random] = None):
        self.target_terms = target_terms
        self.rng = rng or random.Random()

    def choose_career(self, char, available):
        return self.rng.choice(available)

    def choose_background_skills(self, char, options, count):
        opts = list(dict.fromkeys(options))
        self.rng.shuffle(opts)
        return opts[:count]

    def choose_basic_training_skill(self, char, career, options):
        return self.rng.choice(options)

    def choose_skill_table(self, char, career, tables):
        weighted = []
        for t in tables:
            weighted += [t, t] if t in ("service", "specialist") else [t]
        return self.rng.choice(weighted)

    def choose_specialization(self, char, cascade, options):
        return self.rng.choice(options)

    def choose_characteristic_boost(self, char):
        return min(ORDER, key=lambda c: char.chars.score(c))

    def reenlist(self, char, career):
        return char.total_terms < self.target_terms

    def start_new_career(self, char):
        return char.total_terms < self.target_terms


def _throw(char, characteristic, target, dm=0):
    r = dice.roll_detail(2)
    cdm = char.chars.dm(characteristic) if characteristic else 0
    total = r.natural + cdm + dm
    return (total >= target, r.natural, total)


def _grant_rank_skill(char, career, rank, chooser):
    entry = career.rank(rank)
    skill = entry.get("skill")
    if not skill:
        return
    name, _, lvl = skill.rpartition("-")
    name = name or skill
    levels = int(lvl) if lvl.isdigit() else 1
    _apply_skill(char, name, levels, chooser,
                 "rank {} ({})".format(rank, entry.get("title") or career.name))


def _apply_skill(char, raw, levels, chooser, source):
    raw = raw.strip()
    low = raw.lower()
    if low.startswith("+1 ") or low.startswith("+2 "):
        amount = int(raw[1])
        abbr = raw.split()[1][:3].title()
        for c in ORDER:
            if c.value == abbr:
                char.chars.set_score(c, char.chars.score(c) + amount)
                char._log("  {}: +{} {}".format(source, amount, c.value))
                return
    name = skills_mod.normalize(raw)
    if skills_mod.is_cascade(name):
        spec = chooser.choose_specialization(char, name,
                                             skills_mod.specializations(name))
        char.add_skill(spec, levels)
        char._log("  {}: {} ({}) now {}".format(
            source, name, spec, char.skills[skills_mod.normalize(spec)]))
    else:
        char.add_skill(name, levels)
        char._log("  {}: {} now {}".format(source, name, char.skills[name]))


def roll_skill_table(char, career, chooser):
    tables = career.available_skill_tables(char.chars.score(Characteristic.EDU))
    table = chooser.choose_skill_table(char, career, tables)
    roll = dice.roll(1)
    result = career.skill_table(table).get(roll)
    if result is None:
        char._log("  skill roll [{}] {} -> (none)".format(table, roll))
        return
    _apply_skill(char, result, 1, chooser, "skill [{}] {}".format(table, roll))


def background_skills(char, chooser, law_band="medium", trade_codes=None):
    count = 3 + max(0, char.chars.dm(Characteristic.EDU))
    options = [HOMEWORLD_LAW_SKILL.get(law_band, "Gun Combat")]
    for tc in (trade_codes or []):
        if tc in HOMEWORLD_TRADE_SKILL:
            options.append(HOMEWORLD_TRADE_SKILL[tc])
    options += PRIMARY_EDUCATION_SKILLS
    chosen = chooser.choose_background_skills(char, options, count)
    for s in chosen:
        name = skills_mod.normalize(s)
        if skills_mod.is_cascade(name):
            spec = chooser.choose_specialization(char, name,
                                                 skills_mod.specializations(name))
            char.add_skill(spec, 0)
        else:
            char.add_skill(name, 0)
    char._log("Background skills ({}): {}".format(count, ", ".join(chosen)))


def apply_injury(char, chooser):
    roll = dice.roll(1)
    rng = random.Random()
    def reduce(c, amt):
        char.chars.set_score(c, char.chars.score(c) - amt)
    if roll == 1:
        c = rng.choice(PHYSICAL)
        reduce(c, dice.roll(1))
        for o in [p for p in PHYSICAL if p != c]:
            reduce(o, 2)
        char._log("  INJURY(1): nearly killed")
    elif roll == 2:
        reduce(rng.choice(PHYSICAL), dice.roll(1))
        char._log("  INJURY(2): severely injured")
    elif roll == 3:
        reduce(rng.choice([Characteristic.STR, Characteristic.DEX]), 2)
        char._log("  INJURY(3): missing eye or limb")
    elif roll == 4:
        reduce(rng.choice(PHYSICAL), 2)
        char._log("  INJURY(4): scarred")
    elif roll == 5:
        reduce(rng.choice(PHYSICAL), 1)
        char._log("  INJURY(5): injured")
    else:
        char._log("  INJURY(6): lightly injured, no permanent effect")
    _check_crisis(char, "injury")


def _check_crisis(char, kind):
    if all(char.chars.score(c) > 0 for c in ORDER):
        return
    cost = dice.roll(1) * 10000
    if char.credits >= cost:
        char.credits -= cost
        for cc in ORDER:
            if char.chars.score(cc) <= 0:
                char.chars.set_score(cc, 1)
        char._log("  {} crisis: paid Cr{:,} for medical care".format(kind, cost))
    else:
        char.alive = False
        char.cause_of_death = "{} crisis (could not pay)".format(kind)
        char._log("  {} crisis: DEATH (could not pay Cr{:,})".format(kind, cost))


def aging_check(char, chooser):
    roll = dice.roll(2) - char.total_terms
    rng = random.Random()
    def reduce(c, amt):
        char.chars.set_score(c, char.chars.score(c) - amt)
    if roll >= 1:
        return
    if roll == 0:
        reduce(rng.choice(PHYSICAL), 1)
    elif roll == -1:
        for c in rng.sample(PHYSICAL, 2):
            reduce(c, 1)
    elif roll == -2:
        for c in PHYSICAL:
            reduce(c, 1)
    elif roll == -3:
        o = rng.sample(PHYSICAL, 3); reduce(o[0], 2); reduce(o[1], 1); reduce(o[2], 1)
    elif roll == -4:
        o = rng.sample(PHYSICAL, 3); reduce(o[0], 2); reduce(o[1], 2); reduce(o[2], 1)
    elif roll == -5:
        for c in PHYSICAL:
            reduce(c, 2)
    else:
        for c in PHYSICAL:
            reduce(c, 2)
        reduce(rng.choice(MENTAL), 1)
    char._log("  aging roll {}: characteristics reduced".format(roll))
    _check_crisis(char, "aging")


def muster_out(char, stint, chooser, retired):
    if stint.benefits_lost:
        char._log("Mustering out {}: benefits forfeited".format(stint.career))
        return
    career = careers_mod.get(stint.career)
    rolls = stint.terms
    if stint.rank >= 6:
        rolls += 3
    elif stint.rank == 5:
        rolls += 2
    elif stint.rank == 4:
        rolls += 1
    cash_taken = 0
    has_gambling = char.skills.get("Gambling", 0) > 0
    for _ in range(rolls):
        if cash_taken < 3:
            r = dice.roll(1) + (1 if (has_gambling or retired) else 0)
            r = min(max(r, 1), 7)
            amount = career.cash_benefit(r) or 0
            char.credits += int(amount)
            cash_taken += 1
            char._log("  muster cash[{}]: Cr{:,}".format(r, int(amount)))
        else:
            r = dice.roll(1) + (1 if stint.rank >= 5 else 0)
            r = min(max(r, 1), 7)
            benefit = career.material_benefit(r)
            if benefit:
                _apply_material_benefit(char, benefit, chooser)


def _apply_material_benefit(char, benefit, chooser):
    b = benefit.strip()
    low = b.lower()
    if low.startswith("+1 ") or low.startswith("+2 "):
        amount = int(b[1])
        abbr = b.split()[1][:3].title()
        for c in ORDER:
            if c.value == abbr:
                char.chars.set_score(c, char.chars.score(c) + amount)
                char._log("  muster benefit: +{} {}".format(amount, c.value))
                return
    char.benefits.append(b)
    char._log("  muster benefit: {}".format(b))


def run_term(char, career, stint, chooser, first_term_in_career,
             drafted_first_term, allow_mishaps):
    stint.terms += 1
    sc, st = career.survival
    r = dice.roll_detail(2)
    cdm = char.chars.dm(sc) if sc else 0
    survived = (r.natural != 2) and (r.natural + cdm >= st)
    if not survived:
        if allow_mishaps:
            char._log("  survival FAILED (mishap) -- ejected")
            stint.benefits_lost = True
            char.age += 2
            return True
        char.alive = False
        char.cause_of_death = "failed survival in {}".format(career.name)
        char.age += 4
        char._log("  survival FAILED -- DEATH ({} {}+)".format(
            sc.value if sc else "", st))
        return False
    char._log("  survival ok ({} {}+)".format(sc.value if sc else "-", st))

    extra_rolls = 0
    if (career.has_commission and stint.rank == 0
            and not (drafted_first_term and first_term_in_career)):
        if chooser.attempt_commission(char, career):
            cc, ct = career.commission
            ok, _, _ = _throw(char, cc, ct)
            if ok:
                stint.rank = 1
                stint.commissioned = True
                extra_rolls += 1
                char._log("  COMMISSIONED to rank 1")
                _grant_rank_skill(char, career, 1, chooser)
    if career.has_commission and stint.rank >= 1:
        if chooser.attempt_advancement(char, career):
            ac, at = career.advancement
            ok, _, _ = _throw(char, ac, at)
            if ok and stint.rank < 6:
                stint.rank += 1
                extra_rolls += 1
                char._log("  ADVANCED to rank {}".format(stint.rank))
                _grant_rank_skill(char, career, stint.rank, chooser)

    for _ in range(career.skill_rolls_per_term + extra_rolls):
        roll_skill_table(char, career, chooser)

    char.age += 4
    if char.total_terms >= AGING_ONSET_TERM:
        aging_check(char, chooser)
        if not char.alive:
            return False
    return True


def generate(name="Traveller", chooser=None, law_band="medium",
             trade_codes=None, allow_mishaps=False, seed=None):
    if seed is not None:
        dice.seed(seed)
    chooser = chooser or RandomChooser(rng=random.Random(seed))

    char = Character(name=name, chars=Characteristics.roll())
    char._log("Rolled characteristics: {}".format(char.chars.upp))
    background_skills(char, chooser, law_band, trade_codes)

    prior_careers = []
    used_draft = False

    while char.alive and char.total_terms < MAX_TERMS:
        available = [n for n in careers_mod.names() if n not in prior_careers]
        if "Drifter" not in available:
            available.append("Drifter")
        choice = chooser.choose_career(char, available)
        career = careers_mod.get(choice)

        drafted_first_term = False
        if choice != "Drifter":
            qc, qt = career.qualification
            dm = -2 * len(prior_careers)
            ok, _, _ = _throw(char, qc, qt, dm)
            if not ok:
                if not used_draft:
                    used_draft = True
                    drafted = DRAFT_TABLE[dice.roll(1)]
                    char._log("Failed to qualify for {} -- DRAFTED into {}".format(
                        choice, drafted))
                    career = careers_mod.get(drafted)
                    choice = drafted
                    drafted_first_term = True
                else:
                    char._log("Failed to qualify for {} -- became a Drifter".format(choice))
                    career = careers_mod.get("Drifter")
                    choice = "Drifter"
            else:
                char._log("Qualified for {} ({} {}+, DM{:+d})".format(
                    choice, qc.value if qc else "-", qt, dm))

        stint = CareerStint(career=choice)
        char.history.append(stint)
        service = [v for v in career.skill_table("service").values() if v]
        if not prior_careers:
            for sk in service:
                _apply_skill(char, sk, 0, chooser, "basic training")
        elif service:
            sk = chooser.choose_basic_training_skill(char, career, service)
            _apply_skill(char, sk, 0, chooser, "basic training")
        _grant_rank_skill(char, career, 0, chooser)
        if choice not in prior_careers:
            prior_careers.append(choice)

        first_in_career = True
        serving = True
        while serving and char.alive:
            char._log("--- {} term {} (age {}) ---".format(
                choice, stint.terms + 1, char.age))
            run_term(char, career, stint, chooser, first_in_career,
                     drafted_first_term, allow_mishaps)
            first_in_career = False
            if not char.alive:
                break
            if stint.benefits_lost:
                serving = False
                break

            target = career.reenlistment_target or 6
            natural = dice.roll(2)
            at_cap = char.total_terms >= MAX_TERMS
            if natural == 12:
                char._log("  natural 12 -- must serve another term")
                continue
            if at_cap:
                char._log("  reached term cap -- must leave service")
                serving = False
            elif not chooser.reenlist(char, career):
                char._log("  chose to leave {}".format(choice))
                serving = False
            elif natural >= target:
                char._log("  reenlisted in {} ({}+ ok)".format(choice, target))
                continue
            else:
                char._log("  reenlistment denied ({}+ needed, rolled {})".format(
                    target, natural))
                serving = False

        if not char.alive or char.total_terms >= MAX_TERMS:
            break
        if not chooser.start_new_career(char):
            break

    for s in char.history:
        if s.terms >= 5:
            terms = min(s.terms, 8)
            base = RETIREMENT_PAY.get(terms, 16000 + (s.terms - 8) * 2000)
            char.pension = max(char.pension, base)

    retired = any(s.terms >= 5 for s in char.history)
    if char.alive:
        for s in char.history:
            muster_out(char, s, chooser, retired)
        if char.debt:
            paid = min(char.credits, char.debt)
            char.credits -= paid
            char.debt -= paid

    return char
