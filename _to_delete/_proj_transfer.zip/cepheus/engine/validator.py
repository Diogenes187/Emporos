"""validator.py -- prose may not assert a mechanical fact the tape can't back.

The receipt tape records every mechanical act with the numbers it produced.
This module reads a piece of narration and asks one question of it: does every
mechanical claim in here correspond to a receipt from this turn?

It is deliberately narrow. Flavour numbers are none of its business -- three
guards, a dozen crates, fifty metres of corridor are prose, not mechanics. It
only inspects claims made in mechanical GRAMMAR: a displayed roll, a stated
check total, damage dealt, credits moved, fuel burned, parsecs crossed. Those
are the sentences a player would be entitled to audit, and therefore the ones
that must be true.

    validate(text, receipts) -> {"ok": bool, "violations": [...]}

`receipts` is this turn's tape slice: a list of dicts with a "numbers" field
(space-separated) and a "tool" name. Pass None to disable receipt checking
(the structural rules still run).

Rules
  RECEIPT_BACKING  a mechanical number appears that no receipt produced
  UNBACKED_ROLL    a roll is displayed but no die was rolled this turn
  IMPOSSIBLE_ROLL  a displayed 2D6 total is outside what 2D6 can produce
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

# Tools that actually roll dice.
DICE_TOOLS = frozenset({"roll_dice", "task_check", "jump_ship",
                        "generate_creature", "generate_npc", "generate_world",
                        "trade_price", "attack", "combat_round"})

# A displayed roll: "[task_check, Average: rolled (4,5)+2 = 11 vs 8+ ...]"
ROLL_BRACKET = re.compile(r"\[(?:task_check|roll_dice|roll|check)\b[^\]]*\]", re.I)

# Mechanical grammar. Each pattern captures the number(s) being claimed.
CLAIMS = [
    ("roll",    re.compile(r"\brolled?\s*(?:\(|\[)?\s*(\d+)\s*[,+]\s*(\d+)", re.I)),
    ("total",   re.compile(r"\b(?:total|result)\s*(?:of|:|=)?\s*(\d+)\b", re.I)),
    ("vs",      re.compile(r"=\s*(\d+)\s*(?:vs|versus|against)\s*\d+\+", re.I)),
    ("effect",  re.compile(r"\beffect\s*([+-]?\d+)", re.I)),
    ("credits", re.compile(r"\bCr\s*([\d,]+)", re.I)),
    ("credits", re.compile(r"\b([\d,]+)\s*credits?\b", re.I)),
    ("damage",  re.compile(r"\b(\d+)\s*(?:points? of\s*)?damage\b", re.I)),
    ("fuel",    re.compile(r"\b(\d+)\s*(?:tons?|t)\s*of\s*fuel\b", re.I)),
    ("parsecs", re.compile(r"\b(\d+)\s*parsecs?\b", re.I)),
]

# Numbers so common in prose that demanding a receipt would be absurd.
FREE_NUMBERS = {"0", "1", "2"}


def _norm(n: str) -> str:
    return str(n).replace(",", "").replace("+", "").strip()


def backed_numbers(receipts: Optional[List[Dict[str, Any]]]) -> set:
    out = set()
    for r in receipts or []:
        nums = r.get("numbers") if isinstance(r, dict) else getattr(r, "numbers", "")
        for n in str(nums or "").split():
            out.add(_norm(n))
    return out


def dice_receipts(receipts: Optional[List[Dict[str, Any]]]) -> int:
    n = 0
    for r in receipts or []:
        tool = r.get("tool") if isinstance(r, dict) else getattr(r, "tool", "")
        if tool in DICE_TOOLS:
            n += 1
    return n


def validate(text: str, receipts: Optional[List[Dict[str, Any]]] = None
             ) -> Dict[str, Any]:
    """Check narration against this turn's receipts."""
    text = text or ""
    violations: List[Dict[str, Any]] = []

    shown = ROLL_BRACKET.findall(text)
    if receipts is not None and shown:
        rolled = dice_receipts(receipts)
        if len(shown) > rolled:
            violations.append({
                "rule": "UNBACKED_ROLL",
                "detail": "{} roll(s) displayed, {} die-rolling receipt(s) on "
                          "the tape this turn".format(len(shown), rolled),
                "claims": shown[:6],
            })

    # A 2D6 total outside 2..12 (before modifiers are shown) is not a die
    # result at all -- catch it even with no tape to compare against.
    for m in re.finditer(r"\brolled?\s*\(?\s*(\d+)\s*,\s*(\d+)\s*\)?", text, re.I):
        for face in m.groups():
            if not (1 <= int(face) <= 6):
                violations.append({
                    "rule": "IMPOSSIBLE_ROLL",
                    "detail": "a d6 cannot show {}".format(face),
                    "claims": [m.group(0)],
                })

    if receipts is None:
        return {"ok": not violations, "violations": violations}

    backed = backed_numbers(receipts)
    seen = set()
    for kind, pat in CLAIMS:
        for m in pat.finditer(text):
            for raw in m.groups():
                if raw is None:
                    continue
                n = _norm(raw)
                if not n or n in FREE_NUMBERS or n in backed:
                    continue
                key = (kind, n)
                if key in seen:
                    continue
                seen.add(key)
                violations.append({
                    "rule": "RECEIPT_BACKING",
                    "kind": kind,
                    "number": n,
                    "detail": "narration claims {} {} but no receipt this turn "
                              "produced that number".format(kind, n),
                    "claims": [m.group(0).strip()],
                })
    return {"ok": not violations, "violations": violations}


def summarize(result: Dict[str, Any], limit: int = 6) -> str:
    """A correction the referee can act on, not a lecture."""
    vs = result.get("violations", [])[:limit]
    if not vs:
        return ""
    lines = []
    for v in vs:
        claim = (v.get("claims") or [""])[0]
        lines.append("- {}: {}{}".format(
            v["rule"], v["detail"],
            " -- you wrote {!r}".format(claim) if claim else ""))
    return "\n".join(lines)
