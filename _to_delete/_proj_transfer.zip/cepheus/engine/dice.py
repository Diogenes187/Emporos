"""dice.py -- dice rolling for the Cepheus Engine.

The Cepheus Engine resolves all actions with two six-sided dice (2D6) plus
modifiers (SRD, Introduction: "Roll two six-sided dice (abbreviated 2d6)").
This module provides:

  * roll(n)            -- roll N d6 and return the total
  * roll_detail(...)   -- roll with full breakdown (each die, modifier, total)
  * roll_notation(s)   -- parse and roll standard notation, e.g. "2d6+1"
  * flux / good_flux   -- the signed 2D6 variants used by world/encounter gen

Deliberately NO "boon/bane" mechanic: that belongs to Mongoose Traveller 2e,
not the Cepheus SRD, which uses Difficulty DMs instead (see tasks.py).

Builds on the public-domain-style helper from the orffen toolbox
(reference/toolbox/dice.py) but adds notation parsing and detailed results.
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass, field
from typing import List, Optional


# A single shared RNG so a campaign can be seeded for reproducible play/tests.
_rng = random.Random()


def seed(value: Optional[int]) -> None:
    """Seed the shared RNG (use in tests / reproducible sessions)."""
    _rng.seed(value)


@dataclass
class RollResult:
    """The full breakdown of a roll, so callers (and the log) can show work."""

    dice: List[int] = field(default_factory=list)  # each individual die face
    sides: int = 6
    modifier: int = 0

    @property
    def natural(self) -> int:
        """Sum of the dice before the modifier (the 'natural' result)."""
        return sum(self.dice)

    @property
    def total(self) -> int:
        """Final result: natural roll plus modifier."""
        return self.natural + self.modifier

    def __str__(self) -> str:
        mod = ""
        if self.modifier:
            mod = " {:+d}".format(self.modifier)
        return "{}d{}{} -> {} = {}".format(
            len(self.dice), self.sides, mod, self.dice, self.total
        )


def roll_detail(number: int = 2, sides: int = 6, modifier: int = 0) -> RollResult:
    """Roll `number` dice of `sides` faces, returning a full RollResult.

    Defaults to 2d6, the Cepheus core roll.
    """
    if number < 0:
        raise ValueError("Cannot roll a negative number of dice")
    if sides < 1:
        raise ValueError("Dice must have at least one side")
    dice = [_rng.randint(1, sides) for _ in range(number)]
    return RollResult(dice=dice, sides=sides, modifier=modifier)


def roll(number: int = 2, sides: int = 6, modifier: int = 0) -> int:
    """Roll dice and return just the total. Defaults to 2d6."""
    return roll_detail(number, sides, modifier).total


# Standard RPG dice notation: NdS+/-M  (N and the modifier are optional).
#   "2d6", "d6", "1d6+1", "3D6 - 2"
_NOTATION = re.compile(
    r"^\s*(\d*)\s*[dD]\s*(\d+)\s*([+-]\s*\d+)?\s*$"
)


def roll_notation(notation: str) -> RollResult:
    """Parse and roll standard dice notation such as '2d6+1' or 'd6'.

    Whitespace around the parts is ignored. A missing dice count means 1.
    """
    m = _NOTATION.match(notation)
    if not m:
        raise ValueError("Unrecognized dice notation: {!r}".format(notation))
    count = int(m.group(1)) if m.group(1) else 1
    sides = int(m.group(2))
    modifier = int(m.group(3).replace(" ", "")) if m.group(3) else 0
    return roll_detail(count, sides, modifier)


def flux() -> int:
    """Flux: 1D6 - 1D6, giving a signed result in the range -5..+5.

    Used in several Cepheus generators (e.g. shifting a base value up or down).
    """
    return _rng.randint(1, 6) - _rng.randint(1, 6)


def good_flux() -> int:
    """Good Flux: larger die minus smaller die, a 0..+5 result skewed positive."""
    a, b = _rng.randint(1, 6), _rng.randint(1, 6)
    return max(a, b) - min(a, b)


if __name__ == "__main__":  # pragma: no cover - manual smoke test
    print(roll_detail())            # a 2d6
    print(roll_notation("3d6+2"))   # parsed notation
    print("flux:", flux(), "good_flux:", good_flux())
