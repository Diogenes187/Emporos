"""creatures.py -- honest-dice creature generation for the Cepheus Engine.

Animals and beasts in Cepheus terms: STR/DEX/END rolled by size class, hits =
STR + END, natural armor rolled on a hide table, attack skill rolled by
ferocity, damage set by size and natural weapon. Every number comes off real
dice via engine.dice (the campaign's shared, seedable RNG), and generate()
returns the full roll breakdown so the caller can log receipts.

This is deliberately simple and fair rather than exhaustive: enough to put a
one-record, one-beast creature on the table whose stats the referee did not
invent. Traits (flyer, venomous, armored...) are declared by the referee from
the fiction, not rolled -- the module knows what the thing is; the dice decide
how strong this PARTICULAR one turned out.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import dice


# Size class -> (STR dice/mod, DEX dice/mod, END dice/mod, base damage dice)
SIZES: Dict[str, dict] = {
    "tiny":      {"str": (1, -2), "dex": (2, 2),  "end": (1, -2), "dmg": (1, -3)},
    "small":     {"str": (1, 1),  "dex": (2, 1),  "end": (1, 1),  "dmg": (1, -2)},
    "medium":    {"str": (2, 0),  "dex": (2, 0),  "end": (2, 0),  "dmg": (1, 0)},
    "large":     {"str": (3, 2),  "dex": (2, -1), "end": (3, 2),  "dmg": (2, 0)},
    "huge":      {"str": (4, 4),  "dex": (2, -2), "end": (4, 4),  "dmg": (3, 0)},
    "monstrous": {"str": (6, 6),  "dex": (2, -2), "end": (6, 6),  "dmg": (4, 0)},
}

# Ferocity -> how the attack-skill die is read (all on a live 1d6).
FEROCITY = ("timid", "defensive", "aggressive", "predator")

WEAPONS = ("teeth", "claws", "teeth and claws", "stinger", "horns",
           "tentacles", "crusher")

# Natural armor: 2d6 on the hide table.
_ARMOR_TABLE = [(7, 0, "none"), (9, 1, "hide"), (10, 2, "tough hide"),
                (11, 3, "plates"), (12, 4, "shell")]


@dataclass
class Creature:
    name: str
    size: str
    ferocity: str
    weapon: str
    strength: int
    dexterity: int
    endurance: int
    hits: int
    armor: int
    armor_kind: str
    attack_skill: int
    damage: str
    traits: List[str] = field(default_factory=list)
    rolls: List[Tuple[str, str]] = field(default_factory=list)  # (label, shown)

    def statline(self) -> str:
        tr = ", ".join(self.traits) if self.traits else "none"
        return ("CREATURE: {sz} {fer}, {wpn}. Hits {hits} (STR {s} DEX {d} "
                "END {e}) | Armor {ar} ({ak}) | Attack skill {atk}, damage "
                "{dmg} | Traits: {tr}").format(
                    sz=self.size, fer=self.ferocity, wpn=self.weapon,
                    hits=self.hits, s=self.strength, d=self.dexterity,
                    e=self.endurance, ar=self.armor, ak=self.armor_kind,
                    atk=self.attack_skill, dmg=self.damage, tr=tr)


def _roll(label: str, n: int, mod: int, rolls: List[Tuple[str, str]]) -> int:
    r = dice.roll_detail(n, 6, mod)
    rolls.append((label, str(r)))
    return max(0, r.total)


def generate(name: str, size: str = "medium", ferocity: str = "predator",
             weapon: Optional[str] = None,
             traits: Optional[List[str]] = None) -> Creature:
    """Roll up one creature with live dice. Raises ValueError on a bad size
    or ferocity so the caller can correct itself rather than get garbage."""
    sz = str(size).strip().lower()
    if sz not in SIZES:
        raise ValueError("unknown size {!r}; use one of {}".format(
            size, "/".join(SIZES)))
    fer = str(ferocity).strip().lower()
    if fer not in FEROCITY:
        raise ValueError("unknown ferocity {!r}; use one of {}".format(
            ferocity, "/".join(FEROCITY)))
    spec = SIZES[sz]
    rolls: List[Tuple[str, str]] = []

    s = _roll("STR", *spec["str"], rolls)
    d = _roll("DEX", *spec["dex"], rolls)
    e = _roll("END", *spec["end"], rolls)

    # Natural armor: 2d6 on the hide table.
    ar_roll = dice.roll_detail(2, 6, 0)
    rolls.append(("armor (hide table)", str(ar_roll)))
    armor, armor_kind = 0, "none"
    for ceiling, val, kind in _ARMOR_TABLE:
        if ar_roll.total <= ceiling:
            armor, armor_kind = val, kind
            break

    # Attack skill: one honest d6, read through the beast's temperament.
    atk_roll = dice.roll_detail(1, 6, 0)
    rolls.append(("attack skill (d6, {})".format(fer), str(atk_roll)))
    v = atk_roll.total
    attack_skill = {"timid": (v - 1) // 3,          # 0..1
                    "defensive": v // 3,            # 0..2
                    "aggressive": (v + 1) // 3,     # 0..2, skewed up
                    "predator": (v + 2) // 3}[fer]  # 1..2 (+size below)
    if sz in ("large", "huge", "monstrous") and fer == "predator":
        attack_skill += 1                            # apex things hit harder

    wpn = (weapon or "").strip().lower()
    if wpn not in WEAPONS:
        w_roll = dice.roll_detail(1, 6, 0)
        rolls.append(("natural weapon (d6)", str(w_roll)))
        wpn = WEAPONS[(w_roll.total - 1) % len(WEAPONS)]

    n_dmg, m_dmg = spec["dmg"]
    damage = "{}d6{}".format(n_dmg, "{:+d}".format(m_dmg) if m_dmg else "")

    return Creature(name=name, size=sz, ferocity=fer, weapon=wpn,
                    strength=s, dexterity=d, endurance=e, hits=s + e,
                    armor=armor, armor_kind=armor_kind,
                    attack_skill=attack_skill, damage=damage,
                    traits=[t.strip() for t in (traits or []) if str(t).strip()],
                    rolls=rolls)
