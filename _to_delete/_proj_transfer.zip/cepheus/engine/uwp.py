"""uwp.py -- turn terse T5/Cepheus world codes into plain language.

The database stores worlds the compact way ('A477879-D', 'Rm', hex '1914').
That is right for storage and wrong for a referee: a model reading raw codes
decodes them in its head and gets them wrong -- calling a tainted atmosphere
breathable, a hundred million people seven billion, or inventing a polity out
of a two-letter allegiance code.

So: decode once, here, and hand the referee words instead of digits.

  describe(row)            -> dict of decoded fields + a one-line summary
  bearing(from_hex, to_hex)-> 'rimward', '2 parsecs coreward-trailing', ...
  ALLEGIANCE               -> the Emporion's reach codes, expanded

Everything degrades gracefully: an odd or missing UWP yields 'unknown'
rather than an exception, because a referee mid-scene needs an answer.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .pseudohex import from_pseudohex

STARPORT = {
    "A": "Class A -- excellent: refined fuel, full shipyard, annual overhaul",
    "B": "Class B -- good: refined fuel, spacecraft shipyard, repairs",
    "C": "Class C -- routine: unrefined fuel, some repair capacity",
    "D": "Class D -- poor: unrefined fuel only, no repair facilities",
    "E": "Class E -- frontier: a marked landing area, no services at all",
    "X": "No starport -- nothing on the ground answers hails",
}

SIZE = {
    0: "asteroid belt or tiny body, negligible gravity",
    1: "~1,600 km diameter, 0.05g",
    2: "~3,200 km diameter, 0.15g",
    3: "~4,800 km diameter, 0.25g",
    4: "~6,400 km diameter, 0.35g",
    5: "~8,000 km diameter, 0.45g",
    6: "~9,600 km diameter, 0.7g",
    7: "~11,200 km diameter, 0.9g",
    8: "~12,800 km diameter, 1.0g",
    9: "~14,400 km diameter, 1.25g",
    10: "~16,000 km diameter, 1.4g",
}

# (description, what a visitor must wear)
ATMOSPHERE = {
    0: ("none -- vacuum", "VACC SUIT REQUIRED"),
    1: ("trace", "VACC SUIT REQUIRED"),
    2: ("very thin, tainted", "respirator AND filter required"),
    3: ("very thin", "respirator required"),
    4: ("thin, tainted", "filter mask required"),
    5: ("thin", "breathable"),
    6: ("standard", "breathable -- shirtsleeve world"),
    7: ("standard, tainted", "FILTER MASK REQUIRED"),
    8: ("dense", "breathable"),
    9: ("dense, tainted", "FILTER MASK REQUIRED"),
    10: ("exotic", "air supply required"),
    11: ("corrosive", "protective suit required"),
    12: ("insidious", "sealed suit; it defeats most gear within hours"),
    13: ("very dense, high pressure", "breathable at low altitude only"),
    14: ("thin, low pressure", "breathable at low altitude only"),
    15: ("unusual -- varies", "check locally before disembarking"),
}

GOVERNMENT = {
    0: "no government -- family and clan bands",
    1: "company/corporate world",
    2: "participating democracy",
    3: "self-perpetuating oligarchy",
    4: "representative democracy",
    5: "feudal technocracy",
    6: "captive government -- ruled from off-world",
    7: "balkanized -- rival states, no single authority",
    8: "civil service bureaucracy",
    9: "impersonal bureaucracy",
    10: "charismatic dictator",
    11: "non-charismatic dictator",
    12: "charismatic oligarchy",
    13: "religious dictatorship",
    14: "religious autocracy",
    15: "totalitarian oligarchy",
}

LAW = {
    0: "no restrictions worth the name",
    1: "poison gas, explosives, undetectable weapons banned",
    2: "portable energy weapons banned",
    3: "military weapons and automatic weapons banned",
    4: "light assault weapons banned",
    5: "concealable firearms banned",
    6: "all firearms except shotguns banned",
    7: "shotguns banned as well",
    8: "blades controlled; no open carry of anything",
    9: "no weapons permitted outside the home",
}

TRADE_CODES = {
    "Ag": "Agricultural -- food, textiles and livestock sell cheap here",
    "As": "Asteroid belt -- vacuum, mining, no world underfoot",
    "Ba": "Barren -- no population at all",
    "De": "Desert -- no surface water",
    "Fl": "Fluid oceans (non-water)",
    "Ga": "Garden world -- benign and green",
    "Hi": "High population -- hungry markets, deep demand",
    "Ht": "High technology",
    "Ic": "Ice-capped -- frozen surface, no free water",
    "In": "Industrial -- manufactured goods sell cheap here",
    "Lo": "Low population",
    "Lt": "Low technology",
    "Na": "Non-agricultural -- food fetches a premium",
    "Ni": "Non-industrial -- machinery fetches a premium",
    "Po": "Poor",
    "Ri": "Rich -- deep pockets, luxury demand",
    "Va": "Vacuum world",
    "Wa": "Water world -- oceans, little land",
}

BASES = {"N": "Naval base", "S": "Scout base", "M": "Military base",
         "C": "Corsair base", "D": "Naval depot", "W": "Way station",
         "R": "Research station", "P": "Prison/exile camp"}

ZONE = {"A": "AMBER ZONE -- travel advisory; dangerous conditions",
        "R": "RED ZONE -- interdicted; traffic is turned back or fired on"}

# The Emporion's eight reaches, by allegiance code. A bare two-letter code is
# exactly the sort of thing a referee will confabulate a nation out of.
ALLEGIANCE = {
    "Nr": "the Norse Reach (Nordvegr, the North Way) -- feuding jarldoms",
    "Gk": "the Greek Reach (the Koinon, the League) -- squabbling city-worlds",
    "Rm": "the Roman Reach (Res Publica Stellarum) -- senate, censors, legions",
    "Jp": "the Japanese Reach (Takamagahara) -- court, clans and guilds",
    "My": "the Maya Reach (Ox Te' Tuun) -- astronomer-kings and observatories",
    "Sw": "the Swahili Reach (Pwani ya Nyota) -- independent port-sultanates",
    "Eg": "the Egyptian Reach (Ta-Sopdet) -- temple-bureaucracies on the main",
    "Su": "the Sumerian Reach (Ki-Engir) -- ziggurat arcologies under Ur",
}


def _val(ch: str) -> Optional[int]:
    try:
        return from_pseudohex(ch)
    except (ValueError, AttributeError):
        return None


def _pop_words(p: Optional[int]) -> str:
    if p is None:
        return "unknown"
    if p == 0:
        return "uninhabited"
    words = {1: "a few dozen people", 2: "hundreds", 3: "thousands",
             4: "tens of thousands", 5: "hundreds of thousands",
             6: "millions", 7: "tens of millions",
             8: "hundreds of millions", 9: "billions",
             10: "tens of billions"}
    return "{} (10^{} order of magnitude)".format(
        words.get(p, "an enormous population"), p)


def _tl_words(t: Optional[int]) -> str:
    if t is None:
        return "unknown"
    band = ("pre-industrial" if t <= 3 else
            "industrial age" if t <= 6 else
            "pre-stellar" if t <= 9 else
            "early stellar" if t <= 11 else
            "average stellar" if t <= 14 else "high stellar")
    return "TL {} -- {}".format(t, band)


def _get(row: Any, key: str, default: str = "") -> str:
    if isinstance(row, dict):
        return str(row.get(key, default) or default)
    try:
        return str(row[key] or default)
    except (TypeError, KeyError, IndexError):
        return str(getattr(row, key, default) or default)


def describe(row: Any) -> Dict[str, Any]:
    """Decode a world row into plain language for the referee."""
    uwp = _get(row, "uwp").replace("-", "").strip()
    port = (uwp[0].upper() if uwp else "X")
    size = _val(uwp[1]) if len(uwp) > 1 else None
    atm = _val(uwp[2]) if len(uwp) > 2 else None
    hyd = _val(uwp[3]) if len(uwp) > 3 else None
    pop = _val(uwp[4]) if len(uwp) > 4 else None
    gov = _val(uwp[5]) if len(uwp) > 5 else None
    law = _val(uwp[6]) if len(uwp) > 6 else None
    tl = _val(uwp[7]) if len(uwp) > 7 else None

    atmo_desc, atmo_gear = ATMOSPHERE.get(
        atm, ("unknown", "check before disembarking"))
    codes = [t for t in _get(row, "remarks").split() if t in TRADE_CODES]
    base_list = [BASES[b] for b in _get(row, "bases").upper() if b in BASES]
    pbg = _get(row, "pbg")
    gas_giant = bool(len(pbg) == 3 and pbg[2].isdigit() and int(pbg[2]) > 0)
    alleg = _get(row, "allegiance").strip()

    out = {
        "name": _get(row, "name"),
        "hex": _get(row, "hex"),
        "uwp": _get(row, "uwp"),
        "starport": STARPORT.get(port, STARPORT["X"]),
        "size": SIZE.get(size, "unknown size"),
        "atmosphere": atmo_desc,
        "atmosphere_gear": atmo_gear,
        "hydrographics": ("no surface water" if hyd == 0 else
                          "about {}% surface water".format(min(hyd, 10) * 10)
                          if hyd is not None else "unknown"),
        "population": _pop_words(pop),
        "government": GOVERNMENT.get(gov, "unknown government"),
        "law_level": ("law level {} -- {}".format(law, LAW[law])
                      if law in LAW else
                      "law level {} -- total prohibition; mind your step".format(law)
                      if law is not None else "unknown"),
        "tech_level": _tl_words(tl),
        "trade_codes": {c: TRADE_CODES[c] for c in codes},
        "bases": base_list or ["no bases"],
        "gas_giant": ("gas giant present -- wilderness refuelling possible"
                      if gas_giant else "no gas giant -- fuel at the port"),
        "allegiance": ALLEGIANCE.get(alleg, alleg or "unaligned"),
        "travel_zone": ZONE.get(_get(row, "zone").upper(), "green -- no advisory"),
    }
    out["summary"] = (
        "{name} ({hex}, {uwp}): {port}. {atmo} atmosphere -- {gear}. "
        "{pop}. {gov}. {law}. {tl}. {alleg}.".format(
            name=out["name"], hex=out["hex"], uwp=out["uwp"],
            port=out["starport"].split(" -- ")[0], atmo=atmo_desc,
            gear=atmo_gear, pop=out["population"].split(" (")[0],
            gov=out["government"], law=out["law_level"], tl=out["tech_level"],
            alleg=out["allegiance"]))
    return out


# --- direction ------------------------------------------------------------

def bearing(from_hex, to_hex) -> str:
    """Plain-language direction and distance. One implementation, engine.hexes."""
    from . import hexes
    return hexes.bearing(from_hex, to_hex)
