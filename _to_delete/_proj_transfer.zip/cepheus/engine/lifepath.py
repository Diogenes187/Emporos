"""lifepath.py -- interactive, step-by-step Cepheus character creation.

Where chargen.generate() runs the whole career lifepath at once (great for
NPCs), LifepathSession runs it as a *resumable* sequence of decisions a human
makes one at a time -- the rich tabletop experience. It is driven by a
generator coroutine: each pending decision is yielded to the caller, and the
player's choice is sent back in.

The player makes the meaningful choices (assign characteristics, background
skills, which career, push for commission?, which skill table, cascade
specialization, reenlist?, new career?, cash vs material benefit). The dice
(qualification, survival, advancement, aging, reenlistment throws) roll
automatically and are reported in the feed.

For player characters the kinder SRD survival rule is on by default: a failed
survival roll EJECTS you from the career (mishap) rather than killing you.
"""
from __future__ import annotations

import random
from typing import Any, Dict, List, Optional

from . import dice
from . import careers as careers_mod
from . import skills as skills_mod
from .characteristics import Characteristics, Characteristic, ORDER
from .chargen import (Character, CareerStint, STARTING_AGE, MAX_TERMS,
                      AGING_ONSET_TERM, PHYSICAL, MENTAL, DRAFT_TABLE,
                      RETIREMENT_PAY, HOMEWORLD_LAW_SKILL, HOMEWORLD_TRADE_SKILL,
                      PRIMARY_EDUCATION_SKILLS)

ABBR = [c.value for c in ORDER]          # ["Str","Dex","End","Int","Edu","Soc"]


class LifepathSession:
    def __init__(self, name: str = "Traveller", allow_mishaps: bool = True,
                 law_band: str = "medium", trade_codes: Optional[List[str]] = None,
                 seed: Optional[int] = None):
        import random as _r
        self.seed = seed if seed is not None else _r.randint(0, 2**31 - 1)
        self.rng = _r.Random(self.seed)
        self.char = Character(name=name)
        self.allow_mishaps = allow_mishaps
        self.law_band = law_band
        self.trade_codes = trade_codes or []
        self.feed: List[str] = []
        self.complete = False
        self._gen = self._script()
        self.current = next(self._gen)   # prime to first decision

    # ---- public API ----------------------------------------------------

    def pending(self) -> Optional[Dict[str, Any]]:
        return self.current

    def choose(self, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if self.complete:
            return self.current
        try:
            self.current = self._gen.send(payload or {})
        except StopIteration:
            self.complete = True
        return self.current

    def result(self) -> Character:
        return self.char

    # ---- helpers -------------------------------------------------------

    def _log(self, msg: str):
        self.feed.append(msg)
        self.char.log.append(msg)

    def _d6(self) -> int:
        return self.rng.randint(1, 6)

    def _2d6(self) -> int:
        return self.rng.randint(1, 6) + self.rng.randint(1, 6)

    def _decision(self, step: str, **kw) -> Dict[str, Any]:
        d = {"step": step, "feed": list(self.feed),
             "character": self._snapshot()}
        d.update(kw)
        self.feed = []
        return d

    def _snapshot(self) -> Dict[str, Any]:
        return {
            "name": self.char.name, "upp": self.char.chars.upp,
            "age": self.char.age, "credits": self.char.credits,
            "alive": self.char.alive,
            "skills": dict(self.char.skills),
            "careers": [{"career": s.career, "terms": s.terms, "rank": s.rank}
                        for s in self.char.history],
            "benefits": list(self.char.benefits),
        }

    def _throw(self, characteristic, target, dm=0):
        nat = self._2d6()
        cdm = self.char.chars.dm(characteristic) if characteristic else 0
        return (nat + cdm + dm >= target, nat, nat + cdm + dm)

    def _apply_skill(self, raw: str, levels: int):
        """Apply a skill/boost. Returns cascade name if a specialization is needed."""
        raw = raw.strip()
        low = raw.lower()
        if low.startswith("+1 ") or low.startswith("+2 "):
            amount = int(raw[1])
            abbr = raw.split()[1][:3].title()
            for c in ORDER:
                if c.value == abbr:
                    self.char.chars.set_score(c, self.char.chars.score(c) + amount)
                    self._log("  {} +{}".format(c.value, amount))
                    return None
        name = skills_mod.normalize(raw)
        if skills_mod.is_cascade(name):
            return name
        self.char.add_skill(name, levels)
        self._log("  gained {} ({})".format(name, self.char.skills[name]))
        return None

    def _aging(self):
        roll = self._2d6() - self.char.total_terms
        rng = self.rng
        def red(c, a): self.char.chars.set_score(c, self.char.chars.score(c) - a)
        if roll >= 1:
            return
        if roll == 0:
            red(rng.choice(PHYSICAL), 1)
        elif roll == -1:
            [red(c, 1) for c in rng.sample(PHYSICAL, 2)]
        elif roll == -2:
            [red(c, 1) for c in PHYSICAL]
        elif roll == -3:
            o = rng.sample(PHYSICAL, 3); red(o[0], 2); red(o[1], 1); red(o[2], 1)
        elif roll == -4:
            o = rng.sample(PHYSICAL, 3); red(o[0], 2); red(o[1], 2); red(o[2], 1)
        elif roll == -5:
            [red(c, 2) for c in PHYSICAL]
        else:
            [red(c, 2) for c in PHYSICAL]; red(rng.choice(MENTAL), 1)
        self._log("  ageing takes its toll")

    # ---- the lifepath itself (generator coroutine) ---------------------

    def _script(self):
        c = self.char
        # 1) Characteristics: roll six, player assigns. Unlimited rerolls -- a
        #    reroll re-rolls the six and re-presents the same step. Each reroll
        #    is a stored choice consuming the seeded RNG in order, so
        #    deterministic replay is unaffected.
        while True:
            rolled = [self._2d6() for _ in range(6)]
            self._log("Rolled six characteristics: {} (total {})".format(
                rolled, sum(rolled)))
            ans = yield self._decision("assign_characteristics", rolled=rolled,
                                       slots=ABBR, total=sum(rolled),
                                       prompt="Assign each rolled value to a characteristic.")
            if not (ans or {}).get("reroll"):
                break
            self._log("Rerolled characteristics.")
        assignment = (ans or {}).get("assignment") or ABBR
        # assignment[i] is the characteristic abbrev that gets rolled[i]
        for value, abbr in zip(rolled, assignment):
            c.chars.set_score(Characteristic(abbr), value)
        self._log("Characteristics set: UPP {}".format(c.chars.upp))

        # 2) Background skills.
        count = 3 + max(0, c.chars.dm(Characteristic.EDU))
        opts = [HOMEWORLD_LAW_SKILL.get(self.law_band, "Gun Combat")]
        for tc in self.trade_codes:
            if tc in HOMEWORLD_TRADE_SKILL:
                opts.append(HOMEWORLD_TRADE_SKILL[tc])
        opts += PRIMARY_EDUCATION_SKILLS
        opts = list(dict.fromkeys(opts))
        ans = yield self._decision("background_skills", options=opts, count=count,
                                   prompt="Choose {} background skills (Level 0).".format(count))
        picked = (ans or {}).get("skills") or opts[:count]
        for s in picked[:count]:
            nm = skills_mod.normalize(s)
            if skills_mod.is_cascade(nm):
                spec = yield self._decision("specialization", cascade=nm,
                                            options=skills_mod.specializations(nm),
                                            prompt="Choose a {} specialization.".format(nm))
                c.add_skill((spec or {}).get("specialization") or skills_mod.specializations(nm)[0], 0)
            else:
                c.add_skill(nm, 0)
        self._log("Background skills: {}".format(", ".join(picked[:count])))

        prior: List[str] = []
        used_draft = False

        # 3) Careers.
        while c.alive and c.total_terms < MAX_TERMS:
            available = [n for n in careers_mod.names() if n not in prior]
            if "Drifter" not in available:
                available.append("Drifter")
            ans = yield self._decision("choose_career", options=available,
                                       prompt="Choose a career to enter.")
            choice = (ans or {}).get("career") or "Drifter"
            career = careers_mod.get(choice)
            drafted_first = False

            if choice != "Drifter":
                qc, qt = career.qualification
                dm = -2 * len(prior)
                ok, _, tot = self._throw(qc, qt, dm)
                if ok:
                    self._log("Qualified for {} ({} {}+, DM{:+d}; rolled {}).".format(
                        choice, qc.value if qc else "-", qt, dm, tot))
                else:
                    if not used_draft:
                        used_draft = True
                        drafted = DRAFT_TABLE[self._d6()]
                        self._log("Failed to qualify for {} -- DRAFTED into {}.".format(choice, drafted))
                        career = careers_mod.get(drafted); choice = drafted
                        drafted_first = True
                    else:
                        self._log("Failed to qualify for {} -- became a Drifter.".format(choice))
                        career = careers_mod.get("Drifter"); choice = "Drifter"

            stint = CareerStint(career=choice)
            c.history.append(stint)
            service = [v for v in career.skill_table("service").values() if v]
            if not prior:
                for sk in service:
                    res = self._apply_skill(sk, 0)
                    if res:
                        c.add_skill(skills_mod.specializations(res)[0], 0)
                self._log("Basic training: all {} service skills at level 0.".format(choice))
            elif service:
                ans = yield self._decision("basic_training", options=service,
                                           prompt="Basic training: choose one service skill (Level 0).")
                bt = (ans or {}).get("skill") or service[0]
                res = self._apply_skill(bt, 0)
                if res:
                    spec = yield self._decision("specialization", cascade=res,
                                                options=skills_mod.specializations(res),
                                                prompt="Choose a {} specialization.".format(res))
                    c.add_skill((spec or {}).get("specialization") or skills_mod.specializations(res)[0], 0)
            # rank-0 skill
            rank0 = career.rank(0).get("skill")
            if rank0:
                nm, _, lvl = rank0.rpartition("-")
                res = self._apply_skill(nm or rank0, int(lvl) if lvl.isdigit() else 1)
                if res:
                    spec = yield self._decision("specialization", cascade=res,
                                                options=skills_mod.specializations(res),
                                                prompt="Choose a {} specialization.".format(res))
                    c.add_skill((spec or {}).get("specialization") or skills_mod.specializations(res)[0],
                                int(lvl) if lvl.isdigit() else 1)
            if choice not in prior:
                prior.append(choice)

            first_in_career = True
            serving = True
            while serving and c.alive:
                stint.terms += 1
                # Survival.
                sc, st = career.survival
                nat = self._2d6()
                cdm = c.chars.dm(sc) if sc else 0
                survived = (nat != 2) and (nat + cdm >= st)
                if not survived:
                    if self.allow_mishaps:
                        self._log("Survival FAILED ({} {}+, rolled {}) -- mishap, ejected from {}.".format(
                            sc.value if sc else "-", st, nat, choice))
                        stint.benefits_lost = True
                        c.age += 2
                        serving = False
                        break
                    c.alive = False
                    c.cause_of_death = "failed survival in {}".format(choice)
                    c.age += 4
                    self._log("Survival FAILED -- DEATH in {}.".format(choice))
                    break
                self._log("{} term {}: survival ok ({} {}+, rolled {}).".format(
                    choice, stint.terms, sc.value if sc else "-", st, nat))

                extra = 0
                if (career.has_commission and stint.rank == 0
                        and not (drafted_first and first_in_career)):
                    ans = yield self._decision("commission", career=choice,
                                               prompt="Attempt a commission this term?")
                    if (ans or {}).get("attempt", True):
                        cc, ct = career.commission
                        ok, _, tot = self._throw(cc, ct)
                        if ok:
                            stint.rank = 1; extra += 1
                            self._log("COMMISSIONED to rank 1 (rolled {}).".format(tot))
                            rsk = career.rank(1).get("skill")
                            if rsk:
                                nm, _, lvl = rsk.rpartition("-")
                                self._apply_skill(nm or rsk, int(lvl) if lvl.isdigit() else 1)
                        else:
                            self._log("Commission attempt failed (rolled {}).".format(tot))

                if career.has_commission and stint.rank >= 1:
                    ans = yield self._decision("advancement", career=choice,
                                               rank=stint.rank,
                                               prompt="Attempt advancement this term?")
                    if (ans or {}).get("attempt", True):
                        ac, at = career.advancement
                        ok, _, tot = self._throw(ac, at)
                        if ok and stint.rank < 6:
                            stint.rank += 1; extra += 1
                            self._log("ADVANCED to rank {} (rolled {}).".format(stint.rank, tot))
                            rsk = career.rank(stint.rank).get("skill")
                            if rsk:
                                nm, _, lvl = rsk.rpartition("-")
                                self._apply_skill(nm or rsk, int(lvl) if lvl.isdigit() else 1)
                        else:
                            self._log("Advancement attempt failed (rolled {}).".format(tot))

                rolls = career.skill_rolls_per_term + extra
                for _ in range(rolls):
                    tables = career.available_skill_tables(c.chars.score(Characteristic.EDU))
                    ans = yield self._decision("skill_table", options=tables,
                                               prompt="Choose a training table to roll on.")
                    table = (ans or {}).get("table") or tables[0]
                    if table not in tables:
                        table = tables[0]
                    roll = self._d6()
                    result = career.skill_table(table).get(roll)
                    if result is None:
                        self._log("Training [{}] {} -> nothing.".format(table, roll))
                        continue
                    res = self._apply_skill(result, 1)
                    if res:
                        spec = yield self._decision("specialization", cascade=res,
                                                    options=skills_mod.specializations(res),
                                                    prompt="Choose a {} specialization.".format(res))
                        c.add_skill((spec or {}).get("specialization") or skills_mod.specializations(res)[0], 1)

                c.age += 4
                if c.total_terms >= AGING_ONSET_TERM:
                    self._aging()
                    if not c.alive:
                        break
                first_in_career = False

                if c.total_terms >= MAX_TERMS:
                    self._log("Reached the {}-term limit -- must leave service.".format(MAX_TERMS))
                    serving = False
                    break
                target = career.reenlistment_target or 6
                natural = self._2d6()
                if natural == 12:
                    self._log("Natural 12 -- compelled to serve another term.")
                    continue
                ans = yield self._decision("reenlist", career=choice, target=target,
                                           prompt="Reenlist for another term in {}?".format(choice))
                if not (ans or {}).get("continue", True):
                    self._log("Chose to leave {}.".format(choice))
                    serving = False
                elif natural >= target:
                    self._log("Reenlisted in {} ({}+ ok, rolled {}).".format(choice, target, natural))
                else:
                    self._log("Reenlistment denied ({}+ needed, rolled {}).".format(target, natural))
                    serving = False

            if not c.alive or c.total_terms >= MAX_TERMS:
                break
            ans = yield self._decision("new_career",
                                       prompt="Leave with what you have, or try a new career?")
            if not (ans or {}).get("another", False):
                break

        # Pension.
        for s in c.history:
            if s.terms >= 5:
                t = min(s.terms, 8)
                base = RETIREMENT_PAY.get(t, 16000 + (s.terms - 8) * 2000)
                c.pension = max(c.pension, base)
        retired = any(s.terms >= 5 for s in c.history)

        # 4) Mustering out -- player chooses cash vs material per benefit.
        if c.alive:
            for s in c.history:
                if s.benefits_lost:
                    self._log("{}: benefits forfeited (mishap).".format(s.career))
                    continue
                career = careers_mod.get(s.career)
                rolls = s.terms + (3 if s.rank >= 6 else 2 if s.rank == 5 else 1 if s.rank == 4 else 0)
                cash_taken = 0
                has_gambling = c.skills.get("Gambling", 0) > 0
                for _ in range(rolls):
                    ans = yield self._decision("muster_benefit", career=s.career,
                                               cash_allowed=cash_taken < 3,
                                               prompt="Mustering out of {}: take cash or a material benefit?".format(s.career))
                    take = (ans or {}).get("take", "cash" if cash_taken < 3 else "material")
                    if take == "cash" and cash_taken < 3:
                        r = self._d6() + (1 if (has_gambling or retired) else 0)
                        r = min(max(r, 1), 7)
                        amt = career.cash_benefit(r) or 0
                        c.credits += int(amt); cash_taken += 1
                        self._log("Mustering cash: Cr{:,}.".format(int(amt)))
                    else:
                        r = self._d6() + (1 if s.rank >= 5 else 0)
                        r = min(max(r, 1), 7)
                        ben = career.material_benefit(r)
                        if ben:
                            res = self._apply_skill(ben, 1) if (ben.lower().startswith("+1") or ben.lower().startswith("+2")) else "ITEM"
                            if res == "ITEM":
                                c.benefits.append(ben)
                                self._log("Mustering benefit: {}.".format(ben))

        # Naming happens LAST, once the dice have decided who this person is --
        # so the name can fit the character who actually emerged. The name is
        # cosmetic (everything internal keys off the database id), and it does
        # not touch the RNG, so deterministic replay is unaffected.
        ans = yield self._decision("name_character",
                                   prompt="Name your character.",
                                   sheet=self.char.sheet())
        chosen = (ans or {}).get("name")
        if chosen and str(chosen).strip():
            self.char.name = str(chosen).strip()

        self.complete = True
        yield self._decision("complete", prompt="Character complete.",
                             sheet=self.char.sheet())
