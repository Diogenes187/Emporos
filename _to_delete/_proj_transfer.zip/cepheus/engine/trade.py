"""trade.py -- Cepheus Engine speculative trade & commerce.

Implements the speculative-trade chapter of the SRD: common and trade goods,
goods availability, and purchase/sale pricing via the Modified Price table.
Numbers come from engine/data/trade_goods.json (parsed by scripts/parse_trade.py).

Pricing (SRD "Determine Purchase Price" / "Selling Goods"):
  base skill check = 2D6 + Broker skill + (Int or Soc DM) at Average difficulty.
  PURCHASE result = check + largest applicable Purchase DM
                          - largest applicable Sale DM - supplier's Broker DM
  SALE result     = check + largest applicable Sale DM
                          - largest applicable Purchase DM - buyer's Broker DM
  The result indexes the Modified Price table for a percentage of Base Price.

Passengers, freight and mail are ship operations and live with the ships module
(SRD book 2, Off-World Travel), not here.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from . import dice
from . import tasks

_DATA = os.path.join(os.path.dirname(__file__), "data", "trade_goods.json")

# Standard Traveller trade-code abbreviations used in the goods DM columns.
TRADE_CODES = {
    "Ag": "Agricultural", "As": "Asteroid", "Ba": "Barren", "De": "Desert",
    "Fl": "Fluid Oceans", "Ga": "Garden", "Hi": "High Population",
    "Ht": "High Technology", "Ic": "Ice-Capped", "In": "Industrial",
    "Lo": "Low Population", "Lt": "Low Technology", "Na": "Non-Agricultural",
    "Ni": "Non-Industrial", "Po": "Poor", "Ri": "Rich", "Va": "Vacuum",
    "Wa": "Water World",
}

ILLEGAL_D66 = {"61", "62", "63", "64", "65"}   # black-market-only results


@dataclass
class TradeGood:
    d66: str
    name: str
    base_price: Optional[int]
    tons_expr: str
    purchase_dms: Dict[str, int]
    sale_dms: Dict[str, int]

    @property
    def illegal(self) -> bool:
        return self.d66 in ILLEGAL_D66

    def roll_tons(self) -> int:
        return roll_tons(self.tons_expr)

    def __str__(self):
        price = "Cr{:,}".format(self.base_price) if self.base_price else "special"
        return "{} [{}] {}/ton".format(self.name, self.d66, price)


def roll_tons(expr: str) -> int:
    """Parse and roll a tonnage expression like '1D6×5', '2D6', '4D6x5'."""
    expr = expr.replace("×", "x").replace("X", "x").strip()
    m = re.match(r"(\d+)D6(?:\s*x\s*(\d+))?", expr, re.I)
    if not m:
        return 0
    n = int(m.group(1))
    mult = int(m.group(2)) if m.group(2) else 1
    return dice.roll(n) * mult


def _load():
    raw = json.load(open(_DATA, encoding="utf-8"))
    goods = {}
    for g in raw["trade_goods"]:
        goods[g["d66"]] = TradeGood(
            d66=g["d66"], name=g["name"], base_price=g["base_price"],
            tons_expr=g["tons"], purchase_dms=g["purchase_dms"],
            sale_dms=g["sale_dms"])
    return goods, raw["common_goods"], raw["price_table"]


TRADE_GOODS, COMMON_GOODS, _PRICE_TABLE = _load()


def _price_pct(result: int, column: str) -> int:
    """Look up the Modified Price table (column 'purchase' or 'sale')."""
    if result <= 2:
        key = "2-"
    elif result >= 16:
        key = "16+"
    else:
        key = str(result)
    return _PRICE_TABLE[key][column]


def _best_dm(dms: Dict[str, int], world_codes: List[str]) -> int:
    applicable = [dm for code, dm in dms.items() if code in world_codes]
    return max(applicable) if applicable else 0


def good_by_d66(d66: str) -> TradeGood:
    return TRADE_GOODS[d66]


def available_goods(world_codes: List[str], black_market: bool = False,
                    count: Optional[int] = None) -> List[TradeGood]:
    """A supplier's stock: all common goods are always available; here we return
    the randomly-determined Trade Goods (roll D66, 1D6 of them by default).

    Illegal goods (61-65) are skipped unless black_market is True. A black-market
    supplier also always stocks illegal goods matching the world trade codes."""
    n = count if count is not None else dice.roll(1)
    result = []
    for _ in range(n):
        d66 = "{}{}".format(dice.roll(1), dice.roll(1))
        g = TRADE_GOODS.get(d66)
        if g is None:
            continue
        if g.illegal and not black_market:
            continue
        result.append(g)
    if black_market:
        for g in TRADE_GOODS.values():
            if g.illegal:
                if _best_dm(g.purchase_dms, world_codes) or \
                   _best_dm(g.sale_dms, world_codes):
                    result.append(g)
    return result


@dataclass
class PriceQuote:
    good: TradeGood
    result: int
    percent: int
    price_per_ton: int
    check: tasks.CheckResult

    def __str__(self):
        return "{}: result {} -> {}% = Cr{:,}/ton".format(
            self.good.name, self.result, self.percent, self.price_per_ton)


def _quote(good: TradeGood, world_codes, broker_skill, char_dm,
           other_broker, buying: bool,
           difficulty=tasks.Difficulty.AVERAGE) -> PriceQuote:
    check = tasks.check(skill_dm=max(broker_skill, 0), characteristic_dm=char_dm,
                        difficulty=difficulty, unskilled=(broker_skill <= 0))
    best_pur = _best_dm(good.purchase_dms, world_codes)
    best_sale = _best_dm(good.sale_dms, world_codes)
    if buying:
        result = check.total + best_pur - best_sale - other_broker
        pct = _price_pct(result, "purchase")
    else:
        result = check.total + best_sale - best_pur - other_broker
        pct = _price_pct(result, "sale")
    base = good.base_price or 0
    return PriceQuote(good, result, pct, round(base * pct / 100), check)


def purchase_price(good: TradeGood, world_codes: List[str], broker_skill: int = 0,
                   char_dm: int = 0, supplier_broker: int = 0) -> PriceQuote:
    """Negotiate a purchase price per ton (SRD Determine Purchase Price)."""
    return _quote(good, world_codes, broker_skill, char_dm, supplier_broker,
                  buying=True)


def sale_price(good: TradeGood, world_codes: List[str], broker_skill: int = 0,
               char_dm: int = 0, buyer_broker: int = 0) -> PriceQuote:
    """Negotiate a sale price per ton at the destination (SRD Selling Goods)."""
    return _quote(good, world_codes, broker_skill, char_dm, buyer_broker,
                  buying=False)


def goods_names() -> List[str]:
    return [g.name for g in TRADE_GOODS.values()]

# --- the port board ---------------------------------------------------------
# SRD Trade and Commerce, "Local Brokers": hire one to negotiate for you and
# use THEIR skill instead of yours, for a commission -- payable even if you
# walk away. What is available is capped by the class of starport.
LOCAL_BROKERS = {1: 5, 2: 10, 3: 15, 4: 20}      # skill -> commission %
BROKER_CAP_BY_PORT = {"A": 4, "B": 3, "C": 2, "D": 1, "E": 1, "X": 0}


def brokers_available(starport: str):
    """Which local brokers this port can actually offer, with commission."""
    cap = BROKER_CAP_BY_PORT.get(str(starport or "X").upper(), 0)
    return [{"skill": lvl, "commission_pct": LOCAL_BROKERS[lvl]}
            for lvl in sorted(LOCAL_BROKERS) if lvl <= cap]


def world_bias(good: TradeGood, world_codes: List[str]) -> Dict[str, int]:
    """The DETERMINISTIC half of a price: what this world's trade codes do to
    this good, before anybody rolls anything. This is a fact about the place,
    knowable from the map, and it is what makes a trade ROUTE plannable."""
    pur = _best_dm(good.purchase_dms, world_codes)
    sale = _best_dm(good.sale_dms, world_codes)
    why_buy = [c for c in world_codes if good.purchase_dms.get(c)]
    why_sell = [c for c in world_codes if good.sale_dms.get(c)]
    return {
        "buy_dm": pur - sale,        # applied when buying here
        "sell_dm": sale - pur,       # applied when selling here
        "produced_here": why_buy,    # codes that make it cheap to buy
        "wanted_here": why_sell,     # codes that make it sell dear
    }


def board(world_codes: List[str], starport: str = "C",
          broker_skill: int = 0, char_dm: int = 0,
          stock: Optional[List[TradeGood]] = None) -> Dict[str, Any]:
    """A trader's-eye view of one port. Availability and the day's asking
    prices are ROLLED (once, by the caller's dice, receipted); the bias is
    computed and permanent."""
    goods = stock if stock is not None else available_goods(world_codes)
    seen, offers = set(), []
    for g in goods:
        if g.d66 in seen or not g.base_price:
            continue
        seen.add(g.d66)
        q = purchase_price(g, world_codes, broker_skill=broker_skill,
                           char_dm=char_dm)
        bias = world_bias(g, world_codes)
        offers.append({
            "d66": g.d66, "good": g.name, "base_price": g.base_price,
            "tons_available": roll_tons(g.tons_expr),
            "asking_per_ton": q.price_per_ton, "percent_of_base": q.percent,
            "roll": q.check.roll.dice, "result": q.result,
            "illegal": g.illegal, **bias,
        })
    offers.sort(key=lambda o: o["percent_of_base"])

    # What this port pays dear for -- the "what should I bring back" list.
    demand = []
    for g in TRADE_GOODS.values():
        if not g.base_price or g.illegal:
            continue
        b = world_bias(g, world_codes)
        if b["sell_dm"] > 0:
            demand.append({"d66": g.d66, "good": g.name,
                           "base_price": g.base_price, **b})
    demand.sort(key=lambda d: -d["sell_dm"])
    return {"codes": list(world_codes), "starport": starport,
            "on_offer": offers, "pays_dear_for": demand[:10],
            "brokers": brokers_available(starport)}
