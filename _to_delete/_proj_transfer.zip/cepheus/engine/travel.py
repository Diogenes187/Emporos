"""travel.py -- interstellar travel, run by the engine, per the Cepheus SRD.

Travel is arithmetic and dice, not narration, so the engine owns all of it and
the referee only describes what already happened. Every rule here is cited to
the SRD text in reference/srd/:

  * Jump fuel = 0.1 x hull tonnage x parsecs.        (book2 ship-design, L215)
  * Power plant burns 1/3 of its tonnage per week.   (book2 ship-design, L217)
  * Jumps under one parsec still count as Jump-1 for
    navigation and fuel.                             (book2 off-world, L66)
  * Jump Plot: Easy (+4) EDU-based Navigation check,
    DM = -(jump distance). Fail -> replot or misjump. (book2 off-world, L62)
  * Divert power: Average (+0) EDU-based Engineering
    check; its Effect aids the Jump Success Roll.     (book2 off-world, L64)
  * Jump Success Roll: 2D6; <=0 misjump, 8+ accurate,
    otherwise inaccurate. -2 unrefined fuel, -2 per
    jump drive hit, -8 inside the 100-diameter limit. (book2 off-world, L68-75)
  * Jump takes 148+6D6 hours; inaccurate arrival adds
    1D6 days in normal space.                         (book2 off-world, L66,79)
  * Misjump: 1D6x1D6 parsecs in a random direction,
    plus the equivalent of a critical hit.            (book2 off-world, L79-81)
  * Refined Cr500/ton at class A/B; unrefined Cr100/ton
    at A/B/C; gas giants and hydro-1+ water are free
    unrefined fuel.                                   (book2 off-world, L174-186)

Nothing here talks to the web layer or the model: callers pass a repo and get
back a plain result dict with a full roll trail for the log.
"""
from __future__ import annotations

import json
import math
import re
from typing import Any, Dict, List, Optional

from . import dice, hexes
from .characteristics import modifier as char_dm
from .tasks import Difficulty, check as task_check

# Fuel prices, SRD off-world-travel "Fuel".
REFINED_PRICE = 500
UNREFINED_PRICE = 100
REFINED_PORTS = ("A", "B")
UNREFINED_PORTS = ("A", "B", "C")


# --- ship fuel ------------------------------------------------------------

def jump_fuel(tonnage: int, parsecs: int) -> int:
    """SRD: 0.1 x hull tonnage x jump distance. Sub-parsec jumps count as 1."""
    return int(math.ceil(0.1 * int(tonnage or 0) * max(1, int(parsecs))))


def fuel_capacity(ship_class: Optional[str], tonnage: int,
                  jump_rating: int) -> int:
    """Tankage. Prefer the class's own published figure (the SRD common-vessel
    descriptions state it); otherwise one full jump plus two weeks of plant."""
    try:
        from . import ships as ships_mod
        design = ships_mod.ship(ship_class)
        m = re.search(r"[Ff]uel tankage of ([\d.]+) tons",
                      getattr(design, "description", "") or "")
        if m:
            return int(round(float(m.group(1))))
    except Exception:
        pass
    t = int(tonnage or 0)
    return jump_fuel(t, max(1, int(jump_rating or 1))) + max(1, int(t * 0.02))


# --- crew ------------------------------------------------------------------

def _skill_of(row, *names) -> int:
    try:
        sk = json.loads(row["skills_json"] or "{}")
    except Exception:
        return -1
    best = -1
    for k, v in sk.items():
        for n in names:
            if n.lower() in k.lower():
                try:
                    best = max(best, int(v))
                except (TypeError, ValueError):
                    pass
    return best


def _edu_dm(row) -> int:
    """EDU is the 5th characteristic of the UPP."""
    upp = (row["upp"] or "").strip()
    if len(upp) < 5:
        return 0
    try:
        from .pseudohex import from_pseudohex
        return char_dm(from_pseudohex(upp[4]))
    except Exception:
        return 0


def _best_crew(repo, campaign_id, crew_rows, *skills):
    """Whoever aboard is best at this. Returns (row, skill, edu_dm) or
    (None, -1, 0) when nobody has a level in it -- the caller then eats the
    SRD's unskilled DM."""
    best, best_lvl = None, -1
    for r in crew_rows:
        lvl = _skill_of(r, *skills)
        if lvl > best_lvl:
            best, best_lvl = r, lvl
    if best is None:
        return None, -1, 0
    return best, best_lvl, _edu_dm(best)


# --- the jump ---------------------------------------------------------------

def plan(repo, campaign_id: int, ship_row, origin_hex: str) -> Dict[str, Any]:
    """Everything reachable from here: the engine's answer to 'where can we go'."""
    tonnage = int(ship_row["tonnage"] or 0)
    rating = int(ship_row["jump"] or 0)
    fuel = int(ship_row["fuel"] or 0)
    out = []
    if rating > 0 and origin_hex:
        reach = set(hexes.within(origin_hex, rating))
        for w in repo.list_worlds(campaign_id):
            if w["hex"] not in reach:
                continue
            d = hexes.distance(origin_hex, w["hex"])
            need = jump_fuel(tonnage, d)
            out.append({
                "name": w["name"], "hex": w["hex"], "uwp": w["uwp"],
                "zone": w["zone"] or "", "bases": w["bases"] or "",
                "parsecs": d, "bearing": hexes.bearing(origin_hex, w["hex"]),
                "fuel_needed": need, "fuel_ok": fuel >= need,
                "starport": (w["uwp"] or "X")[0].upper(),
            })
    out.sort(key=lambda x: (x["parsecs"], x["name"]))
    return {"origin": origin_hex, "jump_rating": rating, "fuel": fuel,
            "fuel_capacity": int(ship_row["fuel_capacity"] or 0)
            if "fuel_capacity" in ship_row.keys() else 0,
            "destinations": out}


def _roll(label, notation, trail):
    r = dice.roll_notation(notation)
    trail.append("{}: {} {} = {}".format(label, notation, r.dice, r.total))
    return r


def jump(repo, campaign_id: int, ship_row, dest_row, crew_rows,
         inside_100d: bool = False, drive_hits: int = 0) -> Dict[str, Any]:
    """Run the full SRD jump procedure. Returns a result dict; the caller
    persists nothing -- this decides, the caller records."""
    trail: List[str] = []
    tonnage = int(ship_row["tonnage"] or 0)
    rating = int(ship_row["jump"] or 0)
    fuel = int(ship_row["fuel"] or 0)
    origin = repo.hex_from_location(campaign_id, ship_row["location_hex"])
    if not origin:
        return {"refused": True, "reason":
                "{} has no known position; place it first.".format(
                    ship_row["name"])}
    dist = hexes.distance(origin, dest_row["hex"])
    if dist is None:
        return {"refused": True, "reason": "cannot measure that course."}
    if dist == 0:
        return {"refused": True, "reason": "you are already there."}
    if dist > rating:
        return {"refused": True, "reason":
                "{} is Jump-{}; {} is {} away. Out of range -- plot an "
                "intermediate world.".format(ship_row["name"], rating,
                                             dest_row["name"],
                                             hexes.bearing(origin, dest_row["hex"])),
                "parsecs": dist, "jump_rating": rating}
    need = jump_fuel(tonnage, dist)
    if fuel < need:
        return {"refused": True, "reason":
                "{} needs {}t of fuel for {} parsec{} and has {}t. Refuel "
                "first.".format(ship_row["name"], need, dist,
                                "" if dist == 1 else "s", fuel),
                "fuel_needed": need, "fuel": fuel}

    unrefined = bool(ship_row["fuel_refined"] == 0
                     if "fuel_refined" in ship_row.keys() else False)

    # 1. THE PLOT -- Easy (+4) EDU-based Navigation, DM = -(jump distance).
    nav, nav_lvl, nav_edu = _best_crew(repo, campaign_id, crew_rows,
                                       "navigation", "astrogation")
    nav_res = task_check(characteristic_dm=nav_edu,
                         skill_dm=max(nav_lvl, 0),
                         difficulty=Difficulty.EASY,
                         other_dm=-dist,
                         unskilled=(nav_lvl < 0))
    trail.append("Jump plot [{}, Easy +4, DM-{} for distance]: {} = {} vs 8+ "
                 "-- {}".format(nav["name"] if nav else "unskilled", dist,
                                nav_res.roll.dice, nav_res.total,
                                nav_res.degree.value))
    if not nav_res.success:
        return {"refused": True, "plot_failed": True,
                "reason": "The jump plot will not resolve -- {} cannot close "
                          "the solution. Try plotting again (a few hours "
                          "lost), or buy a course tape at the port.".format(
                              nav["name"] if nav else "nobody aboard"),
                "rolls": trail, "hours_lost": dice.roll(1, 6, 0)}

    # 2. DIVERT POWER -- Average (+0) EDU-based Engineering; Effect feeds the roll.
    eng, eng_lvl, eng_edu = _best_crew(repo, campaign_id, crew_rows,
                                       "engineering", "engineer")
    eng_res = task_check(characteristic_dm=eng_edu,
                         skill_dm=max(eng_lvl, 0),
                         difficulty=Difficulty.AVERAGE,
                         unskilled=(eng_lvl < 0))
    trail.append("Divert power [{}, Average]: {} = {} vs 8+ -- {} "
                 "(effect {:+d})".format(eng["name"] if eng else "unskilled",
                                         eng_res.roll.dice, eng_res.total,
                                         eng_res.degree.value, eng_res.effect))

    # 3. THE JUMP SUCCESS ROLL.
    dms = [("engineer's effect", eng_res.effect)]
    if unrefined:
        dms.append(("unrefined fuel", -2))
    if drive_hits:
        dms.append(("jump drive damage", -2 * int(drive_hits)))
    if inside_100d:
        dms.append(("inside the 100-diameter limit", -8))
    total_dm = sum(v for _, v in dms)
    jr = dice.roll_detail(2, 6, total_dm)
    trail.append("JUMP SUCCESS ROLL: 2d6 {} {} = {} [{}]".format(
        jr.dice, "{:+d}".format(total_dm) if total_dm else "",
        jr.total, "; ".join("{} {:+d}".format(k, v) for k, v in dms) or "no DMs"))

    hours = 148 + dice.roll(6, 6, 0)
    days = int(round(hours / 24.0))
    result: Dict[str, Any] = {
        "ok": True, "parsecs": dist, "fuel_used": need,
        "bearing": hexes.bearing(origin, dest_row["hex"]),
        "origin": origin, "rolls": trail, "jump_total": jr.total,
        "hours": hours, "unrefined": unrefined,
    }

    if jr.total <= 0:
        # MISJUMP -- 1D6 x 1D6 parsecs in a random direction.
        far = dice.roll(1, 6, 0) * dice.roll(1, 6, 0)
        candidates = hexes.within(origin, far)
        ring = [h for h in candidates if hexes.distance(origin, h) == far] or candidates
        landing = ring[dice.roll_detail(1, max(1, len(ring)), 0).total - 1] if ring else origin
        trail.append("MISJUMP: 1d6x1d6 = {} parsecs, random vector -> {}".format(
            far, landing))
        known = repo.find_world_by_hex(campaign_id, landing)
        result.update({"outcome": "misjump", "misjump_parsecs": far,
                       "landing_hex": landing,
                       "landing_world": known["name"] if known else None,
                       "days": days, "critical_hit": True,
                       "summary": "MISJUMP -- {} tore out of jump {} parsecs "
                                  "off course at {}{}. Hard emergence: the "
                                  "ship takes a critical hit and everyone "
                                  "aboard is sick for hours.".format(
                                      ship_row["name"], far, landing,
                                      " (" + known["name"] + ")" if known else
                                      " -- empty space")})
        return result

    if jr.total >= 8:
        result.update({"outcome": "accurate", "days": days,
                       "landing_hex": dest_row["hex"],
                       "landing_world": dest_row["name"],
                       "summary": "Clean jump: {} arrives at {} ({}) after "
                                  "{} days.".format(ship_row["name"],
                                                    dest_row["name"],
                                                    dest_row["hex"], days)})
        return result

    extra = dice.roll(1, 6, 0)
    trail.append("Inaccurate arrival: 1d6 = {} extra days in normal space".format(extra))
    result.update({"outcome": "inaccurate", "days": days + extra,
                   "extra_days": extra,
                   "landing_hex": dest_row["hex"],
                   "landing_world": dest_row["name"],
                   "summary": "Inaccurate jump: {} breaks out far from the "
                              "mainworld and needs {} more days in normal "
                              "space to reach {}.".format(
                                  ship_row["name"], extra, dest_row["name"])})
    return result


# --- fuel -------------------------------------------------------------------

def refuel_options(world_row, ship_row) -> List[Dict[str, Any]]:
    """What fuel this world will sell or give, per the SRD."""
    if not world_row:
        return []
    uwp = (world_row["uwp"] or "").replace("-", "")
    port = (uwp[0].upper() if uwp else "X")
    opts = []
    cap = int(ship_row["fuel_capacity"] or 0) if "fuel_capacity" in ship_row.keys() else 0
    room = max(0, cap - int(ship_row["fuel"] or 0))
    if port in REFINED_PORTS:
        opts.append({"kind": "refined", "price": REFINED_PRICE, "max_tons": room,
                     "note": "Cr500/ton at a class {} port".format(port)})
    if port in UNREFINED_PORTS:
        opts.append({"kind": "unrefined", "price": UNREFINED_PRICE, "max_tons": room,
                     "note": "Cr100/ton at a class {} port -- "
                             "−2 on the jump roll".format(port)})
    pbg = world_row["pbg"] or ""
    if len(pbg) == 3 and pbg[2].isdigit() and int(pbg[2]) > 0:
        opts.append({"kind": "unrefined", "price": 0, "max_tons": room,
                     "note": "skim the gas giant -- free, 1D6 hours per 40 "
                             "tons, −2 on the jump roll"})
    try:
        from .pseudohex import from_pseudohex
        if len(uwp) > 3 and from_pseudohex(uwp[3]) >= 1:
            opts.append({"kind": "unrefined", "price": 0, "max_tons": room,
                         "note": "pump from open water or ice -- free where "
                                 "the port allows it, −2 on the jump roll"})
    except Exception:
        pass
    return opts
