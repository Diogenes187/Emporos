"""skills.py -- the Cepheus Engine skill list and cascade specializations.

Skill names and cascade specializations are taken from the SRD
(reference/srd/src/book1/skills.md). Cascade skills must have a specialization
chosen the moment a level is gained.

The career tables sometimes use slightly different spellings (e.g. 'Pilot' for
Piloting, 'Jack o' Trades' for Jack-of-All-Trades, 'Liaision' for Liaison);
ALIASES normalizes those.
"""

from __future__ import annotations

from typing import Dict, List, Optional

CASCADES: Dict[str, List[str]] = {
    "Aircraft": ["Airship", "Grav Vehicle", "Rotor Aircraft", "Winged Aircraft"],
    "Animals": ["Farming", "Riding", "Survival", "Veterinary Medicine"],
    "Gun Combat": ["Archery", "Energy Pistol", "Energy Rifle", "Shotgun",
                   "Slug Pistol", "Slug Rifle"],
    "Gunnery": ["Bay Weapons", "Heavy Weapons", "Screens", "Spinal Mounts",
                "Turret Weapons"],
    "Melee Combat": ["Natural Weapons", "Bludgeoning Weapons",
                     "Piercing Weapons", "Slashing Weapons"],
    "Sciences": ["Life Sciences", "Physical Sciences", "Social Sciences",
                 "Space Sciences"],
    "Vehicle": ["Aircraft", "Mole", "Tracked Vehicle", "Watercraft",
                "Wheeled Vehicle"],
    "Watercraft": ["Motorboats", "Ocean Ships", "Sailing Ships", "Submarine"],
}

SKILLS = {
    "Admin", "Advocate", "Aircraft", "Animals", "Archery", "Athletics",
    "Battle Dress", "Bay Weapons", "Bludgeoning Weapons", "Bribery", "Broker",
    "Carousing", "Comms", "Computer", "Demolitions", "Electronics",
    "Energy Pistol", "Energy Rifle", "Engineering", "Farming", "Gambling",
    "Grav Vehicle", "Gravitics", "Gun Combat", "Gunnery", "Heavy Weapons",
    "Jack-of-All-Trades", "Leadership", "Linguistics", "Liaison",
    "Life Sciences", "Mechanics", "Medicine", "Melee Combat", "Mole",
    "Motorboats", "Natural Weapons", "Navigation", "Ocean Ships",
    "Physical Sciences", "Piercing Weapons", "Piloting", "Recon", "Riding",
    "Rotor Aircraft", "Sciences", "Sailing Ships", "Screens", "Shotgun",
    "Slashing Weapons", "Slug Pistol", "Slug Rifle", "Social Sciences",
    "Space Sciences", "Spinal Mounts", "Steward", "Streetwise", "Submarine",
    "Survival", "Tactics", "Tracked Vehicle", "Turret Weapons", "Vehicle",
    "Veterinary Medicine", "Watercraft", "Wheeled Vehicle", "Winged Aircraft",
    "Zero-G", "Airship",
    # Granted by career tables but not given their own entry in the Skills
    # chapter -- a known SRD inconsistency. Kept so the engine accepts every
    # skill the careers can actually award.
    "Prospecting", "Perception",
}

ALIASES = {
    "Pilot": "Piloting",
    "Liaision": "Liaison",      # SRD spelling slip in some career tables
    "Jack o' Trades": "Jack-of-All-Trades",
    "Jack o'Trades": "Jack-of-All-Trades",
    "JoT": "Jack-of-All-Trades",
    "Zero G": "Zero-G",
}


def normalize(name: str) -> str:
    """Return the canonical skill name for a possibly-aliased spelling."""
    name = name.strip()
    return ALIASES.get(name, name)


def is_cascade(name: str) -> bool:
    return normalize(name) in CASCADES


def specializations(name: str) -> Optional[List[str]]:
    """Specializations for a cascade skill, or None if it isn't a cascade."""
    return CASCADES.get(normalize(name))


def is_known(name: str) -> bool:
    """Whether a name is a recognized skill (after normalization)."""
    return normalize(name) in SKILLS
