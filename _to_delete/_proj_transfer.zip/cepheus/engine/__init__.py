"""Cepheus Engine — a Python implementation of the Cepheus Engine SRD.

This package implements the open Cepheus Engine ruleset (Samardan Press,
released as Open Gaming Content under the OGL). Rules numbers are drawn from
the SRD markdown under ../reference/srd — nothing is reconstructed from memory.

Layer 1 — the rules core. Built bottom-up:
    dice            -- 2d6 and arbitrary dice, dice-notation parsing
    characteristics -- the six characteristics, UPP, characteristic DMs
    tasks           -- the 2d6 task-resolution system
"""

__version__ = "0.0.1"
