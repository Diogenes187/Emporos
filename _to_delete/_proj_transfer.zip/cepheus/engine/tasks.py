"""tasks.py -- the 2D6 task-resolution system of the Cepheus Engine.

From the SRD (Introduction, "How the Game Works" / "Difficulty and Effect"):

  * A check is 2D6 + modifiers versus a target of 8+.
  * Modifiers include the relevant characteristic DM, skill level, the
    Referee's Difficulty DM, and circumstance DMs (+/-1 each).
  * An unskilled character (no levels in the required skill) suffers DM-3.
  * Effect = (check total) - 8. It measures how well you did:

        Effect <= -6 : Exceptional failure
        Effect -1..-5: Failure
        Effect  0..+5: Success
        Effect >= +6 : Exceptional success

  * Natural 12 is not an automatic success, natural 2 is not an automatic
    failure (the SRD says so explicitly).

The Difficulty ladder (Task Difficulty table) is a DM applied to the roll:

        Simple +6, Easy +4, Routine +2, Average 0,
        Difficult -2, Very Difficult -4, Formidable -6.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from . import dice

# Target number for every check (SRD: "a target of 8+").
TARGET = 8

# Penalty for attempting a skill check with no levels in that skill (SRD).
UNSKILLED_DM = -3


class Difficulty(Enum):
    """The SRD Task Difficulty ladder. The value is the DM applied to the roll."""

    SIMPLE = 6
    EASY = 4
    ROUTINE = 2
    AVERAGE = 0
    DIFFICULT = -2
    VERY_DIFFICULT = -4
    FORMIDABLE = -6

    @property
    def dm(self) -> int:
        return self.value

    @property
    def label(self) -> str:
        return self.name.replace("_", " ").title()


class Degree(Enum):
    """Degree of success, derived from the Effect (SRD Effect Range table)."""

    EXCEPTIONAL_FAILURE = "Exceptional failure"
    FAILURE = "Failure"
    SUCCESS = "Success"
    EXCEPTIONAL_SUCCESS = "Exceptional success"


def degree_for_effect(effect: int) -> Degree:
    """Map an Effect value to its Degree of success (SRD table)."""
    if effect <= -6:
        return Degree.EXCEPTIONAL_FAILURE
    if effect < 0:
        return Degree.FAILURE
    if effect < 6:
        return Degree.SUCCESS
    return Degree.EXCEPTIONAL_SUCCESS


@dataclass
class CheckResult:
    """The outcome of a single check, with a full breakdown for the log."""

    roll: dice.RollResult            # the underlying 2D6 roll
    characteristic_dm: int = 0
    skill_dm: int = 0
    difficulty_dm: int = 0
    other_dm: int = 0                # circumstance / help / hindrance
    unskilled: bool = False

    @property
    def modifier_total(self) -> int:
        return (
            self.characteristic_dm
            + self.skill_dm
            + self.difficulty_dm
            + self.other_dm
            + (UNSKILLED_DM if self.unskilled else 0)
        )

    @property
    def total(self) -> int:
        """The final check result: 2D6 natural + all modifiers."""
        return self.roll.natural + self.modifier_total

    @property
    def effect(self) -> int:
        """Effect = total - 8."""
        return self.total - TARGET

    @property
    def degree(self) -> Degree:
        return degree_for_effect(self.effect)

    @property
    def success(self) -> bool:
        return self.effect >= 0

    def __str__(self) -> str:
        return (
            "2D6 {dice} {mod:+d} = {total} vs {target}+ -> "
            "{deg} (Effect {eff:+d})".format(
                dice=self.roll.dice,
                mod=self.modifier_total,
                total=self.total,
                target=TARGET,
                deg=self.degree.value,
                eff=self.effect,
            )
        )


def check(
    characteristic_dm: int = 0,
    skill_dm: int = 0,
    difficulty: Difficulty = Difficulty.AVERAGE,
    other_dm: int = 0,
    unskilled: bool = False,
    roll: Optional[List[int]] = None,
) -> CheckResult:
    """Make a Cepheus task check: roll 2D6 and apply all DMs vs target 8+.

    Arguments:
        characteristic_dm -- the relevant characteristic's DM
        skill_dm          -- levels in the relevant skill (0 if untrained)
        difficulty        -- a Difficulty from the ladder (default Average / +0)
        other_dm          -- net circumstance DM (help +1 each, hindrance -1)
        unskilled         -- True if the actor has no levels in the skill (DM-3)
        roll              -- supply [d1, d2] to use dice thrown by hand at the
                             player's own table instead of the engine's RNG
    """
    if roll:
        faces = [int(x) for x in roll][:2]
        if len(faces) != 2 or not all(1 <= f <= 6 for f in faces):
            raise ValueError("a hand-rolled check needs two d6 faces, 1-6")
        r = dice.RollResult(dice=faces, sides=6, modifier=0)
    else:
        r = dice.roll_detail(2)
    return CheckResult(
        roll=r,
        characteristic_dm=characteristic_dm,
        skill_dm=skill_dm,
        difficulty_dm=difficulty.dm,
        other_dm=other_dm,
        unskilled=unskilled,
    )


@dataclass
class OpposedResult:
    """Outcome of an opposed check between two actors (SRD: highest Effect wins)."""

    a: CheckResult
    b: CheckResult
    winner: Optional[str]            # "a", "b", or None when a re-roll is needed
    tie_break: str = ""              # explanation of how a tie was resolved

    def __str__(self) -> str:
        return "A:[{}]  B:[{}]  winner={}{}".format(
            self.a, self.b, self.winner,
            " ({})".format(self.tie_break) if self.tie_break else "",
        )


def opposed(
    a: CheckResult,
    b: CheckResult,
    a_characteristic: Optional[int] = None,
    b_characteristic: Optional[int] = None,
) -> OpposedResult:
    """Resolve an opposed check (SRD Opposed Checks).

    "the character who obtains the highest Effect wins. For ties on opposed
    checks, the character with the highest relevant characteristic score wins.
    If the characters tie on characteristic scores, they reroll."

    Pass the two relevant characteristic *scores* to resolve Effect ties. If
    they are not supplied (or also tie), winner is None to signal a re-roll.
    """
    if a.effect > b.effect:
        return OpposedResult(a, b, "a")
    if b.effect > a.effect:
        return OpposedResult(a, b, "b")

    # Effect tie -> compare relevant characteristic scores, if provided.
    if a_characteristic is not None and b_characteristic is not None:
        if a_characteristic > b_characteristic:
            return OpposedResult(a, b, "a", "tie on Effect, higher characteristic")
        if b_characteristic > a_characteristic:
            return OpposedResult(a, b, "b", "tie on Effect, higher characteristic")

    return OpposedResult(a, b, None, "tie on Effect and characteristic; reroll")
