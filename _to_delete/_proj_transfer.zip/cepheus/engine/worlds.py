"""worlds.py -- Cepheus Engine world & sector generation.

Implements the SRD 'Worlds' chapter (book 3): the Universal World Profile (UWP),
trade classifications, bases, planetoid-belt/gas-giant presence (PBG), and
travel zones, plus subsector/sector generation.

The trade-classification codes produced here (Ag, In, Ht, ...) are exactly the
2-letter codes consumed by trade.py, so a generated world plugs straight into
the trade and travel systems.

All numbers and conditions come straight from the SRD worlds chapter.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from . import dice
from .pseudohex import to_pseudohex

# --- Tech-level DMs by characteristic value (SRD Technology Level table) -----
_SIZE_TL = {0: 2, 1: 2, 2: 1, 3: 1, 4: 1}
_ATMO_TL = {0: 1, 1: 1, 2: 1, 3: 1, 10: 1, 11: 1, 12: 1, 13: 1, 14: 1, 15: 1}
_HYDRO_TL = {0: 1, 9: 1, 10: 2}
_POP_TL = {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 9: 1, 10: 2}
_GOV_TL = {0: 1, 5: 1, 7: 2, 13: -2, 14: -2}
_STARPORT_TL = {"A": 6, "B": 4, "C": 2, "X": -4}

# Starport class by (2D6-7 + population) result.
_STARPORT_TABLE = {2: "X", 3: "E", 4: "E", 5: "D", 6: "D", 7: "C", 8: "C",
                   9: "B", 10: "B"}   # 11+ -> A


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _starport(pop: int) -> str:
    r = dice.roll(2) - 7 + pop
    if r >= 11:
        return "A"
    if r <= 2:
        return "X"
    return _STARPORT_TABLE[r]


def _tech_level(starport, size, atmo, hydro, pop, gov) -> int:
    tl = dice.roll(1)
    tl += _STARPORT_TL.get(starport, 0)
    tl += _SIZE_TL.get(size, 0)
    tl += _ATMO_TL.get(atmo, 0)
    tl += _HYDRO_TL.get(hydro, 0)
    tl += _POP_TL.get(pop, 0)
    tl += _GOV_TL.get(gov, 0)
    tl = max(tl, 0)
    # Minimum TL conditions (apply the highest that applies).
    minimums = [0]
    if hydro in (0, 10) and pop >= 6:
        minimums.append(4)
    if atmo in (4, 7, 9):
        minimums.append(5)
    if atmo <= 3 or atmo in (10, 11, 12):
        minimums.append(7)
    if atmo in (13, 14) and hydro == 10:
        minimums.append(7)
    return max(tl, *minimums)


# --- Trade classifications (SRD UWP Values for Trade Codes table) ------------

def trade_codes(size, atmo, hydro, pop, gov, law, tl) -> List[str]:
    codes = []
    if 4 <= atmo <= 9 and 4 <= hydro <= 8 and 5 <= pop <= 7:
        codes.append("Ag")
    if size == 0 and atmo == 0 and hydro == 0:
        codes.append("As")
    if pop == 0 and gov == 0 and law == 0:
        codes.append("Ba")
    if atmo >= 2 and hydro == 0:
        codes.append("De")
    if atmo >= 10 and hydro >= 1:
        codes.append("Fl")
    if atmo in (5, 6, 8) and 4 <= hydro <= 9 and 4 <= pop <= 8:
        codes.append("Ga")
    if pop >= 9:
        codes.append("Hi")
    if tl >= 12:
        codes.append("Ht")
    if atmo in (0, 1) and hydro >= 1:
        codes.append("Ic")
    if atmo in (0, 1, 2, 4, 7, 9) and pop >= 9:
        codes.append("In")
    if 1 <= pop <= 3:
        codes.append("Lo")
    if tl <= 5:
        codes.append("Lt")
    if atmo <= 3 and hydro <= 3 and pop >= 6:
        codes.append("Na")
    if 4 <= pop <= 6:
        codes.append("Ni")
    if 2 <= atmo <= 5 and hydro <= 3:
        codes.append("Po")
    if atmo in (6, 8) and 6 <= pop <= 8:
        codes.append("Ri")
    if hydro == 10:
        codes.append("Wa")
    if atmo == 0:
        codes.append("Va")
    return codes


# --- Bases / PBG / zones -----------------------------------------------------

def _bases(starport) -> Dict[str, bool]:
    naval = starport in ("A", "B") and dice.roll(2) >= 8
    scout = False
    if starport not in ("E", "X"):
        dm = {"C": -1, "B": -2, "A": -3}.get(starport, 0)
        scout = dice.roll(2) + dm >= 7
    pirate = (starport != "A" and not naval and dice.roll(2) >= 12)
    return {"naval": naval, "scout": scout, "pirate": pirate}


def _base_code(b: Dict[str, bool]) -> str:
    if b["naval"] and b["scout"]:
        return "A"
    if b["scout"] and b["pirate"]:
        return "G"
    if b["naval"]:
        return "N"
    if b["pirate"]:
        return "P"
    if b["scout"]:
        return "S"
    return " "


def _pbg(pop: int) -> str:
    pop_mod = dice.roll(2) - 2
    pop_mod = 0 if pop == 0 else max(pop_mod, 1)
    belts = 0
    if dice.roll(2) >= 4:
        belts = max(dice.roll(1) - 3, 1)
    gas = 0
    if dice.roll(2) >= 5:
        gas = max(dice.roll(1) - 2, 1)
    return "{}{}{}".format(_clamp(pop_mod, 0, 9), _clamp(belts, 0, 9),
                           _clamp(gas, 0, 9))


def _travel_zone(atmo, gov, law) -> str:
    if atmo >= 10 or gov in (0, 7, 10) or law == 0 or law >= 9:
        return "A"      # Amber candidate (Red is Referee discretion)
    return ""


# --- World -------------------------------------------------------------------

@dataclass
class World:
    name: str = "Unnamed"
    starport: str = "X"
    size: int = 0
    atmosphere: int = 0
    hydrographics: int = 0
    population: int = 0
    government: int = 0
    law_level: int = 0
    tech_level: int = 0
    bases: str = " "
    pbg: str = "000"
    travel_zone: str = ""
    allegiance: str = "Na"
    codes: List[str] = field(default_factory=list)

    @property
    def uwp(self) -> str:
        return "{}{}{}{}{}{}{}-{}".format(
            self.starport,
            to_pseudohex(self.size), to_pseudohex(self.atmosphere),
            to_pseudohex(self.hydrographics), to_pseudohex(self.population),
            to_pseudohex(self.government), to_pseudohex(self.law_level),
            to_pseudohex(self.tech_level))

    def __str__(self):
        return "{:<12} {} {:<2} {} {}".format(
            self.name, self.uwp, self.bases.strip() or "-",
            " ".join(self.codes), self.travel_zone or "")


def generate_world(name: str = "Unnamed") -> World:
    """Generate a single world per the SRD worlds chapter."""
    size = dice.roll(2) - 2
    atmo = 0 if size == 0 else _clamp(dice.roll(2) - 7 + size, 0, 15)

    if size in (0, 1):
        hydro = 0
    else:
        hdm = 0
        if atmo in (0, 1, 10, 11, 12):
            hdm = -4
        elif atmo == 14:
            hdm = -2
        hydro = _clamp(dice.roll(2) - 7 + size + hdm, 0, 10)

    pdm = 0
    if size <= 2:
        pdm -= 1
    if atmo >= 10:
        pdm -= 2
    if atmo == 6:
        pdm += 3
    elif atmo in (5, 8):
        pdm += 1
    if hydro == 0 and atmo < 3:
        pdm -= 2
    pop = _clamp(dice.roll(2) - 2 + pdm, 0, 10)

    if pop == 0:
        gov = law = 0
    else:
        gov = _clamp(dice.roll(2) - 7 + pop, 0, 15)
        law = max(dice.roll(2) - 7 + gov, 0) if gov else 0

    starport = _starport(pop)
    tl = 0 if pop == 0 else _tech_level(starport, size, atmo, hydro, pop, gov)

    bases = _bases(starport)
    w = World(
        name=name, starport=starport, size=size, atmosphere=atmo,
        hydrographics=hydro, population=pop, government=gov, law_level=law,
        tech_level=tl, bases=_base_code(bases), pbg=_pbg(pop),
        travel_zone=_travel_zone(atmo, gov, law),
        codes=trade_codes(size, atmo, hydro, pop, gov, law, tl))
    return w


# --- Sector / subsector generation ------------------------------------------

# Standard subsector grid: 8 columns x 10 rows. A world is present on a 4+.
def generate_subsector(present_on: int = 4, namer=None) -> Dict[str, World]:
    """Generate one subsector (8x10 hexes). Each hex has a world on 2D6>=present_on."""
    worlds = {}
    for col in range(1, 9):
        for row in range(1, 11):
            if dice.roll(2) >= present_on:
                hx = "{:02d}{:02d}".format(col, row)
                name = namer(hx) if namer else "World-{}".format(hx)
                worlds[hx] = generate_world(name)
    return worlds


def render_sec(worlds: Dict[str, World]) -> str:
    """Render worlds in a legacy .SEC-like listing (Name Hex UWP Bases Codes Zone)."""
    lines = ["{:<12} {:<4} {:<9} {:<2} {:<20} {}".format(
        "Name", "Hex", "UWP", "B", "Remarks", "Z")]
    for hx, w in sorted(worlds.items()):
        lines.append("{:<12} {:<4} {} {:<2} {:<20} {}".format(
            w.name[:12], hx, w.uwp, w.bases.strip() or "-",
            " ".join(w.codes), w.travel_zone or ""))
    return "\n".join(lines)
