"""careers.py -- load and model the 24 Cepheus careers.

The numeric career data lives in engine/data/careers.json, generated from the
SRD by scripts/parse_careers.py. This module wraps that data in a Career object
with helpers for the various throws (qualification, survival, etc.) and the
skill / benefit tables.

A "throw" in the SRD is written like 'Int 8+' (roll 2D6 + Int DM, need 8+) or
'6+' for reenlistment (a flat 2D6 target with no characteristic). parse_throw
turns those strings into a (characteristic, target) pair.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from .characteristics import Characteristic

_DATA = os.path.join(os.path.dirname(__file__), "data", "careers.json")

# Careers without a commission/advancement hierarchy: they roll TWICE on the
# skill tables each term instead (SRD, "Skills and Training").
NO_COMMISSION = {
    "Athlete", "Barbarian", "Belter", "Drifter", "Entertainer", "Hunter",
    "Scout",
}

# The six skill/benefit table keys.
SKILL_TABLES = ["personal_development", "service", "specialist",
                "advanced_education"]

_CHAR_BY_ABBR = {c.value: c for c in Characteristic}


def parse_throw(throw: Optional[str]) -> Tuple[Optional[Characteristic], Optional[int]]:
    """Parse a throw string into (characteristic, target).

    'Int 8+'  -> (Characteristic.INT, 8)
    '6+'      -> (None, 6)
    None / '' -> (None, None)
    """
    if not throw:
        return (None, None)
    m = re.match(r"^([A-Za-z]{3})?\s*(\d+)\+?$", throw.strip())
    if not m:
        return (None, None)
    char = _CHAR_BY_ABBR.get(m.group(1)) if m.group(1) else None
    target = int(m.group(2))
    return (char, target)


@dataclass
class Career:
    name: str
    data: Dict

    # ---- throws ---------------------------------------------------------

    @property
    def qualification(self) -> Tuple[Optional[Characteristic], Optional[int]]:
        return parse_throw(self.data.get("qualification"))

    @property
    def survival(self) -> Tuple[Optional[Characteristic], Optional[int]]:
        return parse_throw(self.data.get("survival"))

    @property
    def commission(self) -> Tuple[Optional[Characteristic], Optional[int]]:
        return parse_throw(self.data.get("commission"))

    @property
    def advancement(self) -> Tuple[Optional[Characteristic], Optional[int]]:
        return parse_throw(self.data.get("advancement"))

    @property
    def reenlistment_target(self) -> Optional[int]:
        return parse_throw(self.data.get("reenlistment"))[1]

    @property
    def has_commission(self) -> bool:
        return self.name not in NO_COMMISSION and self.commission[1] is not None

    @property
    def skill_rolls_per_term(self) -> int:
        """No-commission careers roll twice on the skill tables each term."""
        return 2 if self.name in NO_COMMISSION else 1

    # ---- tables ---------------------------------------------------------

    def rank(self, n: int) -> Dict[str, Optional[str]]:
        """Rank entry {title, skill} for rank n (0..6)."""
        return self.data["ranks"].get(str(n), {"title": None, "skill": None})

    def skill_table(self, table: str) -> Dict[int, Optional[str]]:
        """A skill table ('service' etc.) as {1..6: skill-or-None}."""
        return {int(k): v for k, v in self.data[table].items()}

    def available_skill_tables(self, education: int) -> List[str]:
        """Tables the character may roll on (Advanced Education needs Edu 8+)."""
        tables = ["personal_development", "service", "specialist"]
        if education >= 8:
            tables.append("advanced_education")
        return tables

    def material_benefit(self, n: int) -> Optional[str]:
        return self.data["material_benefits"].get(str(n))

    def cash_benefit(self, n: int):
        return self.data["cash_benefits"].get(str(n))


def load_careers() -> Dict[str, Career]:
    with open(_DATA, encoding="utf-8") as f:
        raw = json.load(f)
    return {name: Career(name, data) for name, data in raw.items()}


# Loaded once on import.
CAREERS: Dict[str, Career] = load_careers()


def get(name: str) -> Career:
    if name not in CAREERS:
        raise KeyError("Unknown career: {!r}".format(name))
    return CAREERS[name]


def names() -> List[str]:
    return sorted(CAREERS)
