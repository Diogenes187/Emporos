"""characteristics.py -- the six characteristics and the Universal Persona Profile.

From the Cepheus Engine SRD (Chapter 1: Character Creation):

  "Roll your six characteristics using 2D6, and record them in the standard
   order: Strength (Str), Dexterity (Dex), Endurance (End), Intelligence (Int),
   Education (Edu), and Social Standing (Soc)."

Characteristic Modifier (DM): "calculated by dividing the ability score by
three, dropping all fractions, and then subtracting two" -> floor(score/3) - 2.
The SRD's Characteristic Modifier by Score Range table is reproduced in the
tests as an authoritative cross-check on the formula.

The UPP records the six scores in pseudo-hex (0-9, then A.. skipping I and O).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List

from . import dice
from .pseudohex import to_pseudohex, from_pseudohex


class Characteristic(str, Enum):
    """The six characteristics, in standard UPP order."""

    STR = "Str"  # Strength
    DEX = "Dex"  # Dexterity
    END = "End"  # Endurance
    INT = "Int"  # Intelligence
    EDU = "Edu"  # Education
    SOC = "Soc"  # Social Standing


# Standard order used for the UPP string and most displays.
ORDER: List[Characteristic] = [
    Characteristic.STR,
    Characteristic.DEX,
    Characteristic.END,
    Characteristic.INT,
    Characteristic.EDU,
    Characteristic.SOC,
]


def modifier(score: int) -> int:
    """Characteristic DM for a score: floor(score / 3) - 2 (SRD).

    Scores are clamped at 0 for the purpose of the modifier (a score can be
    driven to 0 by injury/aging; negative scores do not occur).
    """
    if score < 0:
        score = 0
    return score // 3 - 2


@dataclass
class Characteristics:
    """A set of the six characteristic scores for a character or NPC."""

    Str: int = 7
    Dex: int = 7
    End: int = 7
    Int: int = 7
    Edu: int = 7
    Soc: int = 7

    # ---- access helpers -------------------------------------------------

    def score(self, c: Characteristic) -> int:
        return getattr(self, c.value)

    def set_score(self, c: Characteristic, value: int) -> None:
        # A characteristic floors at 0 (incapacitation) and never goes negative;
        # aging penalties on a long career can otherwise push it below zero,
        # which is both wrong by the rules and unencodable as a UPP pseudo-hex.
        setattr(self, c.value, max(0, value))

    def dm(self, c: Characteristic) -> int:
        """Characteristic DM for the given characteristic."""
        return modifier(self.score(c))

    def as_dict(self) -> Dict[str, int]:
        return {c.value: self.score(c) for c in ORDER}

    # ---- UPP ------------------------------------------------------------

    @property
    def upp(self) -> str:
        """The six scores as a pseudo-hex UPP string, e.g. '7A7964'."""
        return "".join(to_pseudohex(self.score(c)) for c in ORDER)

    @classmethod
    def from_upp(cls, upp: str) -> "Characteristics":
        """Build a Characteristics from a 6-character pseudo-hex UPP string."""
        s = upp.strip()
        if len(s) != 6:
            raise ValueError(
                "UPP must be exactly 6 characters, got {!r}".format(upp)
            )
        scores = [from_pseudohex(ch) for ch in s]
        return cls(*scores)

    # ---- generation -----------------------------------------------------

    @classmethod
    def roll(cls) -> "Characteristics":
        """Roll a fresh set: 2D6 for each of the six, in standard order."""
        return cls(*(dice.roll(2) for _ in ORDER))

    def __str__(self) -> str:
        parts = ["{} {} (DM{:+d})".format(c.value, self.score(c), self.dm(c))
                 for c in ORDER]
        return "UPP {} | ".format(self.upp) + ", ".join(parts)
