"""battle.py -- the Field Desk: a fight the engine runs and the player rolls.

The division of labour, which is the whole point:

    THE ENGINE   keeps the schedule -- who is in the fight, initiative order,
                 whose turn it is, what each attack needs, what the damage
                 was, who is still standing.
    THE PLAYER   throws the dice. Their own, at their own table, typed in --
                 or the engine's, if they'd rather.
    THE AI       is asked one question, and only when asked: what does the
                 enemy do next? It never decides whether a blow lands.

Like segments.py in the older game, this module holds NO dice of its own. Rolls
arrive from outside. Everything here is arithmetic and ordering, which means a
fight can be reloaded, audited, and replayed exactly.

Cepheus rules throughout -- 2D6 + skill + characteristic DM against 8+, Effect
adding to damage, armour subtracting from it, range bands setting difficulty.
Nothing from any d20 game got in here.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from . import combat as combat_mod
from . import equipment as eq
from .characteristics import Characteristic, Characteristics

RANGES = [r.value for r in combat_mod.Range]


def range_of(name: str) -> combat_mod.Range:
    for r in combat_mod.Range:
        if r.value.lower() == str(name or "").strip().lower():
            return r
    return combat_mod.Range.SHORT


def combatant_from_row(row, weapon: str = "Unarmed Strike",
                       armor: str = "") -> combat_mod.Combatant:
    """Build a fighting body from a character record, wounds included."""
    upp = (row["upp"] or "777777").strip()
    scores = {}
    try:
        from .pseudohex import from_pseudohex
        keys = [Characteristic.STR, Characteristic.DEX, Characteristic.END,
                Characteristic.INT, Characteristic.EDU, Characteristic.SOC]
        for i, c in enumerate(keys):
            scores[c.value] = (from_pseudohex(upp[i]) if i < len(upp) else 7)
    except Exception:
        scores = {c.value: 7 for c in (
            Characteristic.STR, Characteristic.DEX, Characteristic.END,
            Characteristic.INT, Characteristic.EDU, Characteristic.SOC)}

    chars = Characteristics(**scores)
    # Wounds already on the record come off the physical scores, so a hurt
    # crewman walks into the next fight hurt.
    try:
        dmg = int(row["damage"] or 0)
    except Exception:
        dmg = 0
    for c in (Characteristic.END, Characteristic.STR, Characteristic.DEX):
        if dmg <= 0:
            break
        cur = chars.score(c)
        take = min(cur, dmg)
        chars.set_score(c, cur - take)
        dmg -= take

    skills = {}
    try:
        import json
        skills = json.loads(row["skills_json"] or "{}")
    except Exception:
        pass

    def _weapon(nm):
        if not nm:
            return eq.UNARMED
        try:
            return eq.weapon(nm)
        except KeyError:
            low = str(nm).replace(" ", "").lower()
            for cand in eq.WEAPONS:
                if cand.replace(" ", "").lower() == low:
                    return eq.weapon(cand)
            raise KeyError(
                "unknown weapon {!r}. Try one of: {}".format(
                    nm, ", ".join(sorted(eq.WEAPONS)[:24])))

    def _armor(nm):
        if not nm:
            return None
        try:
            return eq.armor(nm)
        except KeyError:
            low = str(nm).replace(" ", "").lower().replace("armour", "armor")
            for cand in eq.ARMORS:
                if cand.replace(" ", "").lower() == low:
                    return eq.armor(cand)
            raise KeyError("unknown armour {!r}. Try one of: {}".format(
                nm, ", ".join(sorted(eq.ARMORS))))

    c = combat_mod.Combatant(
        name=row["name"],
        chars=chars,
        skills={str(k): int(v) for k, v in skills.items()},
        weapon=_weapon(weapon),
        armor=_armor(armor),
    )
    c.wounded = bool(dmg or (row["damage"] if "damage" in row.keys() else 0))
    return c


def order(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Initiative order: highest first, DEX DM breaks ties. Pure arithmetic."""
    return sorted(rows, key=lambda r: (-int(r.get("initiative") or 0),
                                       -int(r.get("dex_dm") or 0),
                                       str(r.get("name") or "")))


def next_turn(rows: List[Dict[str, Any]], turn_index: int, round_no: int):
    """Advance the schedule. Returns (turn_index, round_no, new_round).

    A round ends when everyone still standing has acted; then everyone's
    'acted' flag clears and the count goes up by one.
    """
    standing = [r for r in rows if r.get("standing")]
    if not standing:
        return turn_index, round_no, False
    for step in range(1, len(rows) + 1):
        idx = (turn_index + step) % len(rows)
        r = rows[idx]
        if r.get("standing") and not r.get("acted"):
            return idx, round_no, False
    # everybody has had their go
    first = next((i for i, r in enumerate(rows) if r.get("standing")), 0)
    return first, round_no + 1, True


def plan(attacker: combat_mod.Combatant, rng_name: str,
         other_dm: int = 0) -> Dict[str, Any]:
    """What the attack needs, before any die is thrown."""
    return combat_mod.attack_plan(attacker, range_of(rng_name), other_dm)


def resolve(attacker: combat_mod.Combatant, defender: combat_mod.Combatant,
            rng_name: str, other_dm: int = 0,
            roll: Optional[List[int]] = None,
            damage_roll: Optional[List[int]] = None) -> Dict[str, Any]:
    """One attack. `roll` is the player's own 2D6 if they threw it."""
    rng = range_of(rng_name)
    before = {c: defender.chars.score(c) for c in combat_mod.PHYSICAL}
    res = combat_mod.attack(attacker, defender, rng, other_dm=other_dm,
                            roll=roll, damage_roll=damage_roll)
    if res.check is None:
        return {"ok": False, "reason": res.note}
    after = {c: defender.chars.score(c) for c in combat_mod.PHYSICAL}
    return {
        "ok": True,
        "attacker": attacker.name,
        "defender": defender.name,
        "weapon": (attacker.weapon or eq.UNARMED).name,
        "range": rng.value,
        "difficulty": res.difficulty.label if res.difficulty else None,
        "roll": res.check.roll.dice,
        "total": res.check.total,
        "target": 8,
        "hit": res.hit,
        "effect": res.check.effect,
        "damage": res.damage,
        "armor": defender.armor.ar if defender.armor else 0,
        "defender_conscious": defender.conscious,
        "defender_alive": defender.alive,
        "characteristics_lost": {c.value: before[c] - after[c]
                                 for c in combat_mod.PHYSICAL
                                 if before[c] != after[c]},
        "line": "{} attacks {} with {} [{} {} = {} vs 8+] -- {}{}".format(
            attacker.name, defender.name,
            (attacker.weapon or eq.UNARMED).name,
            res.difficulty.label if res.difficulty else "",
            res.check.roll.dice, res.check.total,
            "HIT for {} damage".format(res.damage) if res.hit else "miss",
            "" if defender.conscious else
            (" -- {} is DOWN".format(defender.name) if defender.alive
             else " -- {} is DEAD".format(defender.name))),
    }
