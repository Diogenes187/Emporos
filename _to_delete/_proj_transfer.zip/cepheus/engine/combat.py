"""combat.py -- Cepheus Engine personal combat.

Implements the personal-combat chapter of the SRD: range bands, initiative,
attack resolution (built on the 2D6 task system in tasks.py), damage with
armor, and the characteristic-damage rules for wounding, unconsciousness and
death.

Attack rolls (SRD):
  Melee:    2D6 + melee skill + (Str or Dex DM, attacker's choice)
  Shooting: 2D6 + gun skill   + Dex DM
  Thrown:   2D6 + Athletics    + Dex DM
The Difficulty comes from the weapon's class crossed with the range band
(RANGE_DIFFICULTY). Damage = weapon D6 + Effect, reduced by armor; a hit with
Effect 6+ always inflicts at least 1 point regardless of armor.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

from . import dice
from . import tasks
from . import equipment as eq
from .tasks import Difficulty
from .characteristics import Characteristics, Characteristic


class Range(Enum):
    PERSONAL = "Personal"
    CLOSE = "Close"
    SHORT = "Short"
    MEDIUM = "Medium"
    LONG = "Long"
    VERY_LONG = "Very Long"
    DISTANT = "Distant"


# Weapon class x range band -> Difficulty (SRD Range table). Missing entry means
# the weapon cannot attack at that range.
_D = Difficulty
RANGE_DIFFICULTY: Dict[str, Dict[Range, Difficulty]] = {
    "close quarters": {Range.PERSONAL: _D.AVERAGE, Range.CLOSE: _D.DIFFICULT},
    "extended reach": {Range.PERSONAL: _D.DIFFICULT, Range.CLOSE: _D.AVERAGE},
    "thrown": {Range.CLOSE: _D.AVERAGE, Range.SHORT: _D.DIFFICULT,
               Range.MEDIUM: _D.DIFFICULT},
    "pistol": {Range.PERSONAL: _D.DIFFICULT, Range.CLOSE: _D.AVERAGE,
               Range.SHORT: _D.AVERAGE, Range.MEDIUM: _D.DIFFICULT,
               Range.LONG: _D.VERY_DIFFICULT},
    "rifle": {Range.PERSONAL: _D.VERY_DIFFICULT, Range.CLOSE: _D.DIFFICULT,
              Range.SHORT: _D.AVERAGE, Range.MEDIUM: _D.AVERAGE,
              Range.LONG: _D.AVERAGE, Range.VERY_LONG: _D.DIFFICULT,
              Range.DISTANT: _D.VERY_DIFFICULT},
    "shotgun": {Range.PERSONAL: _D.DIFFICULT, Range.CLOSE: _D.AVERAGE,
                Range.SHORT: _D.DIFFICULT, Range.MEDIUM: _D.DIFFICULT,
                Range.LONG: _D.VERY_DIFFICULT},
    "assault weapon": {Range.PERSONAL: _D.DIFFICULT, Range.CLOSE: _D.AVERAGE,
                       Range.SHORT: _D.AVERAGE, Range.MEDIUM: _D.AVERAGE,
                       Range.LONG: _D.DIFFICULT, Range.VERY_LONG: _D.VERY_DIFFICULT,
                       Range.DISTANT: _D.FORMIDABLE},
    "rocket": {Range.PERSONAL: _D.VERY_DIFFICULT, Range.CLOSE: _D.DIFFICULT,
               Range.SHORT: _D.DIFFICULT, Range.MEDIUM: _D.AVERAGE,
               Range.LONG: _D.AVERAGE, Range.VERY_LONG: _D.DIFFICULT,
               Range.DISTANT: _D.VERY_DIFFICULT},
}

PHYSICAL = [Characteristic.END, Characteristic.STR, Characteristic.DEX]

# Map a weapon to its relevant skill specialization (SRD skill list).
_MELEE_TYPE_SKILL = {"B": "Bludgeoning Weapons", "P": "Piercing Weapons",
                     "S": "Slashing Weapons"}
_GUN_BY_CLASS_TYPE = {
    ("pistol", "P"): "Slug Pistol", ("pistol", "E"): "Energy Pistol",
    ("rifle", "P"): "Slug Rifle", ("rifle", "E"): "Energy Rifle",
    ("shotgun", "P"): "Shotgun", ("assault weapon", "P"): "Slug Rifle",
}


def relevant_skill(skills: Dict[str, int], w: eq.Weapon) -> Tuple[str, int]:
    """Return (skill_name, level) for attacking with weapon w given a skills dict."""
    if w.name == "Unarmed Strike":
        return ("Natural Weapons", skills.get("Natural Weapons", 0))
    if w.is_melee:
        # P/S means either; pick whichever the attacker has higher.
        types = (w.type or "").replace("/", " ").split()
        best_name, best_lvl = "Melee Combat", -1
        for t in types:
            nm = _MELEE_TYPE_SKILL.get(t)
            if nm and skills.get(nm, 0) >= best_lvl:
                best_name, best_lvl = nm, skills.get(nm, 0)
        return (best_name, max(best_lvl, 0))
    if w.is_thrown:
        return ("Athletics", skills.get("Athletics", 0))
    if w.category in ("heavy",):
        return ("Heavy Weapons", skills.get("Heavy Weapons", 0))
    cls = w.primary_class()
    if cls == "assault weapon" and (w.type or "") == "P":
        nm = "Slug Rifle"
    else:
        nm = _GUN_BY_CLASS_TYPE.get((cls, w.type or "P"))
    if cls == "rifle" and w.name == "Bow":   # Bow listed as assault weapon class
        nm = "Archery"
    if "assault weapon" in w.classes and w.name == "Bow":
        nm = "Archery"
    nm = nm or "Gun Combat"
    return (nm, skills.get(nm, 0))


@dataclass
class Combatant:
    name: str
    chars: Characteristics
    skills: Dict[str, int] = field(default_factory=dict)
    weapon: Optional[eq.Weapon] = None
    armor: Optional[eq.Armor] = None
    initiative: int = 0
    conscious: bool = True
    alive: bool = True
    wounded: bool = False
    log: List[str] = field(default_factory=list)

    @classmethod
    def from_character(cls, char, weapon_name="Unarmed Strike", armor_name=None):
        return cls(
            name=char.name,
            chars=Characteristics(**char.chars.as_dict()),
            skills=dict(char.skills),
            weapon=eq.weapon(weapon_name),
            armor=eq.armor(armor_name) if armor_name else None,
        )

    def phys_at_zero(self) -> int:
        return sum(1 for c in PHYSICAL if self.chars.score(c) <= 0)

    def take_damage(self, amount: int) -> int:
        """Apply `amount` damage per SRD rules. Returns damage actually dealt."""
        if amount <= 0:
            return 0
        dealt = 0
        # First wound: Endurance first, overflow to Str/Dex then remaining.
        if not self.wounded:
            order = [Characteristic.END, Characteristic.STR, Characteristic.DEX]
            self.wounded = True
        else:
            # Subsequent: spread to the highest remaining physical (survive longer).
            order = sorted(PHYSICAL, key=lambda c: -self.chars.score(c))
        for c in order:
            if amount <= 0:
                break
            cur = self.chars.score(c)
            if cur <= 0:
                continue
            applied = min(cur, amount)
            self.chars.set_score(c, cur - applied)
            amount -= applied
            dealt += applied
        # Status.
        zeros = self.phys_at_zero()
        if zeros >= 3:
            self.alive = False
            self.conscious = False
            self.log.append("  {} is DEAD".format(self.name))
        elif zeros >= 2:
            self.conscious = False
            self.log.append("  {} falls UNCONSCIOUS".format(self.name))
        return dealt


def initiative(c: Combatant, prepared: bool = False, tactics_effect: int = 0) -> int:
    """Roll initiative: 2D6 + Dex DM (prepared/ambush = auto 12)."""
    natural = 12 if prepared else dice.roll(2)
    c.initiative = natural + c.chars.dm(Characteristic.DEX) + tactics_effect
    return c.initiative


@dataclass
class AttackResult:
    hit: bool
    check: tasks.CheckResult
    damage: int = 0
    difficulty: Optional[Difficulty] = None
    note: str = ""

    def __str__(self):
        if self.note:
            return self.note
        return "{} (Effect {:+d}) -> {} damage".format(
            "HIT" if self.hit else "MISS", self.check.effect, self.damage)


def attack_plan(attacker: Combatant, rng: Range = Range.SHORT,
                other_dm: int = 0) -> Dict[str, object]:
    """What this attack NEEDS before any die is thrown -- so a player can be
    told 'you need 8+, you have +3' and then roll their own dice."""
    w = attacker.weapon or eq.UNARMED
    cls = w.primary_class()
    diff_map = RANGE_DIFFICULTY.get(cls, {})
    difficulty = diff_map.get(rng)
    skill_name, skill_lvl = relevant_skill(attacker.skills, w)
    unskilled = skill_lvl <= 0 and skill_name not in attacker.skills
    if w.is_melee and not w.is_thrown:
        cdm = max(attacker.chars.dm(Characteristic.STR),
                  attacker.chars.dm(Characteristic.DEX))
    else:
        cdm = attacker.chars.dm(Characteristic.DEX)
    total = (cdm + max(skill_lvl, 0) + (difficulty.dm if difficulty else 0)
             + other_dm + (tasks.UNSKILLED_DM if unskilled else 0))
    return {"weapon": w.name, "can_attack": difficulty is not None,
            "difficulty": difficulty.label if difficulty else None,
            "skill": skill_name, "skill_level": max(skill_lvl, 0),
            "characteristic_dm": cdm, "unskilled": unskilled,
            "other_dm": other_dm, "total_dm": total,
            "damage_dice": w.damage_dice or 0,
            "needs": "{}+ on 2D6 with {:+d}".format(tasks.TARGET, total)}


def attack(attacker: Combatant, defender: Combatant, rng: Range = Range.SHORT,
           other_dm: int = 0, roll=None, damage_roll=None) -> AttackResult:
    """Resolve one attack from attacker against defender at the given range.
    Pass `roll=[d1,d2]` to use dice the player threw at their own table."""
    w = attacker.weapon or eq.UNARMED
    cls = w.primary_class()
    diff_map = RANGE_DIFFICULTY.get(cls, {})
    if rng not in diff_map:
        return AttackResult(False, None, 0, None,
                            note="{} cannot attack at {} range".format(
                                w.name, rng.value))
    difficulty = diff_map[rng]

    skill_name, skill_lvl = relevant_skill(attacker.skills, w)
    unskilled = skill_lvl <= 0 and skill_name not in attacker.skills

    # Characteristic DM: melee uses better of Str/Dex; ranged/thrown use Dex.
    if w.is_melee and not w.is_thrown:
        cdm = max(attacker.chars.dm(Characteristic.STR),
                  attacker.chars.dm(Characteristic.DEX))
    else:
        cdm = attacker.chars.dm(Characteristic.DEX)

    res = tasks.check(characteristic_dm=cdm, skill_dm=max(skill_lvl, 0),
                      difficulty=difficulty, other_dm=other_dm,
                      unskilled=unskilled, roll=roll)
    if not res.success:
        return AttackResult(False, res, 0, difficulty)

    # Damage = weapon D6 + Effect, then armor reduction.
    dice_n = w.damage_dice or 0
    if damage_roll:
        raw = sum(int(x) for x in damage_roll)
    else:
        raw = dice.roll(dice_n) if dice_n else 0
    raw += res.effect
    ar = defender.armor.ar if defender.armor else 0
    dmg = raw - ar
    if res.effect >= 6 and dmg < 1:
        dmg = 1     # Effect 6+ always inflicts at least 1 (SRD)
    dmg = max(dmg, 0)
    dealt = defender.take_damage(dmg)
    return AttackResult(True, res, dealt, difficulty)


def duel(a: Combatant, b: Combatant, rng: Range = Range.SHORT,
         max_rounds: int = 50, verbose: bool = False) -> Combatant:
    """Run a simple fight to the finish. Returns the surviving/standing combatant."""
    initiative(a)
    initiative(b)
    order = sorted([a, b], key=lambda c: (-c.initiative,
                                          -c.chars.dm(Characteristic.DEX)))
    rounds = 0
    while a.conscious and b.conscious and rounds < max_rounds:
        rounds += 1
        for attacker in order:
            defender = b if attacker is a else a
            if not attacker.conscious or not defender.conscious:
                continue
            r = attack(attacker, defender, rng)
            if verbose:
                print("R{} {} vs {}: {}".format(rounds, attacker.name,
                                                defender.name, r))
    winner = a if a.conscious else b
    return winner
