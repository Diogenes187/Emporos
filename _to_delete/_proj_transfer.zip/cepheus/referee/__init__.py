"""referee/ -- the LLM (or human) game-master layer for Cepheus campaigns.

The referee is a *role* over the tool API: an LLM, a human using the tools, or a
hybrid can fill it. Built model-agnostic ("AI Pagan" -- pick your deity per
session) on the OpenAI-compatible chat/tool-calling protocol, default
DeepSeek V4-Flash. Everything funnels through the state repo, so the database
stays the source of truth.
"""
