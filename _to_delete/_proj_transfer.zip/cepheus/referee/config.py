"""config.py -- model/provider configuration for the referee.

Default deity: DeepSeek V4-Flash via the OpenAI-compatible API. Swappable to
Ollama, OpenRouter, OpenAI, or any compatible endpoint with one config change.
API keys are read from the environment, never hard-coded.
"""
from __future__ import annotations

import dataclasses
import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class ModelConfig:
    provider: str = "deepseek"
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-v4-flash"    # DeepSeek's cheap/fast chat model
    api_key_env: str = "DEEPSEEK_API_KEY"
    temperature: float = 0.7
    # 1200 was too tight for reasoning-mode models: the chain of thought can
    # eat the whole budget before any actual reply is written, which came back
    # as EMPTY content -- blank narration on every player's screen. Give the
    # reply room to land after the thinking.
    max_tokens: int = 4000

    @property
    def api_key(self) -> Optional[str]:
        return os.environ.get(self.api_key_env)


# Preset providers -- all OpenAI-compatible, so one client class serves them all.
PRESETS = {
    "deepseek": ModelConfig(provider="deepseek",
                            base_url="https://api.deepseek.com/v1",
                            model="deepseek-v4-flash",
                            api_key_env="DEEPSEEK_API_KEY"),
    "deepseek-pro": ModelConfig(provider="deepseek",
                                base_url="https://api.deepseek.com/v1",
                                model="deepseek-v4-pro",
                                api_key_env="DEEPSEEK_API_KEY"),
    "openrouter": ModelConfig(provider="openrouter",
                              base_url="https://openrouter.ai/api/v1",
                              model="deepseek/deepseek-chat",
                              api_key_env="OPENROUTER_API_KEY"),
    "kimi": ModelConfig(provider="moonshot",
                        base_url="https://api.moonshot.ai/v1",
                        model="kimi-k2.6", api_key_env="MOONSHOT_API_KEY"),
    "ollama": ModelConfig(provider="ollama",
                          base_url="http://localhost:11434/v1",
                          model="qwen3", api_key_env="OLLAMA_API_KEY"),
    "openai": ModelConfig(provider="openai",
                          base_url="https://api.openai.com/v1",
                          model="gpt-4o-mini", api_key_env="OPENAI_API_KEY"),
}


def get_config(provider: str = "deepseek") -> ModelConfig:
    """Return a preset, with CEPHEUS_MODEL as an escape hatch.

    Providers rename their models without warning (DeepSeek retired the
    'deepseek-chat' alias mid-campaign). Setting CEPHEUS_MODEL overrides the
    model name for whatever provider is in play, so a rename is a one-line
    `fly secrets set` instead of a code change and a redeploy.
    """
    cfg = PRESETS.get(provider, PRESETS["deepseek"])
    override = os.environ.get("CEPHEUS_MODEL", "").strip()
    if override:
        cfg = dataclasses.replace(cfg, model=override)
    return cfg
