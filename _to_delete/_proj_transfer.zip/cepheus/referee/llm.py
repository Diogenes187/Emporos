"""llm.py -- the model-agnostic LLM client (the "AI Pagan" adapter).

One interface, many gods. OpenAICompatibleClient speaks the chat/tool-calling
protocol shared by DeepSeek, Ollama, OpenRouter, Moonshot/Kimi and OpenAI, so
swapping models is a config change. ScriptedClient returns pre-programmed
responses for offline tests (no network/key needed).
"""
from __future__ import annotations

import json
import urllib.request
import urllib.error
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .config import ModelConfig, get_config


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: Dict[str, Any]


@dataclass
class LLMResponse:
    text: Optional[str] = None
    tool_calls: List[ToolCall] = field(default_factory=list)

    @property
    def wants_tools(self) -> bool:
        return bool(self.tool_calls)


class LLMClient(ABC):
    """A chat model that can request tool calls."""

    @abstractmethod
    def chat(self, messages: List[Dict[str, Any]],
             tools: Optional[List[Dict[str, Any]]] = None) -> LLMResponse:
        ...


class OpenAICompatibleClient(LLMClient):
    """Works against any OpenAI-compatible /chat/completions endpoint."""

    def __init__(self, config: Optional[ModelConfig] = None, timeout: int = 60):
        self.config = config or get_config("deepseek")
        self.timeout = timeout

    def chat(self, messages, tools=None) -> LLMResponse:
        key = self.config.api_key
        if not key and self.config.provider != "ollama":
            raise RuntimeError(
                "No API key found in ${} -- set it to use the {} provider.".format(
                    self.config.api_key_env, self.config.provider))
        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        req = urllib.request.Request(
            self.config.base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer {}".format(key or "ollama")},
            method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8")[:300]
            except Exception:
                pass
            hint = ""
            if e.code in (401, 403):
                hint = (" -- the API key in ${} was rejected. Check it's valid, "
                        "has credit, and was set in the same shell that runs the "
                        "server.".format(self.config.api_key_env))
            raise RuntimeError("{} API HTTP {}{} {}".format(
                self.config.provider, e.code, hint, body))
        except urllib.error.URLError as e:
            raise RuntimeError("{} API unreachable: {}".format(
                self.config.provider, e.reason))
        return self._parse(data)

    @staticmethod
    def _parse(data: Dict[str, Any]) -> LLMResponse:
        msg = data["choices"][0]["message"]
        calls = []
        text = msg.get("content")
        # Reasoning-style models put chain-of-thought in `reasoning_content`
        # and may exhaust max_tokens before writing any `content` at all.
        # NEVER surface the raw reasoning as narration -- it reads as the
        # referee talking to itself and is usually truncated mid-thought.
        # Leave text empty; the referee's empty-reply guard retries with a
        # nudge to produce the actual narration.
        for tc in (msg.get("tool_calls") or []):
            fn = tc.get("function", {})
            args = fn.get("arguments") or "{}"
            try:
                args = json.loads(args) if isinstance(args, str) else args
            except json.JSONDecodeError:
                args = {}
            calls.append(ToolCall(id=tc.get("id", ""), name=fn.get("name", ""),
                                  arguments=args))
        return LLMResponse(text=text, tool_calls=calls)


class ScriptedClient(LLMClient):
    """Returns a fixed sequence of LLMResponses -- for tests and demos.

    `steps` is a list of LLMResponse; each chat() call returns the next one.
    """

    def __init__(self, steps: List[LLMResponse]):
        self.steps = list(steps)
        self.calls: List[Dict[str, Any]] = []

    def chat(self, messages, tools=None) -> LLMResponse:
        self.calls.append({"messages": messages, "tools": tools})
        if not self.steps:
            return LLMResponse(text="(the referee falls silent)")
        return self.steps.pop(0)


def make_client(provider: str = "deepseek") -> LLMClient:
    return OpenAICompatibleClient(get_config(provider))
