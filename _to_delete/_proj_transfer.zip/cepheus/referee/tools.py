"""tools.py -- the referee's tool schema (callable functions over repo + engine).

Mirrors the Greyhawk DM-tools pattern: every mechanical outcome goes through a
tool, and every lasting thing the referee creates -- an NPC, a ship, a world --
is written to the database, with NOTES so the living world remembers ("this
fixer burned the crew on the Regina deal", "this corvette was driven off once
before"). The model never invents dice or contradicts the database; it calls
these.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from engine import dice as dice_mod
from engine import tasks as tasks_mod
from engine import uwp as uwp_mod
from engine import hexes as hexes_mod
from engine import travel as travel_mod
from engine import chargen, worlds as worlds_mod, trade as trade_mod
from engine import ships as ships_mod
from engine import combat as combat_mod
from engine.tasks import Difficulty


@dataclass
class RefereeContext:
    repo: Any
    campaign_id: int
    rng: random.Random = None

    def __post_init__(self):
        if self.rng is None:
            self.rng = random.Random()


@dataclass
class Tool:
    name: str
    description: str
    parameters: Dict[str, Any]
    handler: Callable[..., Any]

    def spec(self) -> Dict[str, Any]:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description,
            "parameters": self.parameters}}


_DIFFICULTY = {d.label.lower(): d for d in Difficulty}
_DIFFICULTY.update({d.name.lower(): d for d in Difficulty})


def _row_to_dict(row):
    return dict(row) if row is not None else None


# --- handlers ---------------------------------------------------------------

def h_roll_dice(ctx, notation="2d6"):
    r = dice_mod.roll_notation(notation)
    out = {"notation": notation, "dice": r.dice, "modifier": r.modifier,
           "total": r.total}
    # Every roll leaves a receipt: the ledger of chance is auditable.
    ctx.repo.record_event(ctx.campaign_id, "roll",
                          "Rolled {}: {} = {}".format(notation, r.dice, r.total),
                          out)
    return out


def h_task_check(ctx, characteristic_dm=0, skill=0, difficulty="average",
                 other_dm=0, unskilled=False):
    diff = _DIFFICULTY.get(str(difficulty).lower(), Difficulty.AVERAGE)
    res = tasks_mod.check(characteristic_dm=characteristic_dm, skill_dm=skill,
                          difficulty=diff, other_dm=other_dm, unskilled=unskilled)
    out = {"roll": res.roll.dice, "total": res.total, "effect": res.effect,
           "success": res.success, "degree": res.degree.value,
           "difficulty": diff.label}
    ctx.repo.record_event(
        ctx.campaign_id, "task",
        "Task check ({}): rolled {} = {} vs 8+ -- {} (effect {:+d})".format(
            diff.label, res.roll.dice, res.total, res.degree.value, res.effect),
        out)
    return out


def _party_hex(ctx):
    """Where the crew actually stands, for relative bearings."""
    for row in list(ctx.repo.list_ships(ctx.campaign_id)) + \
            list(ctx.repo.list_characters(ctx.campaign_id, include_npcs=False)):
        h = ctx.repo.hex_from_location(ctx.campaign_id, row["location_hex"])
        if h:
            return h
    return None


def h_get_world(ctx, sector=None, hex=None, name=None):
    if name:
        row = ctx.repo.find_world(ctx.campaign_id, name)
    elif hex and not sector:
        row = ctx.repo.find_world_by_hex(ctx.campaign_id, hex)
    else:
        row = ctx.repo.get_world(ctx.campaign_id, sector, hex)
    if row is None:
        return None
    out = _row_to_dict(row)
    # Decoded, in words: the referee must never have to read pseudo-hex or
    # guess what a two-letter allegiance code stands for.
    out["decoded"] = uwp_mod.describe(row)
    here = _party_hex(ctx)
    if here and out.get("hex"):
        out["decoded"]["from_party"] = uwp_mod.bearing(here, out["hex"])
    return out


def h_list_worlds(ctx, sector=None, limit=40):
    rows = ctx.repo.list_worlds(ctx.campaign_id, sector)
    here = _party_hex(ctx)
    out = []
    for r in rows[:limit]:
        d = {"hex": r["hex"], "name": r["name"], "uwp": r["uwp"],
             "bases": r["bases"], "zone": r["zone"],
             "allegiance": uwp_mod.ALLEGIANCE.get(
                 (r["allegiance"] or "").strip(), r["allegiance"] or "")}
        if here and r["hex"]:
            d["from_party"] = uwp_mod.bearing(here, r["hex"])
        out.append(d)
    return out


def h_get_character(ctx, character_id):
    return _row_to_dict(ctx.repo.get_character(int(character_id)))


def h_list_characters(ctx, include_npcs=True):
    rows = ctx.repo.list_characters(ctx.campaign_id, include_npcs=include_npcs)
    return [{"id": r["id"], "name": r["name"], "upp": r["upp"],
             "is_npc": bool(r["is_npc"]), "status": r["status"],
             "notes": r["notes"]} for r in rows]


def h_list_ships(ctx):
    rows = ctx.repo.list_ships(ctx.campaign_id)
    return [{"id": r["id"], "name": r["name"], "class": r["ship_class"],
             "location": r["location_hex"], "notes": r["notes"]} for r in rows]


def h_generate_npc(ctx, name="NPC", terms=3, location=None, role=""):
    # One person, one record: if this name already exists in the campaign,
    # return the REAL one instead of minting a twin.
    existing = ctx.repo.find_character_by_name(ctx.campaign_id, name)
    if existing:
        return {"already_exists": True, "id": existing["id"],
                "name": existing["name"], "upp": existing["upp"],
                "status": existing["status"], "location": existing["location_hex"],
                "notes": existing["notes"],
                "referee_note": "This person already exists -- use this record "
                                "and their notes; do NOT create a duplicate."}
    chooser = chargen.RandomChooser(target_terms=int(terms))
    char = chargen.generate(name=name, chooser=chooser)
    notes = "Role: {}".format(role) if role else ""
    cid = ctx.repo.save_character(ctx.campaign_id, char, is_npc=True,
                                  location=location, notes=notes)
    return {"id": cid, "name": char.name, "upp": char.chars.upp,
            "skills": char.skills, "careers": [s.career for s in char.history],
            "role": role}


def h_create_ship(ctx, name, ship_class=None, tonnage=None, armor=0,
                  notes="", location=None):
    if ship_class and ship_class in ships_mod.SHIPS:
        design = ships_mod.ship(ship_class)
    else:
        design = ships_mod.Ship(
            name=ship_class or name, tl=None, tonnage=int(tonnage or 200),
            jump=1, maneuver_g=1, cargo_tons=None, staterooms=None,
            low_berths=None, crew=None, cost_mcr=None, high_passengers=None,
            low_passengers=None, description=notes or "ad-hoc vessel")
    sid = ctx.repo.save_ship(ctx.campaign_id, design, name=name, armor=armor,
                             location=location, notes=notes)
    return {"ship_id": sid, "name": name, "class": design.name,
            "tonnage": design.tonnage}


def h_generate_world(ctx, name="Unsurveyed", hex=None, sector=None, notes=""):
    w = worlds_mod.generate_world(name=name)
    if not sector:
        row = ctx.repo.conn.execute(
            "SELECT sector FROM world WHERE campaign_id=? LIMIT 1",
            (ctx.campaign_id,)).fetchone()
        sector = row["sector"] if row else "Spin"
    wid = None
    if hex:
        wid = ctx.repo.add_world(ctx.campaign_id, sector, hex, w.name, uwp=w.uwp,
                                 bases=w.bases, remarks=" ".join(w.codes),
                                 zone=w.travel_zone, pbg=w.pbg,
                                 allegiance=w.allegiance, source="generated",
                                 notes=notes)
    return {"name": w.name, "uwp": w.uwp, "bases": w.bases,
            "trade_codes": w.codes, "pbg": w.pbg, "zone": w.travel_zone,
            "sector": sector, "hex": hex, "world_id": wid, "saved": bool(wid)}


def h_add_note(ctx, entity_type, identifier, note):
    et = str(entity_type).lower()
    if et == "world":
        row = (ctx.repo.find_world_by_hex(ctx.campaign_id, identifier)
               or ctx.repo.find_world(ctx.campaign_id, identifier))
        table = "world"
    elif et == "ship":
        row = ctx.repo.find_ship_by_name(ctx.campaign_id, identifier)
        table = "ship"
    else:
        row = ctx.repo.find_character_by_name(ctx.campaign_id, identifier)
        table = "character"
    if not row:
        return {"error": "{} not found: {}".format(et, identifier)}
    ok = ctx.repo.append_note(table, row["id"], note)
    return {"noted": ok, "entity": et, "who": identifier, "note": note}


def _resolve_noted(ctx, entity_type, identifier):
    """(row, table) for a character/ship/world by name or hex, or (None, table)."""
    et = str(entity_type).lower()
    if et == "world":
        row = (ctx.repo.find_world_by_hex(ctx.campaign_id, identifier)
               or ctx.repo.find_world(ctx.campaign_id, identifier))
        return row, "world"
    if et == "ship":
        return ctx.repo.find_ship_by_name(ctx.campaign_id, identifier), "ship"
    return ctx.repo.find_character_by_name(ctx.campaign_id, identifier), "character"


def h_remove_note(ctx, entity_type, identifier, contains):
    """Remove a note added by mistake -- the companion to add_note. Matches
    part of the note's text and drops the whole line(s) it appears in."""
    row, table = _resolve_noted(ctx, entity_type, identifier)
    if not row:
        return {"error": "{} not found: {}".format(str(entity_type).lower(),
                                                    identifier)}
    if not (contains or "").strip():
        return {"error": "say which note to remove -- give part of its text to "
                         "match (an empty match would take them all)"}
    removed, remaining = ctx.repo.remove_note(table, row["id"], contains)
    if not removed:
        return {"removed": 0, "entity": table, "who": identifier,
                "note": "no note matched {!r} -- nothing removed".format(contains)}
    return {"removed": len(removed), "removed_lines": removed,
            "remaining": remaining, "entity": table, "who": identifier}


def h_set_character_status(ctx, character_id, status, alive=None):
    ctx.repo.update_character_status(int(character_id), status, alive)
    return {"character_id": int(character_id), "status": status, "alive": alive}


def _wound_capacity(row):
    """How much a body can take. Characters: STR+DEX+END off the UPP.
    Creatures: the Hits value rolled at creation (in the statline)."""
    import re as _re
    m = _re.search(r"Hits (\d+)", row["notes"] or "")
    if m:
        return int(m.group(1))
    upp = (row["upp"] or "").strip()
    try:
        from engine.pseudohex import from_pseudohex
        return sum(from_pseudohex(c) for c in upp[:3])
    except Exception:
        return 21          # an average 777 body, if the record is odd


def h_apply_damage(ctx, target, amount, source=""):
    """Wounds live on the RECORD, not in prose. Positive = damage,
    negative = healing. The engine derives status from the numbers."""
    try:
        row = ctx.repo.get_character(int(target))
    except (TypeError, ValueError):
        row = ctx.repo.find_character_by_name(ctx.campaign_id, str(target))
    if not row:
        return {"error": "no such character/creature: {}".format(target)}
    try:
        amount = int(amount)
    except (TypeError, ValueError):
        return {"error": "amount must be an integer (+damage / -healing)"}
    cap = _wound_capacity(row)
    try:
        old = int(row["damage"] or 0)
    except (KeyError, IndexError):
        old = 0
    new = max(0, old + amount)
    is_beast = (row["upp"] or "") == "beast"
    if new >= cap:
        status, alive = ("dead", 0) if is_beast else ("incapacitated", 1)
    elif new >= (cap + 1) // 2:
        status, alive = "seriously wounded", 1
    elif new > 0:
        status, alive = "wounded", 1
    else:
        status, alive = "ok", 1
    ctx.repo.conn.execute(
        "UPDATE character SET damage=?, status=?, alive=? WHERE id=?",
        (new, status, alive, row["id"]))
    ctx.repo.conn.commit()
    verb = ("takes {} damage".format(amount) if amount >= 0
            else "heals {}".format(-amount))
    ctx.repo.record_event(
        ctx.campaign_id, "combat",
        "{} {}{} -- {}/{} wounds, {}".format(
            row["name"], verb,
            " ({})".format(source) if source else "", new, cap, status))
    return {"id": row["id"], "name": row["name"], "amount": amount,
            "damage": new, "capacity": cap, "remaining": max(0, cap - new),
            "status": status, "alive": bool(alive),
            "referee_note": ("They are DOWN -- at or past capacity."
                             if new >= cap else "")}


def h_generate_creature(ctx, name, size="medium", ferocity="predator",
                        weapon=None, traits=None, location=None, role=""):
    """Roll up a beast with LIVE dice and save it as a permanent campaign
    record. One beast, one record: wound it, note it, meet it again."""
    existing = ctx.repo.find_character_by_name(ctx.campaign_id, name)
    if existing:
        return {"already_exists": True, "id": existing["id"],
                "name": existing["name"], "status": existing["status"],
                "location": existing["location_hex"], "notes": existing["notes"],
                "referee_note": "This creature already exists -- use this "
                                "record and its notes; do NOT roll a twin."}
    from engine import creatures as creatures_mod
    try:
        cr = creatures_mod.generate(name, size=size, ferocity=ferocity,
                                    weapon=weapon, traits=traits)
    except ValueError as e:
        return {"error": str(e)}
    statline = cr.statline() + ("; Role: {}".format(role) if role else "")
    cur = ctx.repo.conn.execute(
        "INSERT INTO character(campaign_id, name, upp, is_npc, skills_json, "
        "notes, location_hex, status, alive) VALUES (?,?,?,1,?,?,?,?,1)",
        (ctx.campaign_id, name, "beast",
         json.dumps({"Natural Weapons": cr.attack_skill}),
         statline, location, "alive"))
    cid = cur.lastrowid
    ctx.repo.conn.commit()
    ctx.repo.set_character_skills(cid, {"Natural Weapons": cr.attack_skill})
    # Every roll leaves a receipt -- creature stats are auditable chance.
    ctx.repo.record_event(
        ctx.campaign_id, "roll",
        "Rolled up creature {}: ".format(name)
        + "; ".join("{} {}".format(lbl, shown) for lbl, shown in cr.rolls),
        {"creature_id": cid})
    ctx.repo.record_event(
        ctx.campaign_id, "character",
        "A creature enters the record: {} -- {}".format(name, statline))
    return {"id": cid, "name": name, "size": cr.size, "ferocity": cr.ferocity,
            "weapon": cr.weapon,
            "str": cr.strength, "dex": cr.dexterity, "end": cr.endurance,
            "hits": cr.hits, "armor": cr.armor, "armor_kind": cr.armor_kind,
            "attack_skill": cr.attack_skill, "damage": cr.damage,
            "traits": cr.traits, "location": location,
            "rolls": ["{} {}".format(lbl, shown) for lbl, shown in cr.rolls]}


def h_trade_price(ctx, good_d66=None, world_codes=None, side="buy",
                  broker_skill=0, broker=None, hex=None):
    """What a good costs or fetches.

    HERE, the answer is today's held price -- the same number the players'
    Exchange shows and the same one the till will charge, so asking twice
    cannot produce a better one. For somewhere the crew ISN'T, this is a
    projection off that world's trade codes and comes back flagged
    `indicative_only`: useful for planning a run, never a price anyone is
    bound to.
    """
    g = trade_mod.good_by_d66(str(good_d66))
    who, skill, cdm = _negotiator(ctx, broker)
    if who is False:
        return {"error": "no such broker character: {}".format(broker)}
    if broker is None:
        skill = int(broker_skill or 0)

    hexv = hex or (None if world_codes else _party_hex(ctx))
    if hexv:
        quote = held_price(ctx, hexv, g.d66, side, skill=skill, cdm=cdm)
        if quote is not None:
            return {"good": g.name, "side": side, "hex": hexv,
                    "date": quote["date"], "codes": quote["codes"],
                    "percent": quote["percent"],
                    "price_per_ton": quote["price_per_ton"],
                    "brokered_by": who, "broker_skill": skill}

    codes = (world_codes if isinstance(world_codes, list)
             else str(world_codes or "").split())
    q = (trade_mod.sale_price if side == "sell" else trade_mod.purchase_price)(
        g, codes, broker_skill=skill, char_dm=cdm)
    return {"good": g.name, "side": side, "codes": codes, "result": q.result,
            "percent": q.percent, "price_per_ton": q.price_per_ton,
            "brokered_by": who, "broker_skill": skill,
            "indicative_only": True,
            "note": "a projection for a world the crew is not at -- plan with "
                    "it, do not quote it as a firm price"}


def h_record_event(ctx, kind, summary, detail=None):
    eid = ctx.repo.record_event(ctx.campaign_id, kind, summary, detail or {})
    return {"event_id": eid, "recorded": summary}


def h_recent_events(ctx, limit=10):
    rows = ctx.repo.events(ctx.campaign_id, limit=int(limit))
    return [{"kind": r["kind"], "summary": r["summary"]} for r in rows]


def h_mark_visited(ctx, world_id):
    ctx.repo.mark_visited(int(world_id))
    return {"world_id": int(world_id), "visited": True}


def h_set_date(ctx, date, reason=""):
    """Set the campaign date -- forward, or BACK to undo time that was taken
    without leave. The change is chronicled either way."""
    return ctx.repo.set_current_date_recorded(ctx.campaign_id, str(date), reason)


def _hex_dist(h1, h2):
    """Distance in parsecs. One implementation, engine.hexes (even-q, the way
    Traveller maps are actually drawn)."""
    return hexes_mod.distance(h1, h2)


def _advance_date_repo(repo, campaign_id, days):
    """Advance the campaign date (YYYY-DDD) by N days; returns the new date."""
    c = repo.get_campaign(campaign_id)
    raw = (c["current_date"] or "1105-001") if c else "1105-001"
    try:
        year, day = int(raw.split("-")[0]), int(raw.split("-")[1])
    except Exception:
        return raw
    day += int(days)
    while day > 365:
        day -= 365
        year += 1
    new = "{:04d}-{:03d}".format(year, day)
    repo.set_current_date(campaign_id, new)
    return new


def _advance_date(ctx, days):
    """Advance the campaign date (YYYY-DDD) by N days; returns the new date."""
    c = ctx.repo.get_campaign(ctx.campaign_id)
    raw = (c["current_date"] or "1105-001") if c else "1105-001"
    try:
        year, day = int(raw.split("-")[0]), int(raw.split("-")[1])
    except Exception:
        return raw
    day += int(days)
    while day > 365:
        day -= 365
        year += 1
    new = "{:04d}-{:03d}".format(year, day)
    ctx.repo.set_current_date(ctx.campaign_id, new)
    return new


def _execute_jump(repo, campaign_id, ship, dest, crew_ids=None,
                  inside_100d=False):
    """THE one jump path. The web UI and the referee tool both come here, so
    they cannot disagree about the rules. Runs the SRD procedure, persists the
    outcome, records the receipts, returns the result."""
    crew = [repo.get_character(int(c)) for c in (crew_ids or [])]
    crew = [c for c in crew if c]
    if not crew:      # nobody named? everyone standing where the ship stands
        here = repo.hex_from_location(campaign_id, ship["location_hex"])
        crew = [c for c in repo.list_characters(campaign_id, include_npcs=False)
                if here and repo.hex_from_location(campaign_id,
                                                   c["location_hex"]) == here]
    res = travel_mod.jump(repo, campaign_id, ship, dest, crew,
                          inside_100d=inside_100d)
    if not res.get("ok"):
        if res.get("rolls"):      # a failed plot still burned real dice
            repo.record_event(campaign_id, "roll",
                              "Jump attempt: " + "; ".join(res["rolls"]))
        return res

    # Every roll leaves a receipt.
    repo.record_event(campaign_id, "roll",
                      "Jump procedure: " + "; ".join(res["rolls"]))

    landing_hex = res["landing_hex"]
    landed = (dest if landing_hex == dest["hex"]
              else repo.find_world_by_hex(campaign_id, landing_hex))
    loc = ("{} ({})".format(landed["name"], landing_hex) if landed
           else "deep space ({})".format(landing_hex))
    repo.conn.execute("UPDATE ship SET location_hex=?, fuel=MAX(0, fuel-?) "
                      "WHERE id=?", (loc, res["fuel_used"], ship["id"]))
    moved = []
    for c in crew:
        repo.conn.execute("UPDATE character SET location_hex=? WHERE id=?",
                          (loc, c["id"]))
        moved.append(c["name"])
    repo.conn.commit()
    if landed:
        repo.mark_visited(landed["id"])

    days = int(res.get("days") or 7)
    new_date = _advance_date_repo(repo, campaign_id, days)
    repo.record_event(
        campaign_id, "travel",
        "{} -- {}t fuel burned{}. Date now {}.".format(
            res["summary"], res["fuel_used"],
            " Crew: " + ", ".join(moved) if moved else "", new_date))

    ship_now = repo.get_ship(ship["id"])
    res.update({
        "ship": ship["name"], "crew_moved": moved, "date": new_date,
        "fuel_remaining": int(ship_now["fuel"] or 0),
        "location": loc,
        "to": ({"name": landed["name"], "hex": landed["hex"],
                "uwp": landed["uwp"], "decoded": uwp_mod.describe(landed),
                "notes": landed["notes"] or ""} if landed else
               {"name": None, "hex": landing_hex,
                "note": "empty space -- no charted world here"}),
    })
    return res


def h_jump_ship(ctx, ship_id, destination, crew_ids=None):
    """Jump a ship. The ENGINE runs the whole SRD procedure -- navigation
    plot, divert power, jump success roll, fuel, misjumps -- and you narrate
    what it returns. Never describe a jump you did not call."""
    ship = ctx.repo.get_ship(int(ship_id))
    if not ship:
        return {"error": "no such ship: {}".format(ship_id)}
    dest = (ctx.repo.find_world(ctx.campaign_id, str(destination))
            or ctx.repo.find_world_by_hex(ctx.campaign_id, str(destination)))
    if not dest:
        return {"error": "no such world in this campaign: {}".format(destination),
                "referee_note": "look it up with get_world/list_worlds, or chart "
                                "it with generate_world first"}
    return _execute_jump(ctx.repo, ctx.campaign_id, ship, dest, crew_ids)


def h_jump_options(ctx, ship_id):
    """Everywhere this ship can actually reach right now, with real distances,
    bearings and fuel costs. Read this before promising a player anything."""
    ship = ctx.repo.get_ship(int(ship_id))
    if not ship:
        return {"error": "no such ship: {}".format(ship_id)}
    origin = ctx.repo.hex_from_location(ctx.campaign_id, ship["location_hex"])
    plan = travel_mod.plan(ctx.repo, ctx.campaign_id, ship, origin)
    plan["ship"] = ship["name"]
    return plan


def h_refuel_ship(ctx, ship_id, tons=None, kind="refined", payer="party"):
    """Buy or skim fuel at the ship's current world, by the SRD's prices and
    availability. Refuses what the port cannot sell or the payer cannot buy."""
    ship = ctx.repo.get_ship(int(ship_id))
    if not ship:
        return {"error": "no such ship: {}".format(ship_id)}
    here = ctx.repo.hex_from_location(ctx.campaign_id, ship["location_hex"])
    world = ctx.repo.find_world_by_hex(ctx.campaign_id, here) if here else None
    if not world:
        return {"error": "no charted world here -- nothing to refuel from"}
    opts = travel_mod.refuel_options(world, ship)
    want = str(kind).lower()
    # cheapest first: never charge for fuel a gas giant is giving away
    matches = sorted([o for o in opts if o["kind"] == want],
                     key=lambda o: o["price"])
    match = matches[0] if matches else None
    if not match:
        return {"refused": True, "reason":
                "{} offers no {} fuel. Available: {}".format(
                    world["name"], want,
                    "; ".join("{} at Cr{}/t".format(o["kind"], o["price"])
                              for o in opts) or "nothing")}
    cap = int(ship["fuel_capacity"] or 0)
    room = max(0, cap - int(ship["fuel"] or 0))
    take = room if tons in (None, "", 0) else min(int(tons), room)
    if take <= 0:
        return {"refused": True, "reason": "{}'s tanks are already full "
                                           "({}/{}t).".format(ship["name"],
                                                              ship["fuel"], cap)}
    cost = take * int(match["price"])
    char, funds, label = _resolve_pocket(ctx, payer)
    if char is False:
        return {"error": "no such payer: {}".format(payer)}
    if cost > funds:
        return {"refused": True, "reason":
                "{}t of {} fuel costs Cr{:,}; {} has Cr{:,}.".format(
                    take, want, cost, label, funds),
                "cost": cost, "funds": funds}
    if cost:
        if char is not None:
            ctx.repo.adjust_character_credits(char["id"], -cost)
        else:
            ctx.repo.record_transaction(
                ctx.campaign_id, -cost, "fuel",
                "{}t {} fuel at {}".format(take, want, world["name"]))
    refined = 1 if want == "refined" and int(ship["fuel"] or 0) == 0 else (
        0 if want == "unrefined" else int(ship["fuel_refined"] or 1))
    ctx.repo.conn.execute(
        "UPDATE ship SET fuel=MIN(?, fuel+?), fuel_refined=? WHERE id=?",
        (cap, take, refined, ship["id"]))
    ctx.repo.conn.commit()
    now = ctx.repo.get_ship(ship["id"])
    ctx.repo.record_event(
        ctx.campaign_id, "trade",
        "{} took on {}t of {} fuel at {}{} -- tanks {}/{}t".format(
            ship["name"], take, want, world["name"],
            " for Cr{:,}".format(cost) if cost else " (free)",
            now["fuel"], cap))
    return {"ok": True, "ship": ship["name"], "tons": take, "kind": want,
            "cost": cost, "paid_by": label if cost else "nobody -- free",
            "fuel": int(now["fuel"]), "capacity": cap,
            "refined": bool(refined),
            "note": match["note"]}


def h_set_location(ctx, entity_type, entity_id, location):
    """Freeform local movement -- docking bays, cities, aboard-ship, orbit.
    No rules to enforce, so none are: narrate freely, record truthfully."""
    et = str(entity_type).lower()
    table = "ship" if et == "ship" else "character"
    row = ctx.repo.conn.execute(
        "SELECT id, name, location_hex FROM {} WHERE id=?".format(table),
        (int(entity_id),)).fetchone()
    if not row:
        return {"error": "no such {}: {}".format(table, entity_id)}
    loc = str(location).strip()
    # The hex must survive prose. 'Luna Highport, Bay 12' keeps its (1914),
    # inherited from the text itself or from where they already were --
    # otherwise the party silently falls off the map.
    import re as _re
    if not _re.search(r"\b\d{4}\b", loc):
        hx = (ctx.repo.hex_from_location(ctx.campaign_id, loc)
              or ctx.repo.hex_from_location(ctx.campaign_id, row["location_hex"]))
        if hx:
            loc = "{} ({})".format(loc, hx)
    ctx.repo.conn.execute(
        "UPDATE {} SET location_hex=? WHERE id=?".format(table),
        (loc, int(entity_id)))
    ctx.repo.conn.commit()
    return {"ok": True, "type": table, "name": row["name"], "location": loc}


def h_adjust_credits(ctx, character_id, delta, reason=""):
    """A character's personal money, kept true on the sheet itself."""
    new = ctx.repo.adjust_character_credits(int(character_id), int(delta))
    if new is None:
        return {"error": "no such character: {}".format(character_id)}
    row = ctx.repo.get_character(int(character_id))
    ctx.repo.record_event(
        ctx.campaign_id, "ledger",
        "{} {}{:,} cr{} -- balance Cr{:,}".format(
            row["name"], "+" if int(delta) >= 0 else "-", abs(int(delta)),
            " ({})".format(reason) if reason else "", new))
    return {"character_id": int(character_id), "name": row["name"],
            "delta": int(delta), "reason": reason, "new_balance": new}


def _find_good(name_or_d66):
    """Resolve a trade good by D66 code, exact name, or partial name."""
    s = str(name_or_d66).strip()
    if s in trade_mod.TRADE_GOODS:
        return trade_mod.TRADE_GOODS[s]
    low = s.lower()
    for g in trade_mod.TRADE_GOODS.values():
        if g.name.lower() == low:
            return g
    for g in trade_mod.TRADE_GOODS.values():
        if low in g.name.lower():
            return g
    return None


def _ship_capacity(ship_row):
    """Cargo capacity in tons from the ship's class; None if unknowable."""
    try:
        from engine import ships as ships_mod
        return ships_mod.ship(ship_row["ship_class"]).cargo_tons
    except Exception:
        return None


def _resolve_pocket(ctx, who):
    """'party' -> (None, party balance, 'party ledger'); otherwise a character
    by id or name -> (row, their credits, their name). (False, ...) = no such."""
    p = str(who).strip().lower()
    if p in ("", "party", "ledger", "pool"):
        return None, ctx.repo.balance(ctx.campaign_id), "party ledger"
    try:
        row = ctx.repo.get_character(int(who))
    except (TypeError, ValueError):
        row = ctx.repo.find_character_by_name(ctx.campaign_id, str(who))
    # A raw id is not proof of ownership: a pocket in another campaign is not
    # this table's to reach into.
    if row is not None and row["campaign_id"] != ctx.campaign_id:
        row = None
    if not row:
        return False, 0, str(who)
    return row, int(row["credits"] or 0), row["name"]


def _negotiator(ctx, who):
    """(name, skill, characteristic_dm) for whoever did the talking."""
    if not who:
        return None, 0, 0
    row = ctx.repo.get_character(int(who)) if str(who).isdigit() \
        else ctx.repo.find_character_by_name(ctx.campaign_id, str(who))
    if not row or row["campaign_id"] != ctx.campaign_id:
        return False, 0, 0
    skill, cdm = _trader_dm(ctx, row)
    return row["name"], skill, cdm


def h_buy_goods(ctx, good, tons, ship_id, payer="party", broker=None,
                price_per_ton=None):
    """The airtight cargo purchase: checks the payer's REAL funds and the
    ship's REAL hold, refuses what can't be paid for or carried, then moves
    the money and stows the lot in one motion.

    THE PRICE IS NOT YOURS TO SET. It comes from this port's held survey for
    today, exactly as it does for the players' Exchange -- same rule dispatch()
    already applies to dice, where a roll offered by the referee is discarded
    and the engine throws instead. A price you hand in is treated as what you
    EXPECTED; if the port disagrees, the port wins and the answer tells you so,
    so narrate from what comes back rather than from what you asked for.
    """
    g = _find_good(good)
    if not g:
        return {"error": "unknown trade good: {!r} -- use its exact name or "
                         "D66 code (see trade_price)".format(good)}
    try:
        tons = int(tons)
    except (TypeError, ValueError):
        return {"error": "tons must be an integer"}
    if tons <= 0:
        return {"error": "tons must be positive"}
    ship = ctx.repo.get_ship(int(ship_id))
    if not ship:
        return {"error": "no such ship: {}".format(ship_id)}

    who, skill, cdm = _negotiator(ctx, broker)
    if who is False:
        return {"error": "no such broker character: {}".format(broker)}
    hexv = (ctx.repo.hex_from_location(ctx.campaign_id, ship["location_hex"])
            or _party_hex(ctx))
    quote = held_price(ctx, hexv, g.d66, "buy", skill=skill, cdm=cdm)
    if quote is None:
        return {"refused": True, "reason":
                "There is no charted world at {} to buy cargo from. Cargo "
                "needs a port.".format(hexv or "this position")}
    on_quay = int(quote.get("tons_available", 0))
    if tons > on_quay:
        return {"refused": True, "tons_available": on_quay,
                "reason": "only {}t of {} left on the quay today; the crew "
                          "asked for {}t.".format(on_quay, g.name, tons)}
    price = quote["price_per_ton"]
    asked = None
    try:
        asked = int(price_per_ton) if price_per_ton is not None else None
    except (TypeError, ValueError):
        asked = None
    cost = tons * price
    cap = _ship_capacity(ship)
    held = sum(int(l["tons"]) for l in ctx.repo.list_cargo(ctx.campaign_id)
               if l["ship_id"] == ship["id"])
    if cap is not None and held + tons > cap:
        return {"refused": True, "reason":
                "{}'s hold is {}t with {}t already stowed -- no room for {}t "
                "of {}. Sell something or buy less.".format(
                    ship["name"], cap, held, tons, g.name),
                "hold_capacity": cap, "hold_used": held}
    char, funds, label = _resolve_pocket(ctx, payer)
    if char is False:
        return {"error": "no such payer character: {}".format(payer)}
    if cost > funds:
        return {"refused": True, "reason":
                "{} has Cr{:,}; {}t of {} costs Cr{:,}. The seller keeps the "
                "goods and the deal is off.".format(
                    label, funds, tons, g.name, cost),
                "funds": funds, "cost": cost}
    took = take_stock(ctx, hexv, g.d66, tons)
    if not took.get("ok"):
        return took
    lid = ctx.repo.add_cargo_lot(
        ctx.campaign_id, g.name, tons, price, ship_id=ship["id"],
        origin_hex=ctx.repo.hex_from_location(ctx.campaign_id,
                                              ship["location_hex"]))
    if char is not None:
        new = ctx.repo.adjust_character_credits(char["id"], -cost)
        ctx.repo.record_event(
            ctx.campaign_id, "ledger",
            "{} -{:,} cr (bought {}t {}) -- balance Cr{:,}".format(
                char["name"], cost, tons, g.name, new))
    else:
        ctx.repo.record_transaction(
            ctx.campaign_id, -cost, "trade",
            "Bought {}t {} @ Cr{:,}/t".format(tons, g.name, price),
            "cargo_lot", lid)
        new = ctx.repo.balance(ctx.campaign_id)
    out = {"ok": True, "cargo_lot_id": lid, "good": g.name, "tons": tons,
           "price_per_ton": price, "percent_of_base": quote["percent"],
           "cost": cost, "paid_by": label, "payer_new_balance": new,
           "brokered_by": who, "broker_skill": skill,
           "hold_used": held + tons, "hold_capacity": cap}
    if asked is not None and asked != price:
        out["quoted_price_per_ton"] = asked
        out["note"] = ("You expected Cr{:,}/ton; this port asks Cr{:,}. The "
                       "port's number is the one that was paid -- narrate "
                       "that.".format(asked, price))
    return out


def h_sell_goods(ctx, cargo, payee="party", broker=None, price_per_ton=None):
    """Sell a HELD cargo lot (by lot id or good name): credits the chosen
    pocket, marks the lot sold, and reports profit against what was paid.

    THE OFFER IS THE PORT'S, NOT YOURS -- same rule as buying. What this world
    pays for that good today comes from its held survey; a figure you hand in
    is what you EXPECTED, and if it differs the port's number is what changes
    hands. Narrate the answer, not the ask.
    """
    lots = list(ctx.repo.list_cargo(ctx.campaign_id))
    lot = None
    try:
        want = int(cargo)
        lot = next((l for l in lots if l["id"] == want), None)
    except (TypeError, ValueError):
        low = str(cargo).strip().lower()
        lot = (next((l for l in lots if l["good"].lower() == low), None)
               or next((l for l in lots if low in l["good"].lower()), None))
    if not lot:
        return {"error": "no held cargo lot matching {!r}. Held: {}".format(
            cargo, "; ".join("#{} {}t {}".format(l["id"], l["tons"], l["good"])
                             for l in lots) or "nothing -- the hold is empty")}
    char, _funds, label = _resolve_pocket(ctx, payee)
    if char is False:
        return {"error": "no such payee character: {}".format(payee)}
    who, skill, cdm = _negotiator(ctx, broker)
    if who is False:
        return {"error": "no such broker character: {}".format(broker)}
    g = next((x for x in trade_mod.TRADE_GOODS.values()
              if x.name == lot["good"]), None)
    if g is None:
        return {"error": "unknown trade good in hold: {}".format(lot["good"])}
    ship = ctx.repo.get_ship(lot["ship_id"]) if lot["ship_id"] else None
    hexv = (ctx.repo.hex_from_location(ctx.campaign_id, ship["location_hex"])
            if ship else None) or _party_hex(ctx)
    quote = held_price(ctx, hexv, g.d66, "sell", skill=skill, cdm=cdm)
    if quote is None:
        return {"refused": True, "reason":
                "There is no charted world at {} to sell to. Find a port."
                .format(hexv or "this position")}
    price = quote["price_per_ton"]
    try:
        asked = int(price_per_ton) if price_per_ton is not None else None
    except (TypeError, ValueError):
        asked = None
    ctx.repo.mark_cargo_sold(lot["id"])
    revenue = price * int(lot["tons"])
    paid = int(lot["buy_price_per_ton"] or 0) * int(lot["tons"])
    if char is not None:
        new = ctx.repo.adjust_character_credits(char["id"], revenue)
        ctx.repo.record_event(
            ctx.campaign_id, "ledger",
            "{} +{:,} cr (sold {}t {}) -- balance Cr{:,}".format(
                char["name"], revenue, lot["tons"], lot["good"], new))
        ctx.repo.record_event(
            ctx.campaign_id, "trade",
            "Sold {}t {} @ Cr{:,}/t".format(lot["tons"], lot["good"], price))
    else:
        ctx.repo.record_transaction(
            ctx.campaign_id, revenue, "trade",
            "Sold {}t {} @ Cr{:,}/t".format(lot["tons"], lot["good"], price),
            "cargo_lot", lot["id"])
        new = ctx.repo.balance(ctx.campaign_id)
    out = {"ok": True, "cargo_lot_id": lot["id"], "good": lot["good"],
           "tons": lot["tons"], "price_per_ton": price,
           "percent_of_base": quote["percent"], "revenue": revenue,
           "profit_vs_purchase": revenue - paid,
           "brokered_by": who, "broker_skill": skill,
           "paid_to": label, "payee_new_balance": new}
    if asked is not None and asked != price:
        out["quoted_price_per_ton"] = asked
        out["note"] = ("You expected Cr{:,}/ton; this port pays Cr{:,}. The "
                       "port's number is what changed hands -- narrate "
                       "that.".format(asked, price))
    return out


def h_transfer_funds(ctx, source, target, amount, reason=""):
    """Hand credits from one pocket to another -- character to character,
    character to the party ledger, or the ledger back out to somebody.

    One motion, one receipt. Before this existed the only way for one player
    to stake another was two unrelated ledger entries that happened to be the
    same size, which is not a record of a loan, it's a coincidence. Money
    that leaves one pocket must arrive in another: the two halves are written
    under the same lock, and a transfer that cannot complete moves nothing.
    """
    try:
        amount = int(amount)
    except (TypeError, ValueError):
        return {"error": "amount must be a whole number of credits"}
    if amount <= 0:
        return {"error": "amount must be positive -- to send the other way, "
                         "swap source and target"}

    src_row, src_funds, src_label = _resolve_pocket(ctx, source)
    if src_row is False:
        return {"error": "no such source pocket: {}".format(source)}
    dst_row, dst_funds, dst_label = _resolve_pocket(ctx, target)
    if dst_row is False:
        return {"error": "no such target pocket: {}".format(target)}

    same = ((src_row is None and dst_row is None)
            or (src_row is not None and dst_row is not None
                and src_row["id"] == dst_row["id"]))
    if same:
        return {"error": "{} cannot pay themselves".format(src_label)}

    if amount > src_funds:
        return {"refused": True, "reason":
                "{} has Cr{:,} and cannot hand over Cr{:,}.".format(
                    src_label, src_funds, amount),
                "funds": src_funds, "amount": amount}

    note = reason.strip() if reason else ""
    tail = " -- {}".format(note) if note else ""

    # Out of the source.
    if src_row is not None:
        src_new = ctx.repo.adjust_character_credits(src_row["id"], -amount)
        ctx.repo.record_event(
            ctx.campaign_id, "ledger",
            "{} -{:,} cr (to {}){} -- balance Cr{:,}".format(
                src_label, amount, dst_label, tail, src_new))
    else:
        ctx.repo.record_transaction(
            ctx.campaign_id, -amount, "transfer",
            "To {}{}".format(dst_label, tail))
        src_new = ctx.repo.balance(ctx.campaign_id)

    # Into the target.
    if dst_row is not None:
        dst_new = ctx.repo.adjust_character_credits(dst_row["id"], amount)
        ctx.repo.record_event(
            ctx.campaign_id, "ledger",
            "{} +{:,} cr (from {}){} -- balance Cr{:,}".format(
                dst_label, amount, src_label, tail, dst_new))
    else:
        ctx.repo.record_transaction(
            ctx.campaign_id, amount, "transfer",
            "From {}{}".format(src_label, tail))
        dst_new = ctx.repo.balance(ctx.campaign_id)

    return {"ok": True, "amount": amount, "reason": note,
            "from": src_label, "from_balance": src_new,
            "to": dst_label, "to_balance": dst_new}


def h_record_transaction(ctx, amount, kind, description=""):
    """Credits through the ledger, not through prose."""
    tid = ctx.repo.record_transaction(ctx.campaign_id, int(amount), kind,
                                      description)
    return {"transaction_id": tid, "amount": int(amount), "kind": kind,
            "description": description,
            "party_balance": ctx.repo.balance(ctx.campaign_id)}


def h_party_balance(ctx):
    return {"party_balance": ctx.repo.balance(ctx.campaign_id)}


def h_ledger(ctx, limit=20, since_seq=0):
    """Read the receipt tape back: what the engine actually did, in order,
    with any GAP in the sequence flagged."""
    rows = ctx.repo.receipts(ctx.campaign_id, limit=int(limit),
                             since_seq=int(since_seq))
    gaps = ctx.repo.receipt_gaps(ctx.campaign_id)
    return {
        "receipts": [{"seq": r["seq"], "tool": r["tool"], "author": r["author"],
                      "summary": r["summary"], "numbers": r["numbers"],
                      "ts": r["ts"]} for r in rows],
        "gaps": gaps,
        "intact": not gaps,
        "note": ("The tape is contiguous -- every mechanical act is accounted "
                 "for." if not gaps else
                 "WARNING: receipts {} are missing from the tape.".format(gaps)),
    }

def h_strike_event(ctx, event_id, reason=""):
    """Strike something from the record that should never have happened.
    The event is kept and marked struck -- an honest record shows its own
    corrections -- but it stops feeding the story and the briefing."""
    res = ctx.repo.strike_event(ctx.campaign_id, int(event_id), reason)
    if res is None:
        return {"error": "no such event in this campaign: {}".format(event_id)}
    return res


def h_strike_receipt(ctx, seq, reason=""):
    """Void a mechanical act on the receipt tape. The receipt stays (deleting
    it would open a gap, and a gap means tampering); it is marked void."""
    res = ctx.repo.strike_receipt(ctx.campaign_id, int(seq), reason)
    if res is None:
        return {"error": "no receipt #{} on this campaign's tape".format(seq)}
    return res


def h_reverse_transaction(ctx, ledger_id, reason=""):
    """Undo money: posts the exact inverse, linked to the original."""
    res = ctx.repo.reverse_transaction(ctx.campaign_id, int(ledger_id), reason)
    if res is None:
        return {"error": "no such ledger entry: {}".format(ledger_id)}
    return res


def h_add_lore(ctx, title, body="", category="fact"):
    """PROPOSE a lasting fact about the world. It is not canon yet -- the
    table decides. Narrate freely in the moment; this is how something gets
    REMEMBERED."""
    res = ctx.repo.add_lore(ctx.campaign_id, title, body, category,
                            proposed_by="referee")
    if res.get("status") == "pending":
        res["referee_note"] = ("Proposed, NOT canon. Do not treat it as "
                               "established or build further invention on it "
                               "until the table approves it.")
    return res


def h_lookup_lore(ctx, query="", include_pending=False):
    """Read the world's ESTABLISHED facts before inventing new ones."""
    rows = ctx.repo.list_lore(ctx.campaign_id)
    q = (query or "").strip().lower()
    out = []
    for r in rows:
        if r["status"] == "rejected":
            continue
        if r["status"] == "pending" and not include_pending:
            continue
        if q and q not in (r["title"] or "").lower() \
                and q not in (r["body"] or "").lower():
            continue
        out.append({"id": r["id"], "title": r["title"], "body": r["body"],
                    "category": r["category"], "status": r["status"]})
    return {"lore": out[:40], "canon_count":
            len([r for r in rows if r["status"] == "canon"]),
            "pending_count": len([r for r in rows if r["status"] == "pending"])}


# --- the Field Desk ---------------------------------------------------------

def _battle_view(ctx, b):
    from engine import battle as battle_mod
    rows = []
    for r in ctx.repo.combatants(b["id"]):
        ch = ctx.repo.get_character(r["character_id"]) if r["character_id"] else None
        standing = True
        if ch:
            standing = bool(ch["alive"]) and ch["status"] not in (
                "incapacitated", "dead", "unconscious")
        rows.append({
            "id": r["id"], "name": r["name"], "side": r["side"],
            "weapon": r["weapon"], "armor": r["armor"],
            "initiative": r["initiative"], "acted": bool(r["acted"]),
            "character_id": r["character_id"],
            "status": ch["status"] if ch else "ok",
            "damage": (ch["damage"] if ch else 0) or 0,
            "standing": standing,
        })
    rows = battle_mod.order(rows)
    idx = int(b["turn_index"] or 0)
    active = rows[idx]["name"] if 0 <= idx < len(rows) else None
    # What the active combatant NEEDS, before any die is thrown -- so nobody
    # discovers a fist cannot reach across the room by throwing dice at it.
    plan = None
    if 0 <= idx < len(rows) and rows[idx]["character_id"]:
        try:
            body = battle_mod.combatant_from_row(
                ctx.repo.get_character(rows[idx]["character_id"]),
                rows[idx]["weapon"], rows[idx]["armor"])
            plan = battle_mod.plan(body, b["range_band"])
        except Exception as e:
            plan = {"can_attack": False, "needs": str(e)}
    return {"battle_id": b["id"], "status": b["status"], "round": b["round"],
            "range": b["range_band"], "turn_index": idx, "active": active,
            "plan": plan, "combatants": rows,
            "crew_standing": sum(1 for r in rows if r["side"] == "crew" and r["standing"]),
            "foes_standing": sum(1 for r in rows if r["side"] == "foe" and r["standing"])}


def h_start_combat(ctx, combatants, range_band="Short", note=""):
    """Open a fight. Each combatant: {character_id or name, side, weapon,
    armor}. Initiative is rolled here, once, and the order is fixed."""
    from engine import battle as battle_mod
    from engine.characteristics import Characteristic
    if not combatants:
        return {"error": "a fight needs combatants"}
    bid = ctx.repo.start_battle(ctx.campaign_id, range_band, note)
    names = []
    for c in combatants:
        chid = c.get("character_id")
        row = ctx.repo.get_character(int(chid)) if chid else None
        if not row and c.get("name"):
            row = ctx.repo.find_character_by_name(ctx.campaign_id, c["name"])
        if not row:
            return {"error": "no such combatant: {}".format(
                c.get("name") or chid)}
        body = battle_mod.combatant_from_row(row, c.get("weapon") or
                                             "Unarmed Strike", c.get("armor") or "")
        init = combat_mod.initiative(body, prepared=bool(c.get("prepared")))
        ctx.repo.add_combatant(bid, row["name"], c.get("side") or "crew",
                               character_id=row["id"],
                               weapon=c.get("weapon") or "Unarmed Strike",
                               armor=c.get("armor") or "", initiative=init)
        names.append("{} (init {})".format(row["name"], init))
    ctx.repo.record_event(ctx.campaign_id, "combat",
                          "Combat begins at {} range: {}".format(
                              range_band, "; ".join(names)))
    return _battle_view(ctx, ctx.repo.get_battle(bid))


def h_combat_status(ctx):
    """Read the board: order, round, whose turn, who is still standing."""
    b = ctx.repo.active_battle(ctx.campaign_id)
    if not b:
        return {"active": False, "note": "no fight in progress"}
    return _battle_view(ctx, b)


def h_combat_attack(ctx, attacker, target, roll=None, other_dm=0):
    """Resolve one attack. Pass roll=[d1,d2] to use dice thrown by hand.
    The ENGINE decides whether it hits and what it costs."""
    from engine import battle as battle_mod
    b = ctx.repo.active_battle(ctx.campaign_id)
    if not b:
        return {"error": "no fight in progress -- call start_combat first"}
    rows = list(ctx.repo.combatants(b["id"]))

    def find(who):
        for r in rows:
            if str(who).strip().lower() in (str(r["id"]), r["name"].lower()):
                return r
        return None

    a_row, d_row = find(attacker), find(target)
    if not a_row:
        return {"error": "no combatant {!r} in this fight".format(attacker)}
    if not d_row:
        return {"error": "no combatant {!r} in this fight".format(target)}

    a_ch = ctx.repo.get_character(a_row["character_id"])
    d_ch = ctx.repo.get_character(d_row["character_id"])
    atk = battle_mod.combatant_from_row(a_ch, a_row["weapon"], a_row["armor"])
    dfn = battle_mod.combatant_from_row(d_ch, d_row["weapon"], d_row["armor"])

    res = battle_mod.resolve(atk, dfn, b["range_band"], other_dm=int(other_dm or 0),
                             roll=roll)
    if not res.get("ok"):
        return {"refused": True, "reason": res.get("reason")}

    # Wounds land in the SAME ledger as everything else.
    if res["damage"] > 0 and d_ch:
        h_apply_damage(ctx, d_ch["id"], res["damage"],
                       source="{} with {}".format(a_row["name"], res["weapon"]))
    ctx.repo.set_combatant(a_row["id"], acted=1)
    ctx.repo.record_event(ctx.campaign_id, "combat", res["line"])

    view = _battle_view(ctx, ctx.repo.get_battle(b["id"]))
    res["board"] = view
    if view["foes_standing"] == 0 or view["crew_standing"] == 0:
        res["fight_over"] = True
        res["note"] = ("No foe still standing." if view["foes_standing"] == 0
                       else "No crew still standing.")
    return res


def h_combat_next(ctx):
    """Hand the turn on. When everyone standing has acted, the round turns."""
    from engine import battle as battle_mod
    b = ctx.repo.active_battle(ctx.campaign_id)
    if not b:
        return {"error": "no fight in progress"}
    view = _battle_view(ctx, b)
    # Choosing to pass is still taking your turn: mark the current actor done,
    # or a round in which everyone declines never ends.
    cur = int(b["turn_index"] or 0)
    if 0 <= cur < len(view["combatants"]):
        ctx.repo.set_combatant(view["combatants"][cur]["id"], acted=1)
        view["combatants"][cur]["acted"] = True
    idx, rnd, new_round = battle_mod.next_turn(
        view["combatants"], cur, int(b["round"] or 1))
    if new_round:
        for r in ctx.repo.combatants(b["id"]):
            ctx.repo.set_combatant(r["id"], acted=0)
        ctx.repo.record_event(ctx.campaign_id, "combat",
                              "Round {} begins.".format(rnd))
    ctx.repo.set_battle(b["id"], turn_index=idx, round=rnd)
    out = _battle_view(ctx, ctx.repo.get_battle(b["id"]))
    out["new_round"] = new_round
    return out


def h_end_combat(ctx, note=""):
    b = ctx.repo.active_battle(ctx.campaign_id)
    if not b:
        return {"error": "no fight in progress"}
    view = _battle_view(ctx, b)
    ctx.repo.end_battle(b["id"])
    ctx.repo.record_event(ctx.campaign_id, "combat",
                          "Combat ends after {} round(s){}.".format(
                              b["round"], " -- " + note if note else ""))
    return {"ended": True, "rounds": b["round"], "final": view}


def _trader_dm(ctx, row):
    """SRD: a trade check is Broker + the better of INT or SOC."""
    skill = ctx.repo.broker_skill(row["id"])
    cdm = 0
    upp = (row["upp"] or "").strip()
    if len(upp) >= 6:
        try:
            from engine.characteristics import modifier
            from engine.pseudohex import from_pseudohex
            cdm = max(modifier(from_pseudohex(upp[3])),
                      modifier(from_pseudohex(upp[5])))
        except Exception:
            cdm = 0
    return skill, cdm


def _port_day(ctx, hexv):
    """(world, codes, starport, today) for a hex, or None if nothing is charted
    there."""
    world = ctx.repo.find_world_by_hex(ctx.campaign_id, hexv) if hexv else None
    if not world:
        return None
    codes = [c for c in (world["remarks"] or "").split()
             if len(c) == 2 and c[:1].isupper()]
    port = (world["uwp"] or "X")[0].upper()
    c = ctx.repo.get_campaign(ctx.campaign_id)
    return world, codes, port, (c["current_date"] if c else None) or "0000-000"


def _ensure_stock(ctx, hexv, codes, today):
    """The quay for this port today, as {"order":[d66], "tons":{d66:tons}}.

    Which goods a supplier has and how many tons of each is a fact about the
    PORT, not about who walks up to it: a skilled broker earns a better price,
    not a bigger warehouse. The quay is rolled once (its day recorded in
    market_day so an empty quay is not mistaken for an un-visited one), shared
    by everyone, and drained -- atomically -- by take_stock. It lives in real
    rows now, not a JSON blob keyed by a "1910|stock" string.
    """
    from engine import trade as t
    if not ctx.repo.market_surveyed(ctx.campaign_id, hexv, today):
        pairs, seen = [], set()
        for g in t.available_goods(codes):
            if g.d66 in seen or not g.base_price:
                continue
            seen.add(g.d66)
            pairs.append((g.d66, t.roll_tons(g.tons_expr)))
        ctx.repo.seed_stock(ctx.campaign_id, hexv, today, pairs)
    rows = ctx.repo.stock_rows(ctx.campaign_id, hexv, today)
    return {"order": [d for d, _ in rows], "tons": {d: n for d, n in rows}}


def _priced(ctx, hexv, today, skill, cdm, g, codes, side):
    """THE held (price_per_ton, percent) for good g at this port today for
    this negotiator and side -- the only one. Rolled once, then served from
    market_quote so the board, the quote window and the till can never drift.
    """
    from engine import trade as t
    got = ctx.repo.quote_get(ctx.campaign_id, hexv, today, skill, cdm,
                             g.d66, side)
    if got is not None:
        return got
    q = (t.sale_price if side == "sell" else t.purchase_price)(
        g, codes, broker_skill=skill, char_dm=cdm)
    ctx.repo.quote_set(ctx.campaign_id, hexv, today, skill, cdm, g.d66, side,
                       q.price_per_ton, q.percent)
    return q.price_per_ton, q.percent


def _pays_dear_for(codes):
    """What this port permanently wants -- deterministic from its trade codes,
    so it is recomputed rather than stored. (Mirrors engine.trade.board.)"""
    from engine import trade as t
    demand = []
    for g in t.TRADE_GOODS.values():
        if not g.base_price or g.illegal:
            continue
        b = t.world_bias(g, codes)
        if b["sell_dm"] > 0:
            demand.append({"d66": g.d66, "good": g.name,
                           "base_price": g.base_price, **b})
    demand.sort(key=lambda d: -d["sell_dm"])
    return demand[:10]


def take_stock(ctx, hexv, d66, tons):
    """Spend `tons` off today's quay. The decrement is one atomic UPDATE with
    a `tons >= want` guard inside it (repo.stock_take), so two buyers racing
    for the last lot cannot both win. Returns {"ok"} or a refusal naming what
    is actually left."""
    got = _port_day(ctx, hexv)
    if got is None:
        return {"refused": True, "reason": "no charted world at {}".format(hexv)}
    _world, codes, _port, today = got
    _ensure_stock(ctx, hexv, codes, today)          # the quay exists before we spend
    left = ctx.repo.stock_take(ctx.campaign_id, hexv, today, str(d66), int(tons))
    if left is None:
        from engine import trade as t
        have = ctx.repo.stock_remaining(ctx.campaign_id, hexv, today, str(d66))
        g = t.TRADE_GOODS.get(str(d66))
        return {"refused": True, "tons_available": have,
                "reason": "only {}t of {} left on the quay today; you asked "
                          "for {}t.".format(have, g.name if g else d66,
                                            int(tons))}
    return {"ok": True, "tons_taken": int(tons), "tons_left": left}


def _survey_for(ctx, hexv, skill, cdm):
    """Assemble today's board for one port and one negotiator, from the shared
    quay (market_stock) and the held prices (market_quote). Same shape the old
    JSON blob had, so callers are unchanged -- only the storage is honest now.
    """
    from engine import trade as t
    got = _port_day(ctx, hexv)
    if got is None:
        return None
    _world, codes, port, today = got
    rec = _ensure_stock(ctx, hexv, codes, today)
    on_offer = []
    for d66 in rec["order"]:
        g = t.TRADE_GOODS.get(d66)
        if not g:
            continue
        price, percent = _priced(ctx, hexv, today, skill, cdm, g, codes, "buy")
        on_offer.append({
            "d66": g.d66, "good": g.name, "base_price": g.base_price,
            "tons_available": int(rec["tons"].get(d66, 0)),
            "asking_per_ton": price, "percent_of_base": percent,
            "illegal": g.illegal, **t.world_bias(g, codes)})
    on_offer.sort(key=lambda o: o["percent_of_base"])
    board = {"codes": codes, "starport": port, "on_offer": on_offer,
             "pays_dear_for": _pays_dear_for(codes),
             "brokers": t.brokers_available(port)}
    return board, codes, port, today, (skill, cdm), rec


def held_price(ctx, hexv, d66, side, skill=0, cdm=0):
    """THE price for one good at one port today -- the only one.

    The board, the quote window and the till all read the same market_quote
    row. A path that rolls its own would be a re-roll the player can farm and
    a receipt no other path would honour, so every price comes through here.
    Returns {"price_per_ton", "percent", "good", "codes", "port", "date",
    "tons_available"} or None when there is no charted world to trade with.
    """
    from engine import trade as t
    g = t.TRADE_GOODS.get(str(d66))
    if not g:
        return None
    got = _port_day(ctx, hexv)
    if got is None:
        return None
    _world, codes, port, today = got
    rec = _ensure_stock(ctx, hexv, codes, today)
    price, percent = _priced(ctx, hexv, today, skill, cdm, g, codes, side)
    tons = int(rec["tons"].get(g.d66, 0)) if side == "buy" else 0
    return {"good": g.name, "codes": codes, "port": port, "date": today,
            "price_per_ton": price, "percent": percent, "tons_available": tons}


def h_market_board(ctx, trader=None, broker_hired=0):
    """THE PORT BOARD: what is for sale here today, what your hold would
    fetch, and what this port pays dear for. Availability and asking prices
    are rolled ONCE per world per day and held -- a reload is not a re-roll.

    Hiring a local broker (SRD Local Brokers) uses THEIR skill instead of the
    trader's, for a commission that is owed even if the deal is declined."""
    from engine import trade as t
    here = _party_hex(ctx)
    world = ctx.repo.find_world_by_hex(ctx.campaign_id, here) if here else None
    if not world:
        return {"error": "no charted world here -- nothing to trade with"}
    codes = [c for c in (world["remarks"] or "").split()
             if len(c) == 2 and c[:1].isupper()]
    port = (world["uwp"] or "X")[0].upper()

    row, skill, cdm = None, 0, 0
    if trader:
        row = ctx.repo.get_character(int(trader)) if str(trader).isdigit() \
            else ctx.repo.find_character_by_name(ctx.campaign_id, str(trader))
        if not row:
            return {"error": "no such trader: {}".format(trader)}
        skill, cdm = _trader_dm(ctx, row)
    hired = int(broker_hired or 0)
    cap = t.BROKER_CAP_BY_PORT.get(port, 0)
    if hired:
        if hired > cap:
            return {"refused": True, "reason":
                    "A class-{} starport has no broker above skill {}.".format(
                        port, cap)}
        skill, cdm = hired, 0          # you use the broker's skill, not yours

    c = ctx.repo.get_campaign(ctx.campaign_id)
    today = (c["current_date"] if c else None) or "0000-000"
    fresh = not ctx.repo.market_surveyed(ctx.campaign_id, here, today)
    # Same door every other price comes through -- see held_price().
    board, codes, port, today, _neg, _rec = _survey_for(ctx, here, skill, cdm)

    # What the hold is worth HERE, today. The offer a port makes on your cargo
    # is a die like the asking price, rolled once per (port, day, good, side,
    # negotiator) in market_quote and served the same all day -- so a reload is
    # not a re-roll and the sell button cannot be farmed.
    hold = []
    for lot in ctx.repo.list_cargo(ctx.campaign_id):
        g = next((x for x in t.TRADE_GOODS.values()
                  if x.name == lot["good"]), None)
        if not g:
            continue
        price, percent = _priced(ctx, here, today, skill, cdm, g, codes, "sell")
        paid = int(lot["buy_price_per_ton"] or 0)
        hold.append({
            "cargo_lot_id": lot["id"], "good": g.name, "tons": lot["tons"],
            "paid_per_ton": paid, "offer_per_ton": price,
            "percent_of_base": percent,
            "profit_per_ton": price - paid,
            "profit_total": (price - paid) * int(lot["tons"]),
            **t.world_bias(g, codes)})

    # What the crew SEES on the quay: sold-out goods drop off the board. (The
    # tonnage on each row is already the live shared stock; see _survey_for.)
    board = dict(board, on_offer=[
        o for o in board.get("on_offer", []) if o["tons_available"] > 0])

    return {"world": world["name"], "hex": here, "date": today,
            "starport": port, "codes": codes,
            "trader": row["name"] if row is not None else None,
            "broker_skill": skill, "characteristic_dm": cdm,
            "hired_broker": hired,
            "commission_pct": t.LOCAL_BROKERS.get(hired, 0),
            "fresh_survey": fresh, "hold": hold, **board}


def h_update_chronicle(ctx, summary):
    ctx.repo.conn.execute("UPDATE campaign SET notes=? WHERE id=?",
                          (summary, ctx.campaign_id))
    ctx.repo.conn.commit()
    return {"updated": True, "chars": len(summary or "")}


# --- registry ---------------------------------------------------------------

def _obj(props, required=None):
    return {"type": "object", "properties": props, "required": required or []}


TOOLS: List[Tool] = [
    Tool("roll_dice", "Roll dice in standard notation (e.g. '2d6', '1d6+1'). "
         "Use this for ALL random results -- never invent a roll.",
         _obj({"notation": {"type": "string"}}, ["notation"]), h_roll_dice),
    Tool("task_check", "Resolve a Cepheus 2D6 task check vs target 8+.",
         _obj({"characteristic_dm": {"type": "integer"},
               "skill": {"type": "integer"},
               "difficulty": {"type": "string",
                              "enum": [d.label for d in Difficulty]},
               "other_dm": {"type": "integer"},
               "unskilled": {"type": "boolean"}}), h_task_check),
    Tool("get_world", "Look up a world by sector+hex, by hex alone, or by name.",
         _obj({"sector": {"type": "string"}, "hex": {"type": "string"},
               "name": {"type": "string"}}), h_get_world),
    Tool("list_worlds", "List worlds in the campaign (optionally one sector).",
         _obj({"sector": {"type": "string"}, "limit": {"type": "integer"}}),
         h_list_worlds),
    Tool("get_character", "Get a character/NPC by id (includes their notes).",
         _obj({"character_id": {"type": "integer"}}, ["character_id"]),
         h_get_character),
    Tool("list_characters", "List the campaign's characters and NPCs with notes.",
         _obj({"include_npcs": {"type": "boolean"}}), h_list_characters),
    Tool("list_ships", "List the campaign's ships with notes.", _obj({}),
         h_list_ships),
    Tool("generate_npc", "Create a new NPC via Cepheus character creation and "
         "SAVE them to the campaign. Give a role (e.g. 'startown fixer') and a "
         "location; it becomes their note. Use this whenever you introduce a "
         "named person.",
         _obj({"name": {"type": "string"}, "terms": {"type": "integer"},
               "location": {"type": "string"}, "role": {"type": "string"}},
              ["name"]), h_generate_npc),
    Tool("generate_creature", "Roll up a BEAST/creature with LIVE dice (STR/"
         "DEX/END, natural armor, attack skill, damage -- all rolled, all "
         "receipted) and SAVE it as a permanent campaign record. Use this the "
         "moment any animal, monster, or alien creature enters play -- never "
         "invent creature stats in prose. One beast, one record: check "
         "list_characters first; if it exists, use that record. Declare what "
         "the fiction knows (size, ferocity, weapon, traits); the dice decide "
         "how strong this particular one turned out.",
         _obj({"name": {"type": "string"},
               "size": {"type": "string",
                        "enum": ["tiny", "small", "medium", "large", "huge",
                                 "monstrous"]},
               "ferocity": {"type": "string",
                            "enum": ["timid", "defensive", "aggressive",
                                     "predator"]},
               "weapon": {"type": "string",
                          "description": "natural weapon, e.g. 'claws', "
                                         "'stinger'; omit to roll one"},
               "traits": {"type": "array", "items": {"type": "string"},
                          "description": "declared traits from the fiction, "
                                         "e.g. 'flyer', 'venomous', "
                                         "'camouflage'"},
               "location": {"type": "string"},
               "role": {"type": "string"}}, ["name"]), h_generate_creature),
    Tool("create_ship", "Create and SAVE a ship to the campaign (e.g. a pirate "
         "raider, a derelict, a patron's yacht). Use a standard class name if it "
         "fits (e.g. 'Raider', 'Frontier Trader', 'Patrol Frigate'); otherwise "
         "give a tonnage for an ad-hoc vessel. Record what it is in notes.",
         _obj({"name": {"type": "string"}, "ship_class": {"type": "string"},
               "tonnage": {"type": "integer"}, "armor": {"type": "integer"},
               "notes": {"type": "string"}, "location": {"type": "string"}},
              ["name"]), h_create_ship),
    Tool("generate_world", "Roll up an unsurveyed world and SAVE it to the sector "
         "at a hex (so it becomes permanent, mapped canon). Provide the hex; "
         "describe it in notes.",
         _obj({"name": {"type": "string"}, "hex": {"type": "string"},
               "sector": {"type": "string"}, "notes": {"type": "string"}},
              ["name", "hex"]), h_generate_world),
    Tool("add_note", "Append a lasting note to a character, ship or world -- the "
         "living-world memory. Use for anything memorable: betrayals, debts, "
         "alliances, prior encounters. Identify a character/ship by name, a world "
         "by hex or name.",
         _obj({"entity_type": {"type": "string",
                               "enum": ["character", "ship", "world"]},
               "identifier": {"type": "string"},
               "note": {"type": "string"}},
              ["entity_type", "identifier", "note"]), h_add_note),
    Tool("remove_note", "Remove a note added by mistake from a character, ship "
         "or world -- the companion to add_note. Give part of the note's text "
         "and it drops every note line containing that text (case-insensitive), "
         "reporting exactly what it removed. Use this when a player says a note "
         "is wrong; you CAN reach back and take it out.",
         _obj({"entity_type": {"type": "string",
                               "enum": ["character", "ship", "world"]},
               "identifier": {"type": "string"},
               "contains": {"type": "string",
                            "description": "part of the note's text to match"}},
              ["entity_type", "identifier", "contains"]), h_remove_note),
    Tool("set_character_status", "Update a character/NPC's status (e.g. 'wounded', "
         "'captured', 'dead') and alive flag.",
         _obj({"character_id": {"type": "integer"}, "status": {"type": "string"},
               "alive": {"type": "boolean"}}, ["character_id", "status"]),
         h_set_character_status),
    Tool("apply_damage", "Apply DAMAGE (or healing, with a negative amount) to "
         "a character, NPC, or creature by id or name. The RECORD tracks "
         "wounds -- call this every time damage is dealt or healed; never "
         "track hits only in prose or memory. The engine derives status "
         "(wounded / seriously wounded / down) from the numbers and tells "
         "you what's left. Roll the damage dice first (roll_dice), then "
         "apply the result here.",
         _obj({"target": {"type": "string",
                          "description": "character/creature id or name"},
               "amount": {"type": "integer",
                          "description": "+damage or -healing"},
               "source": {"type": "string",
                          "description": "what did it, e.g. 'stinger', "
                                         "'laser carbine'"}},
              ["target", "amount"]), h_apply_damage),
    Tool("trade_price", "What a trade good (by D66 code) costs or fetches. "
         "With no world_codes this is the FIRM price where the crew stands "
         "today -- the same number the Exchange shows and the till charges, "
         "so asking again will not improve it. Give world_codes (or a hex) to "
         "project a price for somewhere else; that answer comes back flagged "
         "indicative_only and must not be quoted as firm.",
         _obj({"good_d66": {"type": "string"},
               "world_codes": {"type": "array", "items": {"type": "string"}},
               "hex": {"type": "string"},
               "side": {"type": "string", "enum": ["buy", "sell"]},
               "broker": {"type": "string",
                          "description": "character id or name who would "
                                         "negotiate"},
               "broker_skill": {"type": "integer"}}, ["good_d66"]),
         h_trade_price),
    Tool("buy_goods", "BUY speculative cargo the airtight way: verifies the "
         "payer's REAL funds (a character's credits, or 'party' for the "
         "ledger) and the ship's REAL hold space, REFUSES if either falls "
         "short, then debits the money and stows the cargo lot in one motion. "
         "Use this for EVERY cargo purchase -- never a bare ledger entry -- "
         "and only when the players said to. YOU DO NOT SET THE PRICE: this "
         "port's asking price for today is applied for you and returned in "
         "price_per_ton. Name the `broker` whose Broker skill did the "
         "haggling and the `payer` whose credits are spent -- they need not "
         "be the same person.",
         _obj({"good": {"type": "string",
                        "description": "trade good name or D66 code"},
               "tons": {"type": "integer"},
               "ship_id": {"type": "integer"},
               "broker": {"type": "string",
                          "description": "character id or name who "
                                         "negotiated; omit for unskilled"},
               "payer": {"type": "string",
                         "description": "character id or name, or 'party' "
                                        "(default) for the shared ledger"}},
              ["good", "tons", "ship_id"]), h_buy_goods),
    Tool("sell_goods", "SELL a held cargo lot (by lot id or good name): marks "
         "it sold, credits the chosen pocket (character id/name, or 'party'), "
         "and reports profit against the purchase price. Use this for EVERY "
         "cargo sale -- never a bare ledger entry -- and only when the "
         "players said to. YOU DO NOT SET THE PRICE: what this port pays "
         "today is applied for you and returned in price_per_ton.",
         _obj({"cargo": {"type": "string",
                         "description": "cargo lot id or good name"},
               "broker": {"type": "string",
                          "description": "character id or name who "
                                         "negotiated; omit for unskilled"},
               "payee": {"type": "string",
                         "description": "character id or name, or 'party' "
                                        "(default) for the shared ledger"}},
              ["cargo"]), h_sell_goods),
    Tool("jump_options", "Where can this ship actually GO right now? Returns "
         "every world within its jump rating, with true distance, bearing, "
         "and the fuel each trip costs. Call this before offering a player "
         "destinations -- never build a range list from memory.",
         _obj({"ship_id": {"type": "integer"}}, ["ship_id"]), h_jump_options),
    Tool("jump_ship", "JUMP a ship to a world (by name or hex). The ENGINE "
         "runs the whole Cepheus procedure: the navigator's jump plot, the "
         "engineer's divert-power check, the 2D6 Jump Success Roll, fuel "
         "burn, the week in jumpspace, and misjumps. It moves the ship and "
         "crew and advances the calendar. Call it for EVERY jump and narrate "
         "the result it returns -- including the failures. A plot that will "
         "not close, a dry tank, or a misjump are all real outcomes; show "
         "the rolls it hands back.",
         _obj({"ship_id": {"type": "integer"},
               "destination": {"type": "string"},
               "crew_ids": {"type": "array", "items": {"type": "integer"}}},
              ["ship_id", "destination"]), h_jump_ship),
    Tool("refuel_ship", "Take on fuel at the ship's current world, by the "
         "SRD's rules: refined Cr500/ton at class A/B ports, unrefined "
         "Cr100/ton at A/B/C, free skimming from a gas giant or open water. "
         "Unrefined fuel costs -2 on the next jump roll. Omit tons to fill "
         "the tanks. payer is a character id/name or 'party'.",
         _obj({"ship_id": {"type": "integer"}, "tons": {"type": "integer"},
               "kind": {"type": "string", "enum": ["refined", "unrefined"]},
               "payer": {"type": "string"}}, ["ship_id"]), h_refuel_ship),
    Tool("set_location", "Set a ship's or character's LOCAL position freeform "
         "(a city, a bay, 'aboard the Rose', orbit). For in-system moves; "
         "interstellar travel goes through jump_ship.",
         _obj({"entity_type": {"type": "string", "enum": ["ship", "character"]},
               "entity_id": {"type": "integer"},
               "location": {"type": "string"}}, ["entity_type", "entity_id",
                                                 "location"]), h_set_location),
    Tool("adjust_credits", "Change a CHARACTER's personal credits by +/- delta "
         "(with a short reason) EVERY time they earn or spend money. The "
         "character sheet's credits field is the single truth for personal "
         "wealth -- never track money only in notes or prose. Returns the new "
         "balance.",
         _obj({"character_id": {"type": "integer"}, "delta": {"type": "integer"},
               "reason": {"type": "string"}}, ["character_id", "delta"]),
         h_adjust_credits),
    Tool("record_transaction", "Record a credit transaction in the party LEDGER "
         "(+income, -expense). Call this EVERY time money changes hands -- the "
         "ledger, not narration, is the source of truth for finances. Returns "
         "the new party balance.",
         _obj({"amount": {"type": "integer"}, "kind": {"type": "string"},
               "description": {"type": "string"}}, ["amount", "kind"]),
         h_record_transaction),
    Tool("party_balance", "The party's current credit balance from the ledger.",
         _obj({}), h_party_balance),
    Tool("transfer_funds", "Hand credits from one pocket to another in ONE "
         "receipted motion: character to character, character to the party "
         "ledger, or the ledger out to a character. Use 'party' (or a "
         "character's id or name) for either end. This is how one player "
         "stakes another, how a share of a haul gets paid out, and how the "
         "pot gets topped up before a big buy -- never two separate credit "
         "adjustments that happen to match.",
         _obj({"source": {"type": "string",
                          "description": "who pays: a character id/name, or "
                                         "'party' for the shared ledger"},
               "target": {"type": "string",
                          "description": "who receives: a character id/name, "
                                         "or 'party' for the shared ledger"},
               "amount": {"type": "integer",
                          "description": "credits to move; always positive"},
               "reason": {"type": "string",
                          "description": "what it's for -- 'stake for the "
                                         "Gems buy', 'his cut of the haul'"}},
              ["source", "target", "amount"]),
         h_transfer_funds),
    Tool("record_event", "Record a campaign event (the source-of-truth log). "
         "Call this for anything lasting that happens.",
         _obj({"kind": {"type": "string"}, "summary": {"type": "string"},
               "detail": {"type": "object"}}, ["kind", "summary"]),
         h_record_event),
    Tool("ledger", "Read back the RECEIPT TAPE -- the numbered record of every "
         "mechanical act this campaign: dice, checks, money, wounds, travel. "
         "Use it to check what actually happened rather than trusting your "
         "memory of it, and to prove a number when a player questions one. "
         "Flags any gap in the sequence.",
         _obj({"limit": {"type": "integer"}, "since_seq": {"type": "integer"}}),
         h_ledger),
    Tool("recent_events", "Read the most recent campaign events for context.",
         _obj({"limit": {"type": "integer"}}), h_recent_events),
    Tool("mark_visited", "Mark a world as visited by the party.",
         _obj({"world_id": {"type": "integer"}}, ["world_id"]), h_mark_visited),
    Tool("set_date", "Set the campaign's current in-game date -- forward, or "
         "BACKWARD to undo time that was advanced by mistake. Records the "
         "correction (was -> now) in the chronicle.",
         _obj({"date": {"type": "string"}, "reason": {"type": "string"}},
              ["date"]), h_set_date),
    Tool("market_board", "THE PORT BOARD -- what is on sale here today with "
         "asking prices, what the crew's cargo would fetch here, and what "
         "this port pays dear for. Prices are rolled once per world per day "
         "and held. Give a trader (their Broker skill and INT-or-SOC apply), "
         "or hire a local broker by skill level for a commission. Read this "
         "before quoting a player any price.",
         _obj({"trader": {"type": "string"},
               "broker_hired": {"type": "integer"}}), h_market_board),
    Tool("start_combat", "Open a FIGHT on the Field Desk. Give the combatants "
         "as [{character_id or name, side: crew|foe, weapon, armor}]. The "
         "engine rolls initiative once and fixes the order. Everyone in the "
         "fight must already exist as a record -- generate_npc or "
         "generate_creature them FIRST.",
         _obj({"combatants": {"type": "array", "items": {"type": "object"}},
               "range_band": {"type": "string",
                              "enum": ["Personal", "Close", "Short", "Medium",
                                       "Long", "Very Long", "Distant"]},
               "note": {"type": "string"}}, ["combatants"]), h_start_combat),
    Tool("combat_status", "Read the battle board: initiative order, round, "
         "whose turn it is, who is still standing.", _obj({}), h_combat_status),
    Tool("combat_attack", "Resolve ONE attack. The engine applies the range "
         "difficulty, the attacker's skill and characteristic DM, rolls 2D6 "
         "(or uses roll=[d1,d2] if a player threw their own), applies armour "
         "and Effect, and writes the wound to the record. Narrate what it "
         "returns -- never decide a hit yourself.",
         _obj({"attacker": {"type": "string"}, "target": {"type": "string"},
               "roll": {"type": "array", "items": {"type": "integer"}},
               "other_dm": {"type": "integer"}}, ["attacker", "target"]),
         h_combat_attack),
    Tool("combat_next", "Pass the turn to the next combatant in initiative "
         "order; turns the round when everyone standing has acted.",
         _obj({}), h_combat_next),
    Tool("end_combat", "Close the fight.", _obj({"note": {"type": "string"}}),
         h_end_combat),
    Tool("add_lore", "PROPOSE a lasting fact about the world -- a faction, an "
         "institution, a custom, a piece of history, a rumour. Call it "
         "whenever you invent something you want the campaign to REMEMBER. "
         "It enters as a PROPOSAL, not canon: narrate it in the moment if the "
         "scene needs it, but do not treat it as established, and do not "
         "build further invention on top of it, until the table approves. "
         "Read lookup_lore FIRST so you don't invent over settled ground.",
         _obj({"title": {"type": "string"}, "body": {"type": "string"},
               "category": {"type": "string",
                            "enum": ["faction", "person", "place", "custom",
                                     "rumour", "fact"]}}, ["title"]),
         h_add_lore),
    Tool("lookup_lore", "Read the world's ESTABLISHED facts (approved canon) "
         "before inventing anything. Optionally filter by a search term.",
         _obj({"query": {"type": "string"},
               "include_pending": {"type": "boolean"}}), h_lookup_lore),
    Tool("strike_event", "STRIKE an event from the record: something that was "
         "written down but should never have happened. The event is kept and "
         "marked struck (an honest record shows its own corrections) but it "
         "stops feeding your briefing and the story. Use it when you or a "
         "player identify a mistake -- never to hide a bad outcome the dice "
         "produced fairly.",
         _obj({"event_id": {"type": "integer"}, "reason": {"type": "string"}},
              ["event_id"]), h_strike_event),
    Tool("strike_receipt", "VOID a mechanical act on the receipt tape by its "
         "sequence number. The receipt stays -- deleting one would leave a "
         "gap, and a gap means tampering -- but it is marked void with your "
         "reason. Pair it with the matching undo (reverse_transaction, a "
         "negative adjust_credits, healing apply_damage) to put the world "
         "back.",
         _obj({"seq": {"type": "integer"}, "reason": {"type": "string"}},
              ["seq"]), h_strike_receipt),
    Tool("reverse_transaction", "Undo money cleanly: posts the exact inverse "
         "of a ledger entry, linked to the original, so the balance is right "
         "and the history still shows what happened. Use this instead of "
         "inventing a compensating entry in prose.",
         _obj({"ledger_id": {"type": "integer"}, "reason": {"type": "string"}},
              ["ledger_id"]), h_reverse_transaction),
    Tool("update_chronicle", "Replace the campaign's running 'story so far' "
         "chronicle -- the long-term memory shown to you every turn. Fold the "
         "existing chronicle plus what just happened into a tight, current "
         "summary: who the crew are, where they are, key NPCs and the crew's "
         "relationships with them, current goals, debts, and open threads. Call "
         "this after meaningful developments and at the end of a session.",
         _obj({"summary": {"type": "string"}}, ["summary"]), h_update_chronicle),
]

_BY_NAME = {t.name: t for t in TOOLS}


def tool_specs() -> List[Dict[str, Any]]:
    return [t.spec() for t in TOOLS]


# Pure reads. Everything NOT listed here is mechanical and must leave a
# receipt -- the default is "this changed the world or rolled a die", because
# a tool wrongly called a read is a hole in the tape.
READ_ONLY = frozenset({
    "get_world", "list_worlds", "get_character", "list_characters",
    "list_ships", "party_balance", "recent_events", "jump_options", "ledger",
    "lookup_lore", "combat_status", "market_board",
})


def dispatch(name: str, arguments: Dict[str, Any], ctx: RefereeContext,
             source: str = "referee") -> Any:
    """Run a tool and, if it changed anything or rolled anything, stamp the
    tape before the result escapes.

    Three invariants, enforced here so no handler has to remember them:
      * a mechanical call leaves exactly ONE receipt
      * a failed call leaves NONE
      * a pure read leaves NONE
    """
    tool = _BY_NAME.get(name)
    if tool is None:
        return {"error": "unknown tool: {}".format(name)}
    args = dict(arguments or {})
    manual = bool(args.pop("_manual", False))

    # A SUPPLIED die is a human's die. The referee is never allowed to hand the
    # engine its own numbers -- that would undo every guarantee on the tape --
    # so a roll offered by the AI is discarded and the engine throws instead.
    supplied = any(args.get(k) for k in ("roll", "damage_roll"))
    if supplied and source != "player":
        args.pop("roll", None)
        args.pop("damage_roll", None)
        supplied = False
    author = "human" if (manual or supplied) else "engine"
    try:
        result = tool.handler(ctx, **args)
    except Exception as e:
        return {"error": "{}: {}".format(type(e).__name__, e)}

    if name in READ_ONLY:
        return result
    if isinstance(result, dict) and (result.get("error")
                                     or result.get("refused")
                                     or result.get("already_exists")):
        return result           # nothing happened; nothing to stamp
    rc = ctx.repo.write_receipt(ctx.campaign_id, name, args, result,
                                author=author, source=source,
                                summary=_receipt_summary(name, result))
    if isinstance(result, dict):
        result = dict(result)
        result["receipt"] = rc
    return result


def _receipt_summary(name, result) -> str:
    if not isinstance(result, dict):
        return name
    for key in ("summary", "reason", "description", "name"):
        if result.get(key):
            return "{}: {}".format(name, result[key])
    return name

