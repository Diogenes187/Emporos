"""referee.py -- the referee turn loop and the three GM modes.

The referee is a role over the tool API. Modes:
  * "ai"     -- the LLM drives: take_turn() runs the full model+tool loop and
                commits results to the database.
  * "assist" -- a human GM holds authority; suggest() returns the model's
                proposed narration/tool-calls WITHOUT committing, for review.
  * "human"  -- no model; the GM calls tools directly via call_tool().

Multiplayer lives one layer up: the web/session code feeds player input into
take_turn(); the referee operates on the shared campaign in the database.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .llm import LLMClient, LLMResponse, ToolCall
from engine import validator
from .tools import RefereeContext, dispatch, tool_specs
from .prompt import SYSTEM_PROMPT, build_context, TURN_REMINDER


@dataclass
class TurnResult:
    narration: str
    tool_trace: List[Dict[str, Any]] = field(default_factory=list)
    event_ids: List[int] = field(default_factory=list)
    iterations: int = 0


# Bracketed roll displays, e.g. "[task_check, Average: rolled (4,2)+4 = 10 ...]".
# The dice audit compares these against ACTUAL roll_dice/task_check calls: a
# displayed roll with no tool receipt is counterfeit and never enters the record.
_ROLL_BRACKET = re.compile(r"\[(?:task_check|roll_dice|roll)\b[^\]]*\]", re.I)
_DICE_TOOLS = ("roll_dice", "task_check")


def _assistant_toolcall_message(calls: List[ToolCall]) -> Dict[str, Any]:
    return {"role": "assistant", "content": None, "tool_calls": [
        {"id": c.id or "call_{}".format(i), "type": "function",
         "function": {"name": c.name, "arguments": json.dumps(c.arguments)}}
        for i, c in enumerate(calls)]}


class Referee:
    def __init__(self, repo, campaign_id: int, client: Optional[LLMClient] = None,
                 mode: str = "ai", max_tool_iters: int = 8):
        self.repo = repo
        self.campaign_id = campaign_id
        self.client = client
        self.mode = mode
        self.max_tool_iters = max_tool_iters
        self.ctx = RefereeContext(repo=repo, campaign_id=campaign_id)

    # ---- human mode: direct tool use -----------------------------------

    def call_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None):
        """Run a tool directly (human-GM mode, or programmatic use)."""
        return dispatch(name, arguments or {}, self.ctx)

    # ---- shared: build the message stack -------------------------------

    def _base_messages(self, player_input: str) -> List[Dict[str, Any]]:
        msgs: List[Dict[str, Any]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "system", "content": build_context(self.repo, self.campaign_id)},
        ]
        # Conversation memory: replay the last few turns so the model remembers
        # what just happened. Each model call is otherwise stateless -- without
        # this a scene narrated last turn is forgotten and resets to a default.
        for past in self.repo.recent_turns(self.campaign_id, limit=20):
            if past.get("player_input"):
                msgs.append({"role": "user", "content": past["player_input"]})
            if past.get("narration"):
                msgs.append({"role": "assistant", "content": past["narration"]})
        msgs.append({"role": "user", "content": player_input + "\n\n" + TURN_REMINDER})
        return msgs

    # ---- assist mode: propose without committing -----------------------

    def suggest(self, player_input: str) -> LLMResponse:
        """Return the model's proposed response (text and/or tool calls) WITHOUT
        executing any tools. For a human GM to review before committing."""
        if self.client is None:
            raise RuntimeError("suggest() needs an LLM client")
        return self.client.chat(self._base_messages(player_input), tool_specs())

    # ---- ai mode: full drive + commit ----------------------------------

    def take_turn(self, player_input: str, actor: Optional[str] = None) -> TurnResult:
        """Run a full referee turn: the model narrates and calls tools, tools are
        executed against the database, and the result is returned + logged."""
        if self.client is None:
            raise RuntimeError("take_turn() needs an LLM client (use call_tool "
                               "for human mode)")
        messages = self._base_messages(
            ("[{}] ".format(actor) if actor else "") + player_input)
        trace: List[Dict[str, Any]] = []
        events: List[int] = []
        audited = False        # one corrective bounce per turn, then enforcement
        nudged_empty = False   # one retry if the model replies with no text
        # Where the tape stood before this turn: everything stamped after this
        # point is what THIS turn is allowed to talk about.
        try:
            before = self.repo.receipts(self.campaign_id, limit=1)
            seq0 = before[0]["seq"] if before else 0
        except Exception:
            seq0 = None

        for i in range(1, self.max_tool_iters + 1):
            resp = self.client.chat(messages, tool_specs())
            if resp.wants_tools:
                messages.append(_assistant_toolcall_message(resp.tool_calls))
                for c in resp.tool_calls:
                    result = dispatch(c.name, c.arguments, self.ctx)
                    trace.append({"tool": c.name, "args": c.arguments,
                                  "result": result})
                    if c.name == "record_event" and isinstance(result, dict):
                        if "event_id" in result:
                            events.append(result["event_id"])
                    messages.append({"role": "tool",
                                     "tool_call_id": c.id or "call",
                                     "content": json.dumps(result)})
                continue
            narration = (resp.text or "").strip()

            # ---- EMPTY-REPLY GUARD: a silent referee is a bug on screen ----
            # Some models/providers occasionally return no tool calls AND no
            # content (truncation, reasoning-only replies, transient API
            # glitches). Committing "" broadcasts a blank line to every player
            # at the table. Bounce once; if still silent, say so visibly.
            if not narration:
                print("[referee] EMPTY model reply on campaign {} iter {} "
                      "(tool_calls=0, content empty){}".format(
                          self.campaign_id, i,
                          " -- retrying once" if not nudged_empty
                          else " -- giving up, visible error returned"),
                      flush=True)
                if not nudged_empty:
                    nudged_empty = True
                    messages.append({"role": "system", "content":
                        "[ENGINE] Your last reply contained no text. Reply now "
                        "with this turn's narration as plain text (no tool "
                        "calls needed unless something mechanical remains)."})
                    continue
                narration = ("[Referee error] The model returned an empty "
                             "reply twice; nothing was narrated this turn. "
                             "State and dice are unchanged -- try the turn "
                             "again, and check the server logs / model "
                             "configuration if this persists.")

            # ---- THE VALIDATOR: prose may not outrun the receipt tape ----
            # Every mechanical act this turn stamped a numbered receipt. If the
            # narration claims a roll, a sum, a wound or a credit the tape
            # never produced, it is invention wearing the clothes of fact.
            turn_receipts = None
            if seq0 is not None:
                try:
                    turn_receipts = [dict(r) for r in self.repo.receipts(
                        self.campaign_id, limit=200, since_seq=seq0)]
                except Exception:
                    turn_receipts = None
            verdict = validator.validate(narration, turn_receipts)

            if not verdict["ok"] and not audited:
                audited = True
                messages.append({"role": "assistant", "content": narration})
                messages.append({"role": "system", "content":
                    "[AUDIT] Your narration asserts mechanical facts the "
                    "receipt tape does not back:\n{}\n\nEvery number you "
                    "state -- a roll, a total, damage, credits, fuel, parsecs "
                    "-- must come from a tool you called THIS turn. Either "
                    "call the tools now and re-narrate from what they "
                    "actually return, or re-narrate without those claims. "
                    "Numbers remembered from earlier turns are history, not "
                    "this turn's facts.".format(validator.summarize(verdict))})
                continue

            if not verdict["ok"]:
                # Still unbacked after the warning. Confiscate the fake dice
                # and record the discrepancy: prose loses, the record holds.
                narration = validator.ROLL_BRACKET.sub("", narration)
                narration = re.sub(r"[ \t]{2,}", " ", narration)
                narration = re.sub(r"\n{3,}", "\n\n", narration).strip()
                self.repo.record_event(
                    self.campaign_id, "audit",
                    "Validator: {} unbacked mechanical claim(s) in narration "
                    "({}).".format(
                        len(verdict["violations"]),
                        "; ".join(sorted({v["rule"] for v in verdict["violations"]}))),
                    {"violations": verdict["violations"][:10]})
                # The player is the auditor, so the player must SEE it. A
                # flagged claim is not quietly logged and shipped as prose.
                flagged = ", ".join(
                    "{} {}".format(v.get("kind", v["rule"]).replace("_", " "),
                                   v.get("number", "")).strip()
                    for v in verdict["violations"][:4])
                narration += (
                    "\n\n⚠ *Engine audit: this narration states {} that the "
                    "record does not back ({}). The record stands; the prose "
                    "does not. Check the ledger.*".format(
                        "a figure" if len(verdict["violations"]) == 1
                        else "figures", flagged))

            # Persist the narration as a turn event (source of truth).
            eid = self.repo.record_event(
                self.campaign_id, "narration",
                narration[:200] + ("..." if len(narration) > 200 else ""),
                {"actor": actor, "full": narration,
                 "player_input": ("[{}] ".format(actor) if actor else "") + player_input})
            events.append(eid)
            return TurnResult(narration=narration, tool_trace=trace,
                              event_ids=events, iterations=i)

        return TurnResult(narration="(the referee is still deliberating)",
                          tool_trace=trace, event_ids=events,
                          iterations=self.max_tool_iters)

    # ---- the table veto: re-narrate the last turn ----------------------

    def reject(self, note: str = "") -> str:
        """Re-narrate the LAST turn. State and dice stand -- tools are
        disabled -- only the prose is regenerated, guided by the player's
        note. The rejected narration is REPLACED in the record so the bad
        prose never feeds a future turn's context."""
        if self.client is None:
            raise RuntimeError("reject() needs an LLM client")
        turns = self.repo.recent_turns(self.campaign_id, limit=7)
        if not turns:
            return "[Nothing to re-narrate yet.]"
        last = turns[-1]
        messages: List[Dict[str, Any]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "system", "content": build_context(self.repo, self.campaign_id)},
        ]
        for past in turns[:-1]:
            if past.get("player_input"):
                messages.append({"role": "user", "content": past["player_input"]})
            if past.get("narration"):
                messages.append({"role": "assistant", "content": past["narration"]})
        if last.get("player_input"):
            messages.append({"role": "user", "content": last["player_input"]})
        messages.append({"role": "assistant", "content": last.get("narration") or ""})
        veto = ("[TABLE VETO] The player rejected that last narration"
                + (": {}".format(note) if note.strip() else "")
                + ". Re-narrate the same turn CORRECTLY. Every name and number "
                "must match the campaign record and what the tools already "
                "returned. Nothing mechanical is re-done -- any dice stand "
                "exactly as rolled. Plainer prose: no flourishes, no invented "
                "details, no new events. Reply with the corrected narration only.")
        messages.append({"role": "user", "content": veto})
        resp = self.client.chat(messages, None)          # no tools: dice stand
        text = (resp.text or "").strip() or "(the referee stands corrected, silently)"
        self.repo.replace_narration(last["id"], text)    # bad prose never returns
        return text
