"""run.py -- start the Cepheus campaign server.

    python web/run.py                 # serves on http://127.0.0.1:8000
    CEPHEUS_DB=mygame.db python web/run.py
    DEEPSEEK_API_KEY=sk-... python web/run.py   # enables the AI referee

Without a model key the server still runs fully -- map, sheets and human-GM
tools all work; only the AI GM turns are disabled until a key is set.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import uvicorn
from web.app import create_app

if __name__ == "__main__":
    db = os.environ.get("CEPHEUS_DB", "cepheus.db")
    app = create_app(db)
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    print("Cepheus server -> http://{}:{}  (db: {})".format(host, port, db))
    uvicorn.run(app, host=host, port=port)
