"""app.py -- the Cepheus campaign web server (FastAPI).

Ties the whole stack together for a browser-based, multiplayer table:
  * REST endpoints over the state repo (campaigns, worlds, characters, ships,
    events) and the engine (the referee turn loop).
  * Live subsector / sector maps rendered as SVG by render.svgmap.
  * A websocket that broadcasts new events to every connected player.

The LLM client is injectable (create_app(client=...)); by default it uses
DeepSeek V4-Flash if DEEPSEEK_API_KEY is set, and otherwise degrades gracefully
so the map, sheets and human-GM tools all work without any model.
"""
from __future__ import annotations

import asyncio
import glob
import json
import os
import threading
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import (FileResponse, Response, JSONResponse,
                               HTMLResponse, RedirectResponse)
from pydantic import BaseModel

from state.repo import Repo
from state import t5
from render import svgmap
from referee.referee import Referee
from referee.llm import LLMClient, LLMResponse, make_client
from referee.config import get_config

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC = os.path.join(os.path.dirname(__file__), "static")
CHARTED = os.path.join(ROOT, "reference", "charted_space")


def _campaign_in_path(path: str):
    """If a request path is scoped to one campaign (/api/campaigns/<cid>[/<sub>]),
    return (cid, sub_or_None); otherwise None. Used to enforce per-campaign locks.
    The bare list/create path /api/campaigns has no <cid> and returns None."""
    parts = path.split("/")
    if (len(parts) >= 4 and parts[1] == "api" and parts[2] == "campaigns"
            and parts[3].isdigit()):
        return int(parts[3]), (parts[4] if len(parts) >= 5 else None)
    return None


def _camp_cookie(cid: int) -> str:
    return "cepheus_camp_{}".format(cid)


class NoKeyClient(LLMClient):
    """Stands in when no API key is configured: explains how to go live."""
    def chat(self, messages, tools=None) -> LLMResponse:
        return LLMResponse(text=(
            "[AI referee offline] No model key is set. Set DEEPSEEK_API_KEY "
            "(or pick another provider) to enable the AI GM. Human-GM tools, "
            "the map and the sheets all work without it."))


# Port-of-origin worlds per reach: the eight doors into a sector. Campaign
# creation looks the chosen port up by NAME in the freshly imported sector, so
# this works for any sector that contains these worlds (and degrades to no
# start point on sectors that don't, e.g. legacy Marches campaigns).
REACH_PORTS = {
    "norse": "Kaupang", "greek": "Massalia", "roman": "Ostia",
    "japanese": "Sakai", "maya": "Tikal", "swahili": "Kilwa",
    "egyptian": "Waset", "sumerian": "Ur",
}


# Lair lore seeded as REFEREE-ONLY world notes when a campaign imports the
# Emporion. The referee meets these on get_world when a crew arrives; players
# never see world notes (stripped from the /worlds endpoint). Full stat blocks
# and hooks: BESTIARY-EMPORION.md.
EMPORION_LAIRS = {
 "Myrkvid": ("LAIR (referee only): DRAUGR -- cold-sleep revenants aboard the "
   "derelict fleet. Hits 20, Armor 8, claw 2D, Stealth-2, immune to vacuum/"
   "cold/fear; radio traffic WAKES them. Guard their wrecks, never leave them. "
   "See BESTIARY-EMPORION."),
 "Hesperides": ("LAIR (referee only): SIREN -- wrecker-colony broadcasting "
   "perfect fake distress calls (Deception-3 electronic). No direct attack; "
   "the crash-site terrain kills. Comms discipline resists the lure. A "
   "graveyard of previous ships surrounds it. See BESTIARY-EMPORION."),
 "Honos": ("LAIR (referee only): STRIX packs (2D) -- silent night-gliders, "
   "heat-seeking. Hits 8, talons 1D+2, drop attack from dark +2 effect, "
   "Stealth-3, flee bright light. They emptied this colony; the settlers' "
   "eagle standard remains. See BESTIARY-EMPORION."),
 "Izu": ("LAIR (referee only): ONI -- feral heavy-world labor-forms, 3m, "
   "tusked. Hits 40, Armor 3, club 3D, Athletics-3. Territorial: one warning "
   "throw, then violence. Gifts of metal tools have bought passage. See "
   "BESTIARY-EMPORION."),
 "Xibalba": ("LAIR (referee only): CAMAZOTZ -- void-adapted death-bat hunting "
   "engine heat across the nebula. Hits 25, talons 3D, strafing 1D structure, "
   "Recon-3 thermal. Cold-running (Pilot, Difficult) evades. Tikal pays for a "
   "live one. See BESTIARY-EMPORION."),
 "Kivuko": ("LAIR (referee only): NUNDA, the Eater of People -- house-sized "
   "amphibious apex predator of the estuaries. Hits 60, Armor 5, bite 4D, "
   "Stealth-3 in water. Takes the straggler near the water. Locals know the "
   "drum-signals; a 40-year Kilwa bounty stands. See BESTIARY-EMPORION."),
 "Deshret": ("LAIR (referee only): SERPOPARD -- long-necked dune stalker, "
   "strikes from cover at reach. Hits 30, bite 3D, Recon-3, shadows caravans "
   "a day before committing. The exile caravans post 'neck watch'. See "
   "BESTIARY-EMPORION."),
 "Aratta": ("LAIR (referee only): GIRTABLILU -- scorpion-men guarding the "
   "road past Aratta. Hits 45, Armor 6, sting 3D + poison (END, Difficult), "
   "cannot be surprised on their ground. PARLEY POSSIBLE: Persuade, or "
   "Sumerian liturgy at +2. They were SET here by something. See "
   "BESTIARY-EMPORION."),
 "Dilmun": ("GUARDIANS (referee only): LAMASSU at the port gates -- winged, "
   "human-faced, benevolent, never wrong about people. Hits 50, Armor 8, "
   "Recon-4, intent-reading +4 vs Deception. They enforce the market truce "
   "in wingbeats. One has begun watching a docked ship... See "
   "BESTIARY-EMPORION."),
}


def _seed_emporion_lore(repo, cid: int) -> int:
    """Write lair notes into a freshly imported Emporion campaign. Silent by
    design: no events, no player-visible trace -- the referee finds them."""
    n = 0
    for name, note in EMPORION_LAIRS.items():
        row = repo.find_world(cid, name)
        if row:
            repo.conn.execute("UPDATE world SET notes=? WHERE id=?",
                              (note, row["id"]))
            n += 1
    repo.conn.commit()
    return n


def find_sector_file(name: str) -> Optional[str]:
    # Original sectors (the Emporion lives here) take precedence.
    own = os.path.join(ROOT, "reference", "emporion", "{}.tab".format(name))
    if os.path.exists(own):
        return own
    for milieu in ("M1105", "M1201"):
        m = glob.glob(os.path.join(CHARTED, milieu, "{}.tab".format(name)))
        if m:
            return m[0]
    m = glob.glob(os.path.join(CHARTED, "**", "{}.tab".format(name)), recursive=True)
    return m[0] if m else None


class ConnectionManager:
    def __init__(self):
        self.rooms: Dict[int, List[WebSocket]] = {}

    async def connect(self, cid: int, ws: WebSocket):
        await ws.accept()
        self.rooms.setdefault(cid, []).append(ws)

    def disconnect(self, cid: int, ws: WebSocket):
        if cid in self.rooms and ws in self.rooms[cid]:
            self.rooms[cid].remove(ws)

    async def broadcast(self, cid: int, message: dict):
        for ws in list(self.rooms.get(cid, [])):
            try:
                await ws.send_json(message)
            except Exception:
                self.disconnect(cid, ws)


class AppState:
    def __init__(self, db_path: str, client: Optional[LLMClient]):
        self.repo = Repo.open(db_path)
        self.lock = threading.Lock()
        # Per-campaign turn locks: a slow referee turn serializes ITS table
        # only. Two campaigns never wait on each other's model calls.
        self._camp_locks: Dict[int, threading.Lock] = {}
        self._camp_locks_guard = threading.Lock()
        self.manager = ConnectionManager()
        if client is not None:
            self.client = client
        elif get_config("deepseek").api_key:
            self.client = make_client("deepseek")
        else:
            self.client = NoKeyClient()
        if db_path != ":memory:":
            t = threading.Thread(target=self._backup_loop, args=(db_path,),
                                 daemon=True)
            t.start()

    def campaign_lock(self, cid: int) -> threading.Lock:
        with self._camp_locks_guard:
            return self._camp_locks.setdefault(int(cid), threading.Lock())

    @staticmethod
    def backup_once(db_path: str, keep: int = 12) -> Optional[str]:
        """Snapshot the database (VACUUM INTO a timestamped copy alongside
        it, under backups/) and prune to the newest `keep`. Returns the
        snapshot path, or None on any failure -- backups never crash play."""
        import sqlite3 as _sq
        import time as _time
        try:
            bdir = os.path.join(os.path.dirname(db_path) or ".", "backups")
            os.makedirs(bdir, exist_ok=True)
            import uuid as _uuid
            dest = os.path.join(bdir, "cepheus-{}-{}.db".format(
                _time.strftime("%Y%m%d-%H%M%S"), _uuid.uuid4().hex[:6]))
            src = _sq.connect(db_path)
            try:
                src.execute("VACUUM INTO ?", (dest,))
            finally:
                src.close()
            old = sorted(glob.glob(os.path.join(bdir, "cepheus-*.db")))
            for p in old[:-keep]:
                try:
                    os.remove(p)
                except OSError:
                    pass
            return dest
        except Exception:
            return None

    def _backup_loop(self, db_path: str):
        import time as _time
        while True:
            self.backup_once(db_path)
            _time.sleep(6 * 3600)               # every six hours, forever

    def referee(self, cid: int, mode: str = "ai") -> Referee:
        return Referee(self.repo, cid, client=self.client, mode=mode)


# --- request bodies ---------------------------------------------------------

class CampaignCreate(BaseModel):
    name: str
    import_sector: Optional[str] = "Emporion"   # the switch, thrown 2026-07-26
    current_date: Optional[str] = "1105-001"
    password: Optional[str] = None          # per-campaign lock; blank = open
    start_reach: Optional[str] = None       # norse|greek|roman|japanese|maya|swahili|egyptian|sumerian


class ModuleLoad(BaseModel):
    """A published adventure handed to the referee, sealed. The uploader need
    not have read it: the server distills it into a referee-only script plus a
    spoiler-free player hook, and only the hook ever leaves the server."""
    text: Optional[str] = None              # pasted module text, or
    filename: Optional[str] = None          # uploaded file's name...
    data_b64: Optional[str] = None          # ...and its bytes, base64
    clear: bool = False                     # true = remove the loaded module


class CampaignUnlock(BaseModel):
    password: str = ""


class CampaignPassword(BaseModel):
    password: str = ""                       # blank clears the lock (reopens)


class AdminReset(BaseModel):
    admin_password: str = ""                 # the master key (CEPHEUS_ADMIN_PASSWORD)
    new_password: str = ""                   # blank reopens the campaign


class TurnReq(BaseModel):
    input: str
    actor: Optional[str] = None
    mode: str = "ai"


class ToolReq(BaseModel):
    name: str
    arguments: Dict[str, Any] = {}


class CharacterCreate(BaseModel):
    name: str
    terms: int = 4
    location: Optional[str] = None
    npc: bool = False


class CharacterNotes(BaseModel):
    notes: str = ""


class Login(BaseModel):
    password: str

class AuthBody(BaseModel):
    username: str
    password: str

class RejectReq(BaseModel):
    note: str = ""


class ShipCreate(BaseModel):
    ship_class: str
    name: Optional[str] = None
    armor: int = 0
    fuel: int = 0
    location: Optional[str] = None


class TradeQuote(BaseModel):
    good_d66: str
    world_codes: Optional[List[str]] = None
    world_hex: Optional[str] = None
    side: str = "buy"
    broker_skill: int = 0                   # ignored if character_id is given
    character_id: Optional[int] = None      # the trader: their Broker skill rules


class TransferReq(BaseModel):
    source: str                             # id/name, or 'party' for the ledger
    target: str
    amount: int
    reason: str = ""


class TradeBuy(BaseModel):
    """Two roles, two people. The BROKER's skill sets the price; the FUNDER's
    credits pay for it. They are usually the same person and needn't be --
    the silver-tongued face of the crew is rarely the one holding the purse.
    `character_id` is the old single-role field, kept so the bridge UI keeps
    working; it means both unless a broker or payer is named explicitly."""
    good_d66: str
    tons: int
    price_per_ton: int
    ship_id: Optional[int] = None
    origin_hex: Optional[str] = None
    character_id: Optional[int] = None      # legacy: broker AND payer
    broker_id: Optional[int] = None         # whose Broker skill haggled
    payer_id: Optional[Any] = None          # who pays; 'party' = the ledger


class BattleStart(BaseModel):
    combatants: List[Dict[str, Any]]
    range_band: str = "Short"
    note: str = ""


class BattleAttack(BaseModel):
    attacker: str
    target: str
    roll: Optional[List[int]] = None      # the player's own dice, if thrown
    other_dm: int = 0


class LoreReq(BaseModel):
    title: str
    body: str = ""
    category: str = "fact"


class LoreDecision(BaseModel):
    approve: bool
    reason: str = ""


class StrikeReq(BaseModel):
    reason: str = ""


class DateReq(BaseModel):
    date: str
    reason: str = ""


class JumpReq(BaseModel):
    ship_id: int
    destination: str                        # world name or hex
    crew_ids: Optional[List[int]] = None    # None = everyone standing there


class RefuelReq(BaseModel):
    ship_id: int
    tons: Optional[int] = None              # None = fill the tanks
    kind: str = "refined"
    payer: Optional[str] = "party"


class TradeSell(BaseModel):
    cargo_lot_id: int
    price_per_ton: int
    character_id: Optional[int] = None      # legacy: broker AND payee
    broker_id: Optional[int] = None         # whose Broker skill haggled
    payee_id: Optional[Any] = None          # who pockets it; 'party' = ledger


class PersonalCombat(BaseModel):
    a_id: int
    b_id: int
    a_weapon: str = "Unarmed Strike"
    b_weapon: str = "Unarmed Strike"
    a_armor: Optional[str] = None
    b_armor: Optional[str] = None
    range: str = "Short"
    rounds: int = 20


class ShipCombat(BaseModel):
    a_ship_id: int
    b_ship_id: int
    a_weapons: List[str] = []
    b_weapons: List[str] = []
    a_gunner: int = 1
    b_gunner: int = 1
    range: str = "Medium"
    max_turns: int = 40


class ChargenStart(BaseModel):
    name: Optional[str] = None      # optional: characters are named at the END
    location: Optional[str] = None


class ChargenChoose(BaseModel):
    payload: Dict[str, Any] = {}


class ManualCharacter(BaseModel):
    name: str
    upp: str = "777777"
    skills: Dict[str, int] = {}
    credits: int = 0
    careers: List[Dict[str, Any]] = []
    gear: List[str] = []
    age: Optional[int] = None
    location: Optional[str] = None
    npc: bool = False


def _rows(rows):
    return [dict(r) for r in rows]


def create_app(db_path: str = ":memory:", client: Optional[LLMClient] = None) -> FastAPI:
    app = FastAPI(title="Emporos Campaign Server")
    state = AppState(db_path, client)
    app.state.cepheus = state

    # --- auth: per-user accounts (traditional login) --------------------
    # Replaces the old site-wide crew password. Users register a username +
    # password (stored as salted PBKDF2 by the repo); a signed cookie keeps
    # them logged in. Per-campaign passwords still lock individual worlds.
    import hashlib
    import hmac as _hmac
    import secrets as _secrets

    def _session_secret() -> bytes:
        env = os.environ.get("EMPOROS_SESSION_SECRET")
        if env:
            return env.encode()
        base = os.path.dirname(db_path) if db_path not in (":memory:",) else ""
        path = os.path.join(base or ".", ".emporos_secret")
        try:
            with open(path) as f:
                return f.read().strip().encode()
        except (FileNotFoundError, OSError):
            s = _secrets.token_hex(32)
            try:
                with open(path, "w") as f:
                    f.write(s)
            except OSError:
                pass                      # :memory: / read-only fs: per-process secret
            return s.encode()

    _SECRET = _session_secret()
    SESSION_COOKIE = "emporos_user"
    SESSION_DAYS = 90

    def _sign_session(uid: int) -> str:
        msg = str(uid)
        return msg + "." + _hmac.new(_SECRET, msg.encode(), hashlib.sha256).hexdigest()

    def _uid_from_token(token) -> Optional[int]:
        if not token or "." not in token:
            return None
        msg, sig = token.rsplit(".", 1)
        good = _hmac.new(_SECRET, msg.encode(), hashlib.sha256).hexdigest()
        if not _hmac.compare_digest(sig, good):
            return None
        try:
            return int(msg)
        except ValueError:
            return None

    def _uid(request) -> Optional[int]:
        uid = _uid_from_token(request.cookies.get(SESSION_COOKIE))
        if uid is None:
            return None
        return uid if state.repo.get_user(uid) else None

    # Optional master key: lets an admin force-reset any campaign's password
    # (the recovery path for a forgotten campaign password). Off unless set.
    ADMIN_PASSWORD = os.environ.get("CEPHEUS_ADMIN_PASSWORD")
    LOGIN_HTML = """<!doctype html><meta charset=utf-8><title>Emporos — Login</title>
<body style="background:#06070c;color:#e8ecf5;font-family:Helvetica,Arial;display:flex;
height:100vh;align-items:center;justify-content:center;margin:0">
<form onsubmit="return doLogin(event)" style="background:#0d1019;border:1px solid #222c45;
padding:22px 28px;border-radius:10px;width:min(460px,92vw)">
<img id=lg alt="Emporos" style="width:100%;max-height:26vh;object-fit:contain;border-radius:8px;margin-bottom:8px"
 onerror="this.style.display='none';document.getElementById('lt').style.display='block'">
<h2 id=lt style="margin:0 0 6px;letter-spacing:1px;display:none">EMPOROS</h2>
<div style="color:#8a93a6;font-size:12px;margin:0 0 12px">the traveling merchant &middot; a 2d6 sci-fi RPG</div>
<input id=un placeholder="Username" autofocus autocomplete=username
style="width:100%;padding:9px;background:#11151f;color:#e8ecf5;border:1px solid #222c45;border-radius:6px">
<input id=pw type=password placeholder="Password" autocomplete=current-password
style="width:100%;margin-top:8px;padding:9px;background:#11151f;color:#e8ecf5;border:1px solid #222c45;border-radius:6px">
<button type=submit style="margin-top:10px;width:100%;padding:9px;background:#11151f;color:#e8ecf5;
border:1px solid #49c0b8;border-radius:6px;cursor:pointer">Sign In</button>
<button type=button id=reg style="margin-top:8px;width:100%;padding:9px;background:#11151f;color:#8a93a6;
border:1px solid #222c45;border-radius:6px;cursor:pointer">New here? Create an account</button>
<div id=err style="color:#ef4146;margin-top:8px;font-size:13px"></div>
<div style="margin-top:12px;font-size:13px">
<a href="/universe" style="color:#d8b45a;text-decoration:none">&#10142; New here? Read about THE EMPORION &mdash; the universe</a></div>
<div style="margin-top:10px;font-size:11px;color:#8a93a6;line-height:1.55">
A free, unofficial fan production. Traveller &copy; Mongoose Publishing &middot;
compatible with the Cepheus Engine SRD (Samardan Press) &middot;
<a href="/legal" style="color:#49c0b8">full notice</a><br>
<a href="https://discord.gg/WWSaSBj9Cj" style="color:#7fd1ff;text-decoration:none">&#9876; Community: The Lyceum on Discord</a></div>
</form>
<script>
document.getElementById('lg').src='/logo/'+(Math.random()<0.5?'emporos_a.jpg':'emporos_b.jpg');
async function post(path){
 const username=document.getElementById('un').value.trim();
 const password=document.getElementById('pw').value;
 if(!username||!password){document.getElementById('err').textContent='Enter a username and password.';return;}
 const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({username,password})});
 if(r.ok){location.href='/';return;}
 let d={};try{d=await r.json();}catch(e){}
 document.getElementById('err').textContent=d.detail||'That didn\\u2019t work.';}
function doLogin(e){e.preventDefault();post('/api/auth/login');return false;}
document.getElementById('reg').onclick=()=>post('/api/auth/register');</script></body>"""

    LEGAL_HTML = """<!doctype html><meta charset=utf-8><title>Legal &amp; Attribution</title>
<body style="background:#06070c;color:#e8ecf5;font-family:Helvetica,Arial;margin:0;padding:40px 16px;
display:flex;justify-content:center"><div style="max-width:640px;line-height:1.65;font-size:14px">
<h2 style="letter-spacing:1px">LEGAL &amp; ATTRIBUTION</h2>
<p>This is a <b>free, non-commercial fan production</b>. No payment is accepted and nothing here is for sale.</p>
<p><b>Traveller.</b> The Traveller game in all forms is owned by Mongoose Publishing.
Copyright &copy; 1977&ndash;2026 Mongoose Publishing. This game is unofficial and is not
affiliated with, or endorsed by, Mongoose Publishing. Charted Space setting material
(including the Spinward Marches) is used non-commercially in the spirit of Mongoose
Publishing's Fair Use Policy.</p>
<p><b>Cepheus Engine.</b> Game rules are derived from the Cepheus Engine System Reference
Document and are used under the Open Game License v1.0a. &ldquo;Cepheus Engine&rdquo; and
&ldquo;Samardan Press&rdquo; are trademarks of Samardan Press. This game is not affiliated
with Samardan Press, and no challenge to any trademark is intended.</p>
<p><b>Astrographic data</b> derives from official data published through the
Traveller Map project (travellermap.com), used for personal, non-commercial play.</p>
<p style="color:#8a93a6">Questions or takedown requests: contact the operator via
<a href="https://discord.gg/WWSaSBj9Cj" style="color:#7fd1ff">The Lyceum on Discord</a>.</p>
<p><a href="/" style="color:#49c0b8">&larr; back to the game</a></p>
</div></body>"""

    @app.middleware("http")
    async def _auth(request, call_next):
        path = request.url.path
        # Outer gate: a logged-in user account.
        exempt = (path in ("/login", "/legal") or path.startswith("/favicon")
                  or path.startswith("/logo/") or path.startswith("/api/auth/")
                  or path.startswith("/universe")
                  or path == "/api/admin/backup")   # its own token gate below
        if not exempt and _uid(request) is None:
            if path.startswith("/api"):
                return JSONResponse({"detail": "authentication required"},
                                    status_code=401)
            return RedirectResponse("/login")
        # Inner gate: a per-campaign password. Any /api/campaigns/<cid>/... route
        # needs that campaign unlocked, independent of the site gate. The /unlock
        # endpoint is exempt (it's how you get in).
        camp = _campaign_in_path(path)
        if camp is not None:
            cid, sub = camp
            if sub not in ("unlock", "reset_password"):
                stored = state.repo.campaign_password_hash(cid)
                if stored and request.cookies.get(_camp_cookie(cid)) != stored:
                    return JSONResponse(
                        {"detail": "campaign locked",
                         "need": "campaign_password", "campaign_id": cid},
                        status_code=403)
        return await call_next(request)

    @app.get("/login")
    def login_page():
        return HTMLResponse(LOGIN_HTML)

    @app.get("/legal")
    def legal_page():
        """Public attribution & fair-use notice (exempt from the crew gate)."""
        return HTMLResponse(LEGAL_HTML)

    @app.get("/universe")
    def universe_page():
        """The public front window: player-safe lore of the Emporion."""
        return FileResponse(os.path.join(STATIC, "universe.html"),
                            headers={"Cache-Control": "no-store, max-age=0"})

    @app.get("/universe/map.svg")
    def universe_map():
        return FileResponse(os.path.join(STATIC, "emporion_map.svg"),
                            headers={"Cache-Control": "public, max-age=86400"})

    _LOGOS = {"emporos_a.jpg", "emporos_b.jpg"}   # rotating banners (public, pre-auth)
    @app.get("/logo/{name}")
    def logo(name: str):
        if name not in _LOGOS:
            return JSONResponse({"detail": "not found"}, status_code=404)
        return FileResponse(os.path.join(STATIC, name),
                            headers={"Cache-Control": "public, max-age=86400"})

    def _session_response(payload, uid):
        resp = JSONResponse(payload)
        resp.set_cookie(SESSION_COOKIE, _sign_session(uid), httponly=True,
                        samesite="lax", max_age=SESSION_DAYS * 86400)
        return resp

    @app.post("/api/auth/register")
    def auth_register(body: AuthBody):
        username = (body.username or "").strip()
        if not (2 <= len(username) <= 32):
            return JSONResponse({"detail": "username must be 2-32 characters"},
                                status_code=400)
        if len(body.password) < 4:
            return JSONResponse({"detail": "password must be at least 4 characters"},
                                status_code=400)
        with state.lock:
            uid = state.repo.create_user(username, body.password)
        if uid is None:
            return JSONResponse({"detail": "that username is taken"},
                                status_code=409)
        return _session_response({"ok": True, "user": {"id": uid,
                                                       "username": username}}, uid)

    @app.post("/api/auth/login")
    def auth_login(body: AuthBody):
        row = state.repo.verify_user(body.username, body.password)
        if not row:
            return JSONResponse({"detail": "wrong username or password"},
                                status_code=401)
        return _session_response({"ok": True, "user": {"id": row["id"],
                                                       "username": row["username"]}},
                                 row["id"])

    @app.get("/api/auth/whoami")
    def auth_whoami(request: Request):
        uid = _uid(request)
        if uid is None:
            return {}
        u = state.repo.get_user(uid)
        return {"user": {"id": u["id"], "username": u["username"]}}

    @app.post("/logout")
    def logout(request: Request):
        """Clear the account session and every campaign-unlock cookie."""
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(SESSION_COOKIE)
        resp.delete_cookie("cepheus_auth")          # legacy crew-gate cookie
        for name in request.cookies:
            if name.startswith("cepheus_camp_"):
                resp.delete_cookie(name)
        return resp

    @app.get("/")
    def index():
        # no-store: every visit fetches the CURRENT client, so deploys never
        # leave players running a stale page against a new server.
        return FileResponse(os.path.join(STATIC, "index.html"),
                            headers={"Cache-Control": "no-store, max-age=0"})

    # Changes automatically on every Fly deploy (falls back to app.py's mtime
    # for local dev). The client compares this to show a "refresh" banner.
    APP_VERSION = (os.environ.get("FLY_IMAGE_REF")
                   or str(int(os.path.getmtime(os.path.abspath(__file__)))))

    @app.get("/api/health")
    def health():
        return {"ok": True, "model": type(state.client).__name__,
                "ai_online": not isinstance(state.client, NoKeyClient),
                "version": APP_VERSION}

    @app.get("/api/admin/backup")
    def admin_backup(request: Request):
        """Pull a fresh, consistent snapshot of the whole database. Guarded by
        its own shared-secret token (CEPHEUS_BACKUP_TOKEN); the feature simply
        does not exist unless the secret is set. Meant for the owner's
        off-machine backup script, not for players."""
        import hmac as _hmac
        secret = os.environ.get("CEPHEUS_BACKUP_TOKEN", "")
        if not secret:
            raise HTTPException(404, "not found")
        supplied = (request.headers.get("X-Backup-Token")
                    or request.query_params.get("token") or "")
        if not _hmac.compare_digest(supplied, secret):
            raise HTTPException(403, "bad token")
        if db_path == ":memory:":
            raise HTTPException(400, "in-memory database has no backups")
        dest = AppState.backup_once(db_path)
        if not dest:
            raise HTTPException(500, "backup failed")
        return FileResponse(dest, media_type="application/octet-stream",
                            filename=os.path.basename(dest))

    @app.get("/api/campaigns")
    def campaigns():
        # Expose whether each campaign is locked, but never the hash itself.
        out = []
        for r in state.repo.list_campaigns():
            d = dict(r)
            d["locked"] = bool(d.pop("password_hash", None))
            d.pop("scenario_notes", None)   # referee eyes only, never serialized
            out.append(d)
        return out

    @app.post("/api/campaigns")
    def create_campaign(body: CampaignCreate, request: Request):
        with state.lock:
            cid = state.repo.create_campaign(
                body.name, current_date=body.current_date, password=body.password,
                owner_user_id=_uid(request))
            imported = 0
            if body.import_sector:
                path = find_sector_file(body.import_sector)
                if path:
                    imported = state.repo.import_sector_file(cid, path)
                    if body.import_sector == "Emporion" and imported:
                        _seed_emporion_lore(state.repo, cid)
            # Port of origin: look the chosen reach's great port up by name in
            # whatever sector this campaign just imported.
            start = None
            port = REACH_PORTS.get((body.start_reach or "").strip().lower())
            if port:
                row = state.repo.find_world(cid, port)
                if row:
                    state.repo.conn.execute(
                        "UPDATE campaign SET start_hex=?, start_world=? WHERE id=?",
                        (row["hex"], row["name"], cid))
                    state.repo.conn.commit()
                    start = {"world": row["name"], "hex": row["hex"]}
                    state.repo.record_event(
                        cid, "campaign", "Port of origin: {} ({})".format(
                            row["name"], row["hex"]))
        stored = state.repo.campaign_password_hash(cid)
        resp = JSONResponse({"id": cid, "name": body.name, "start": start,
                             "worlds_imported": imported, "locked": bool(stored)})
        # The creator is auto-unlocked for the world they just made.
        if stored:
            resp.set_cookie(_camp_cookie(cid), stored, httponly=True, samesite="lax")
        return resp

    @app.post("/api/campaigns/{cid}/claim")
    def claim_campaign(cid: int, request: Request):
        """Attach a pre-accounts (ownerless) campaign to the caller's account.
        The middleware already required the campaign's password cookie if one
        is set, so whoever can enter the world may claim it -- once."""
        if not state.repo.get_campaign(cid):
            raise HTTPException(404, "no such campaign")
        uid = _uid(request)
        with state.lock:
            owner = state.repo.campaign_owner(cid)
            if owner is not None:
                raise HTTPException(409, "this world already has an owner")
            state.repo.conn.execute(
                "UPDATE campaign SET owner_user_id=? WHERE id=?", (uid, cid))
            state.repo.conn.commit()
            u = state.repo.get_user(uid)
            state.repo.record_event(
                cid, "campaign", "World claimed by {}".format(
                    u["username"] if u else "its new owner"))
        return {"ok": True, "owner_user_id": uid}

    @app.post("/api/campaigns/{cid}/unlock")
    def unlock_campaign(cid: int, body: CampaignUnlock):
        if not state.repo.get_campaign(cid):
            raise HTTPException(404, "no such campaign")
        stored = state.repo.campaign_password_hash(cid)
        if stored and not state.repo.check_campaign_password(cid, body.password):
            return JSONResponse({"ok": False}, status_code=401)
        resp = JSONResponse({"ok": True, "locked": bool(stored)})
        if stored:
            resp.set_cookie(_camp_cookie(cid), stored, httponly=True, samesite="lax")
        return resp

    @app.post("/api/campaigns/{cid}/password")
    def set_campaign_password(cid: int, body: CampaignPassword, request: Request):
        # Guarded by the middleware: an already-locked campaign requires its
        # cookie to reach here. Owned campaigns additionally require the OWNER --
        # legacy (pre-accounts) campaigns keep the old inside-can-change rule.
        if not state.repo.get_campaign(cid):
            raise HTTPException(404, "no such campaign")
        owner = state.repo.campaign_owner(cid)
        if owner is not None and owner != _uid(request):
            return JSONResponse(
                {"ok": False, "detail": "only this world's owner can change "
                 "its password"}, status_code=403)
        with state.lock:
            state.repo.set_campaign_password(cid, body.password)
        stored = state.repo.campaign_password_hash(cid)
        resp = JSONResponse({"ok": True, "locked": bool(stored)})
        if stored:
            resp.set_cookie(_camp_cookie(cid), stored, httponly=True, samesite="lax")
        else:
            resp.delete_cookie(_camp_cookie(cid))
        return resp

    @app.post("/api/campaigns/{cid}/reset_password")
    def reset_campaign_password(cid: int, body: AdminReset):
        # The recovery path for a forgotten campaign password. Exempt from the
        # per-campaign gate (you're locked out, so you have no cookie), but it
        # demands the master key instead.
        if not ADMIN_PASSWORD:
            return JSONResponse(
                {"ok": False, "detail": "admin reset is not configured "
                 "(set CEPHEUS_ADMIN_PASSWORD to enable it)"}, status_code=403)
        if body.admin_password != ADMIN_PASSWORD:
            return JSONResponse({"ok": False, "detail": "wrong admin password"},
                                status_code=401)
        if not state.repo.get_campaign(cid):
            raise HTTPException(404, "no such campaign")
        with state.lock:
            state.repo.set_campaign_password(cid, body.new_password)
        stored = state.repo.campaign_password_hash(cid)
        resp = JSONResponse({"ok": True, "locked": bool(stored)})
        # Log the admin in to the campaign they just reset.
        if stored:
            resp.set_cookie(_camp_cookie(cid), stored, httponly=True, samesite="lax")
        else:
            resp.delete_cookie(_camp_cookie(cid))
        return resp

    MODULE_DIGEST_PROMPT = (
        "You are prepping a published adventure module so an AI referee can "
        "run it for players who have NOT read it and must not be spoiled. "
        "From the module text provided, output EXACTLY two sections with "
        "these exact delimiters and nothing else:\n\n"
        "===PLAYER HOOK===\n"
        "Two or three sentences a player may safely read: the setup and the "
        "invitation only. No secrets, no twists, no creature names, nothing "
        "from behind the screen.\n\n"
        "===REFEREE BRIEF===\n"
        "A compact secret script the referee will re-read every turn. Under "
        "700 words, plain text, present tense, written as instructions to "
        "the referee. Include: the real situation and every secret; key "
        "locations with enough geography to run them (invent specifics the "
        "module leaves out, e.g. maps it tells the referee to draw); the "
        "timeline and its trigger events; how it can end well and how it "
        "can end badly. End with a CAST section listing, one per line, "
        "every named person (name -- role, motive), vessel (name -- class), "
        "and creature (name -- size tiny/small/medium/large/huge/monstrous, "
        "ferocity timid/defensive/aggressive/predator, natural weapon, "
        "notable traits). Do NOT write numeric stats for anyone in the cast "
        "-- the referee materializes each entry with its tool (generate_npc "
        "/ create_ship / generate_creature) the moment it first appears, "
        "rolling real dice live at the table. If the module's setting "
        "conflicts with the campaign universe, add one line on how to "
        "reskin it in place.")

    def _pdf_text(data: bytes) -> str:
        try:
            from io import BytesIO
            import pypdf
            rd = pypdf.PdfReader(BytesIO(data))
            return "\n".join((p.extract_text() or "") for p in rd.pages)
        except ImportError:
            raise HTTPException(
                400, "PDF support needs the 'pypdf' package on the server -- "
                     "add pypdf to requirements and redeploy, or paste the "
                     "module text instead")
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(400, "could not read that PDF: {}".format(e))

    @app.post("/api/campaigns/{cid}/module")
    def load_module(cid: int, body: ModuleLoad, request: Request):
        if not state.repo.get_campaign(cid):
            raise HTTPException(404, "no such campaign")
        owner = state.repo.campaign_owner(cid)
        if owner is not None and owner != _uid(request):
            raise HTTPException(403, "only this world's owner can load or "
                                     "remove a module")
        if body.clear:
            with state.lock:
                state.repo.conn.execute(
                    "UPDATE campaign SET scenario_notes='', scenario_hook='' "
                    "WHERE id=?", (cid,))
                state.repo.conn.commit()
                state.repo.record_event(cid, "campaign",
                                        "Module removed by the owner.")
            return {"ok": True, "cleared": True}
        raw = (body.text or "").strip()
        if not raw and body.data_b64:
            import base64
            try:
                data = base64.b64decode(body.data_b64)
            except Exception:
                raise HTTPException(400, "bad file data")
            name = (body.filename or "").lower()
            if name.endswith(".pdf") or data[:5] == b"%PDF-":
                raw = _pdf_text(data).strip()
            else:
                raw = data.decode("utf-8", "replace").strip()
        if not raw:
            raise HTTPException(400, "no module text -- paste it or upload "
                                     "a .pdf/.txt/.md file")
        if len(raw) < 200:
            raise HTTPException(400, "that looks too short to be a module "
                                     "({} characters)".format(len(raw)))
        raw = raw[:60000]
        # One model call, OUTSIDE the state lock: distill into a sealed
        # referee brief + a spoiler-free hook. Only the hook ever goes back.
        hook, brief = "", ""
        if not isinstance(state.client, NoKeyClient):
            try:
                r = state.client.chat([
                    {"role": "system", "content": MODULE_DIGEST_PROMPT},
                    {"role": "user", "content": raw[:24000]}])
                txt = r.text or ""
                if "===REFEREE BRIEF===" in txt:
                    head, brief = txt.split("===REFEREE BRIEF===", 1)
                    hook = head.replace("===PLAYER HOOK===", "").strip()
                    brief = brief.strip()
            except Exception:
                hook, brief = "", ""
        if not brief:
            # AI offline or digest failed: seal the raw text itself. Less
            # compact, equally secret.
            brief = raw[:8000]
        if not hook:
            hook = ("A new adventure has been placed in the referee's hands. "
                    "Tell the referee when you're ready to begin.")
        with state.lock:
            state.repo.conn.execute(
                "UPDATE campaign SET scenario_notes=?, scenario_hook=? "
                "WHERE id=?", (brief, hook, cid))
            state.repo.conn.commit()
            state.repo.record_event(cid, "campaign",
                                    "Module loaded. Hook: {}".format(hook[:300]))
        return {"ok": True, "hook": hook}

    def _start_loc(cid, loc):
        """A character's default location: the campaign's port of origin."""
        if loc:
            return loc
        c = state.repo.get_campaign(cid)
        try:
            return c["start_hex"] if c and c["start_hex"] else None
        except (KeyError, IndexError):
            return None

    @app.get("/api/campaigns/{cid}")
    def campaign(cid: int):
        c = state.repo.get_campaign(cid)
        if not c:
            raise HTTPException(404, "no such campaign")
        d = dict(c)
        d.pop("scenario_notes", None)       # referee eyes only, never serialized
        return {"campaign": d,
                "worlds": len(state.repo.list_worlds(cid)),
                "characters": len(state.repo.list_characters(cid)),
                "ships": len(state.repo.list_ships(cid))}

    @app.get("/api/campaigns/{cid}/worlds")
    def worlds(cid: int, sector: Optional[str] = None):
        # World notes are the referee's private memory (lairs, secrets,
        # corrections) -- players get the survey data, not the margins.
        out = _rows(state.repo.list_worlds(cid, sector))
        for w in out:
            w.pop("notes", None)
        return out

    @app.get("/api/campaigns/{cid}/characters")
    def characters(cid: int):
        return _rows(state.repo.list_characters(cid))

    @app.delete("/api/campaigns/{cid}/characters/{chid}")
    async def delete_character(cid: int, chid: int, request: Request):
        row = state.repo.get_character(chid)
        if not row or row["campaign_id"] != cid:
            raise HTTPException(404, "no such character")
        # Permissions: NPCs and unclaimed PCs keep the legacy anyone-inside
        # rule; a CLAIMED PC can only be deleted by its owner or the world owner.
        char_owner = row["owner_user_id"]
        if char_owner and not row["is_npc"]:
            uid = _uid(request)
            if uid not in (char_owner, state.repo.campaign_owner(cid)):
                return JSONResponse(
                    {"detail": "that character belongs to another player"},
                    status_code=403)
        with state.lock:
            ok = state.repo.delete_character(chid)
        if not ok:
            raise HTTPException(404, "no such character")
        await state.manager.broadcast(cid, {"type": "character_deleted", "id": chid})
        return {"deleted": chid}

    @app.post("/api/campaigns/{cid}/characters/{chid}/claim")
    async def claim_character(cid: int, chid: int, request: Request):
        """Attach a legacy (pre-accounts) PC to the calling account."""
        uid = _uid(request)
        row = state.repo.get_character(chid)
        if not row or row["campaign_id"] != cid:
            raise HTTPException(404, "no such character")
        with state.lock:
            ok = state.repo.claim_character(chid, uid)
        if not ok:
            return JSONResponse(
                {"detail": "that character is an NPC or already claimed"},
                status_code=409)
        await state.manager.broadcast(cid, {"type": "character_claimed",
                                            "id": chid, "user_id": uid})
        return {"ok": True, "id": chid}

    @app.post("/api/campaigns/{cid}/characters/{chid}/notes")
    async def set_character_notes(cid: int, chid: int, body: CharacterNotes,
                                  request: Request):
        """The player's notes editor: replace a character's notes (trim the
        referee's appended career-record blob down to what the player wants on
        the card). Same ownership rule as delete -- a claimed PC's notes are
        the owner's or the world owner's to edit."""
        row = state.repo.get_character(chid)
        if not row or row["campaign_id"] != cid:
            raise HTTPException(404, "no such character")
        char_owner = row["owner_user_id"]
        if char_owner and not row["is_npc"]:
            uid = _uid(request)
            if uid not in (char_owner, state.repo.campaign_owner(cid)):
                return JSONResponse(
                    {"detail": "that character belongs to another player"},
                    status_code=403)
        with state.lock:
            ok = state.repo.set_character_notes(chid, body.notes)
        if not ok:
            raise HTTPException(404, "no such character")
        await state.manager.broadcast(cid, {"type": "character_notes",
                                            "id": chid})
        return {"ok": True, "id": chid, "notes": body.notes}

    @app.post("/api/campaigns/{cid}/characters")
    async def create_character(cid: int, body: CharacterCreate, request: Request):
        from engine import chargen
        with state.lock:
            terms = max(1, min(body.terms, 7))
            char = chargen.generate(name=body.name,
                                    chooser=chargen.RandomChooser(target_terms=terms))
            chid = state.repo.save_character(cid, char, is_npc=body.npc,
                                             location=_start_loc(cid, body.location),
                                             owner_user_id=_uid(request))
        summary = {"id": chid, "name": char.name, "upp": char.chars.upp,
                   "skills": char.skills, "credits": char.credits,
                   "careers": [s.career for s in char.history],
                   "alive": char.alive}
        await state.manager.broadcast(cid, {"type": "character", "summary": summary})
        return summary

    # Interactive lifepath chargen is persisted to the DB (seed + ordered
    # choices) and the live session is rebuilt by deterministic replay on every
    # request. That means a build survives a server restart, redeploy, or a
    # player wandering off mid-creation -- nothing lives only in memory.
    def _load_chargen(cid: int, sid: str):
        row = state.repo.conn.execute(
            "SELECT * FROM chargen_session WHERE id=? AND campaign_id=?",
            (sid, cid)).fetchone()
        if not row:
            return None
        from engine.lifepath import LifepathSession
        sess = LifepathSession(name=row["name"], seed=row["seed"])
        choices = json.loads(row["choices_json"] or "[]")
        for ch in choices:
            if sess.complete:
                break
            sess.choose(ch)
        return row, sess, choices

    @app.post("/api/campaigns/{cid}/chargen/start")
    def chargen_start(cid: int, body: ChargenStart):
        from engine.lifepath import LifepathSession
        import uuid
        import random
        seed = random.randint(0, 2**31 - 1)
        sid = uuid.uuid4().hex[:12]
        # No name up front. The build carries a readable, unique handle (so
        # several players building at once stay distinct); the player names the
        # finished character at the final step. A provided name is still honored.
        handle = (body.name or "").strip() or "Recruit {}".format(sid[:4].upper())
        sess = LifepathSession(name=handle, seed=seed)
        with state.lock:
            state.repo.conn.execute(
                "INSERT INTO chargen_session "
                "(id, campaign_id, name, seed, choices_json, location_hex) "
                "VALUES (?,?,?,?,?,?)",
                (sid, cid, handle, seed, "[]", _start_loc(cid, body.location)))
            state.repo.conn.commit()
        return {"session_id": sid, "pending": sess.pending()}

    @app.get("/api/campaigns/{cid}/chargen/{sid}")
    def chargen_state(cid: int, sid: str):
        loaded = _load_chargen(cid, sid)
        if not loaded:
            raise HTTPException(404, "no such chargen session")
        _row, sess, _choices = loaded
        return {"session_id": sid, "pending": sess.pending()}

    @app.post("/api/campaigns/{cid}/chargen/{sid}/choose")
    async def chargen_choose(cid: int, sid: str, body: ChargenChoose,
                             request: Request):
        done = False
        with state.lock:
            loaded = _load_chargen(cid, sid)
            if not loaded:
                raise HTTPException(404, "no such chargen session")
            row, sess, choices = loaded
            if sess.complete:
                raise HTTPException(409, "chargen session already complete")
            pending = sess.choose(body.payload)
            choices = choices + [body.payload or {}]
            if pending.get("step") == "complete":
                char = sess.result()
                chid = state.repo.save_character(cid, char, is_npc=False,
                                                 location=row["location_hex"],
                                                 owner_user_id=_uid(request))
                state.repo.conn.execute(
                    "DELETE FROM chargen_session WHERE id=?", (sid,))
                state.repo.conn.commit()
                done = True
            else:
                state.repo.conn.execute(
                    "UPDATE chargen_session SET choices_json=?, "
                    "updated_at=datetime('now') WHERE id=?",
                    (json.dumps(choices), sid))
                state.repo.conn.commit()
        if done:
            await state.manager.broadcast(
                cid, {"type": "character",
                      "summary": {"name": char.name, "upp": char.chars.upp}})
            return {"pending": pending, "character_id": chid}
        return {"pending": pending}

    @app.post("/api/campaigns/{cid}/characters/manual")
    async def create_manual(cid: int, body: ManualCharacter, request: Request):
        from engine.chargen import Character, CareerStint
        from engine.characteristics import Characteristics
        ch = Character(name=body.name)
        try:
            ch.chars = Characteristics.from_upp(body.upp)
        except Exception:
            pass
        ch.skills = dict(body.skills)
        ch.credits = int(body.credits)
        ch.benefits = list(body.gear)
        ch.history = [CareerStint(career=c.get("career", "?"),
                                  terms=int(c.get("terms", 0)),
                                  rank=int(c.get("rank", 0))) for c in body.careers]
        ch.age = body.age if body.age is not None else 18 + 4 * ch.total_terms
        with state.lock:
            chid = state.repo.save_character(cid, ch, is_npc=body.npc,
                                             location=_start_loc(cid, body.location),
                                             owner_user_id=_uid(request))
        await state.manager.broadcast(
            cid, {"type": "character",
                  "summary": {"name": ch.name, "upp": ch.chars.upp}})
        return {"id": chid, "name": ch.name, "upp": ch.chars.upp}

    @app.get("/api/campaigns/{cid}/ships")
    def ships(cid: int):
        return _rows(state.repo.list_ships(cid))

    @app.get("/api/ship_classes")
    def ship_classes():
        from engine import ships as ships_mod
        out = []
        for name in ships_mod.ship_names():
            s = ships_mod.ship(name)
            out.append({"name": name, "tl": s.tl, "tonnage": s.tonnage,
                        "jump": s.jump, "maneuver_g": s.maneuver_g,
                        "cargo_tons": s.cargo_tons, "cost_mcr": s.cost_mcr})
        return out

    @app.post("/api/campaigns/{cid}/ships")
    async def create_ship(cid: int, body: ShipCreate):
        from engine import ships as ships_mod
        try:
            design = ships_mod.ship(body.ship_class)
        except KeyError:
            raise HTTPException(400, "unknown ship class: {}".format(body.ship_class))
        with state.lock:
            sid = state.repo.save_ship(cid, design, name=body.name or design.name,
                                       armor=body.armor, fuel=body.fuel,
                                       location=body.location)
        row = dict(state.repo.get_ship(sid))
        await state.manager.broadcast(cid, {"type": "ship", "id": sid,
                                            "name": row["name"]})
        return row

    @app.delete("/api/campaigns/{cid}/ships/{sid}")
    async def delete_ship(cid: int, sid: int):
        with state.lock:
            ok = state.repo.delete_ship(sid)
        if not ok:
            raise HTTPException(404, "no such ship")
        await state.manager.broadcast(cid, {"type": "ship_deleted", "id": sid})
        return {"deleted": sid}

    # --- trade ---
    def _world_codes(cid, hexv):
        if not hexv:
            return []
        row = state.repo.conn.execute(
            "SELECT remarks FROM world WHERE campaign_id=? AND hex=? LIMIT 1",
            (cid, hexv)).fetchone()
        if not row or not row["remarks"]:
            return []
        return [t for t in row["remarks"].split()
                if len(t) == 2 and t[:1].isupper() and t.isalpha()]

    @app.get("/api/trade/goods")
    def trade_goods():
        # From the trade_good TABLE now, not a module dict -- the catalogue
        # lives in the database.
        return [{"d66": g["d66"], "name": g["name"],
                 "base_price": g["base_price"], "illegal": g["illegal"]}
                for g in state.repo.catalog_goods()]

    def _trade_char_dm(row) -> int:
        """SRD: a trade check is Broker with INTELLIGENCE or SOCIAL STANDING.
        Take whichever serves the trader better -- sharp, or well-connected."""
        upp = (row["upp"] or "").strip()
        if len(upp) < 6:
            return 0
        try:
            from engine.characteristics import modifier
            from engine.pseudohex import from_pseudohex
            return max(modifier(from_pseudohex(upp[3])),   # INT
                       modifier(from_pseudohex(upp[5])))   # SOC
        except Exception:
            return 0

    def _char_broker(character_id):
        """The trader, judged by their own sheet. SRD Trade and Commerce:
        'Determining the purchase price: Broker, Intelligence or Social
        Standing, Average (+0)' -- so it is the Broker skill PLUS the better
        of the INT or SOC modifier. Returns (row, skill, characteristic_dm)."""
        row = state.repo.get_character(character_id)
        if not row:
            raise HTTPException(404, "no such character")
        # Broker level from the skill index -- a query, not a blob scan.
        return row, state.repo.broker_skill(character_id), _trade_char_dm(row)

    def _price_hex(cid, given=None):
        """Which port we are pricing against: the one named, else wherever the
        crew actually is."""
        if given:
            return given
        from referee.tools import RefereeContext, _party_hex
        return _party_hex(RefereeContext(repo=state.repo, campaign_id=cid))

    def _authoritative_price(cid, d66, side, hexv, skill, cdm):
        """Today's held price for this good at this port. One number, shared by
        the board, the quote window and the till."""
        from referee.tools import RefereeContext, held_price
        return held_price(RefereeContext(repo=state.repo, campaign_id=cid),
                          hexv, d66, side, skill=skill, cdm=cdm)

    @app.post("/api/campaigns/{cid}/trade/quote")
    def trade_quote(cid: int, body: TradeQuote):
        from engine import trade
        g = trade.good_by_d66(body.good_d66)
        broker, trader, cdm = body.broker_skill, None, 0
        if body.character_id:
            row, broker, cdm = _char_broker(body.character_id)
            trader = row["name"]
        hexv = _price_hex(cid, body.world_hex)
        held = _authoritative_price(cid, g.d66, body.side, hexv, broker, cdm)
        if held is None:
            # No charted port to price against. Quote from the codes given, and
            # SAY it is unbound -- the till will not honour a price that no
            # port stands behind.
            codes = body.world_codes or _world_codes(cid, body.world_hex)
            q = (trade.sale_price if body.side == "sell"
                 else trade.purchase_price)(g, codes, broker_skill=broker,
                                            char_dm=cdm)
            return {"good": g.name, "d66": g.d66, "base_price": g.base_price,
                    "side": body.side, "codes": codes, "result": q.result,
                    "percent": q.percent, "price_per_ton": q.price_per_ton,
                    "trader": trader, "broker_skill": broker,
                    "characteristic_dm": cdm, "indicative_only": True,
                    "note": "no charted world here -- indicative price only"}
        return {"good": g.name, "d66": g.d66, "base_price": g.base_price,
                "side": body.side, "codes": held["codes"],
                "percent": held["percent"],
                "price_per_ton": held["price_per_ton"],
                "hex": hexv, "date": held["date"],
                "trader": trader, "broker_skill": broker,
                "characteristic_dm": cdm}

    def _pocket(cid: int, spec, legacy_id=None):
        """Resolve who pays or gets paid. Returns (character_row_or_None, label);
        None means the shared party ledger. Accepts a character id, a name, the
        string 'party', or nothing at all -- in which case the legacy
        single-role character_id decides, exactly as it always did."""
        if spec is None or (isinstance(spec, str) and not spec.strip()):
            spec = legacy_id
        if spec is None:
            return None, "party"
        if isinstance(spec, str) and spec.strip().lower() in (
                "party", "ledger", "pool"):
            return None, "party"
        row = None
        try:
            row = state.repo.get_character(int(spec))
        except (TypeError, ValueError):
            row = state.repo.find_character_by_name(cid, str(spec))
        if not row or row["campaign_id"] != cid:
            raise HTTPException(404, "no such character in this campaign: "
                                     "{}".format(spec))
        return row, row["name"]

    def _broker_label(cid: int, broker_id, legacy_id=None):
        """Who did the talking. Recorded on the receipt even when they never
        touched the money -- a price is somebody's work, and the tape should
        say whose."""
        bid = broker_id if broker_id is not None else legacy_id
        if bid is None:
            return None, None
        row = state.repo.get_character(bid)
        if not row or row["campaign_id"] != cid:
            raise HTTPException(404, "no such broker in this campaign")
        return row["name"], state.repo.broker_skill(bid)

    @app.post("/api/campaigns/{cid}/trade/buy")
    async def trade_buy(cid: int, body: TradeBuy):
        from engine import trade
        g = trade.good_by_d66(body.good_d66)
        if body.tons <= 0 or body.price_per_ton < 0:
            raise HTTPException(400, "tons must be positive and price non-negative")
        with state.lock:
            broker, broker_skill = _broker_label(cid, body.broker_id,
                                                 body.character_id)
            payer, payer_label = _pocket(cid, body.payer_id, body.character_id)
            # THE PRICE IS THE ENGINE'S, NOT THE CALLER'S. This endpoint used
            # to bill whatever price_per_ton arrived in the body, so a hand-
            # rolled request -- or a stale page, or a devtools console -- could
            # buy Radioactives for Cr1 and leave a receipt that read as
            # honestly as any other. The tape is only worth something if the
            # numbers on it came from the dice.
            cdm = _trade_char_dm(state.repo.get_character(body.broker_id
                                                          or body.character_id)) \
                if (body.broker_id or body.character_id) else 0
            hexv = _price_hex(cid, body.origin_hex)
            held = _authoritative_price(cid, g.d66, "buy", hexv,
                                        broker_skill or 0, cdm)
            if held is None:
                raise HTTPException(
                    400, "no charted world at {} to buy from -- cargo needs a "
                         "port".format(hexv or "this position"))
            if body.price_per_ton != held["price_per_ton"]:
                raise HTTPException(
                    409, "the price moved: {} is Cr{:,}/ton here today, not "
                         "Cr{:,}. Refresh and try again.".format(
                             g.name, held["price_per_ton"], body.price_per_ton))
            # Read the quay BEFORE the hold and the purse, so "it's sold out"
            # is reported as sold out rather than as whichever other limit
            # happens to bind first. The actual spend still happens last.
            on_quay = int(held.get("tons_available", 0))
            if body.tons > on_quay:
                raise HTTPException(
                    409, "only {}t of {} left on the quay today; you asked "
                         "for {}t.".format(on_quay, g.name, body.tons))
            cost = held["price_per_ton"] * body.tons
            if payer is not None:
                funds = int(payer["credits"] or 0)
                if cost > funds:
                    raise HTTPException(
                        400, "{} has Cr{:,}; this costs Cr{:,}".format(
                            payer["name"], funds, cost))
            else:
                bal = state.repo.balance(cid)
                if cost > bal:
                    raise HTTPException(
                        400, "insufficient party funds: Cr{:,} available, "
                             "Cr{:,} needed".format(bal, cost))
            if body.ship_id:
                ship = state.repo.get_ship(body.ship_id)
                cap = None
                if ship:
                    try:
                        from engine import ships as ships_mod
                        cap = ships_mod.ship(ship["ship_class"]).cargo_tons
                    except Exception:
                        cap = None
                if cap is not None:
                    held = sum(int(l["tons"]) for l in state.repo.list_cargo(cid)
                               if l["ship_id"] == body.ship_id)
                    if held + body.tons > cap:
                        raise HTTPException(
                            400, "hold full: {}t capacity, {}t already "
                                 "stowed".format(cap, held))
            # Spend it off the quay LAST, once funds and hold space have both
            # cleared, so a refused purchase never eats stock nobody bought.
            from referee.tools import RefereeContext as _RC, take_stock
            took = take_stock(_RC(repo=state.repo, campaign_id=cid),
                              hexv, g.d66, body.tons)
            if not took.get("ok"):
                raise HTTPException(409, took["reason"])
            lid = state.repo.add_cargo_lot(cid, g.name, body.tons, body.price_per_ton,
                                           ship_id=body.ship_id, origin_hex=body.origin_hex)
            brokered = (" -- {} brokering at Broker-{}".format(
                broker, broker_skill) if broker else "")
            if payer is not None:
                bal = state.repo.adjust_character_credits(payer["id"], -cost)
                state.repo.record_event(
                    cid, "ledger",
                    "{} -{:,} cr (bought {}t {}{}) -- balance Cr{:,}".format(
                        payer["name"], cost, body.tons, g.name, brokered, bal))
                who = payer["name"]
            else:
                state.repo.record_transaction(
                    cid, -cost, "trade",
                    "Bought {}t {} @ Cr{:,}/t{}".format(
                        body.tons, g.name, body.price_per_ton, brokered),
                    "cargo_lot", lid)
                bal = state.repo.balance(cid)
                who = "party"
            state.repo.write_receipt(
                cid, "trade_buy", body.dict(),
                {"cargo_lot_id": lid, "cost": cost, "balance": bal,
                 "payer": who, "broker": broker, "broker_skill": broker_skill},
                source="player",
                summary="bought {}t {} @ Cr{:,}/t -- {} paid{}".format(
                    body.tons, g.name, body.price_per_ton, who,
                    ", {} brokered".format(broker) if broker
                    and broker != who else ""))
        await state.manager.broadcast(cid, {"type": "trade", "action": "buy", "balance": bal})
        return {"cargo_lot_id": lid, "cost": cost, "balance": bal, "payer": who,
                "broker": broker, "broker_skill": broker_skill}

    @app.post("/api/campaigns/{cid}/trade/sell")
    async def trade_sell(cid: int, body: TradeSell):
        if body.price_per_ton < 0:
            raise HTTPException(400, "price must be non-negative")
        with state.lock:
            row = state.repo.conn.execute(
                "SELECT campaign_id, status FROM cargo_lot WHERE id=?",
                (body.cargo_lot_id,)).fetchone()
            if not row or row["campaign_id"] != cid or row["status"] != "held":
                raise HTTPException(404, "no such held cargo lot in this campaign")
            broker, broker_skill = _broker_label(cid, body.broker_id,
                                                 body.character_id)
            payee, _payee_label = _pocket(cid, body.payee_id, body.character_id)
            # The offer is the port's, not the seller's -- same rule as buying.
            held_row = state.repo.conn.execute(
                "SELECT good FROM cargo_lot WHERE id=?",
                (body.cargo_lot_id,)).fetchone()
            from engine import trade as _t
            _g = next((x for x in _t.TRADE_GOODS.values()
                       if x.name == held_row["good"]), None)
            if _g is not None:
                cdm = _trade_char_dm(state.repo.get_character(
                    body.broker_id or body.character_id)) \
                    if (body.broker_id or body.character_id) else 0
                offer = _authoritative_price(cid, _g.d66, "sell",
                                             _price_hex(cid),
                                             broker_skill or 0, cdm)
                if offer is None:
                    raise HTTPException(
                        400, "no charted world here to sell to -- find a port")
                if body.price_per_ton != offer["price_per_ton"]:
                    raise HTTPException(
                        409, "the offer moved: this port pays Cr{:,}/ton for "
                             "{} today, not Cr{:,}. Refresh and try again."
                             .format(offer["price_per_ton"], _g.name,
                                     body.price_per_ton))
            lot = state.repo.mark_cargo_sold(body.cargo_lot_id)
            if not lot:
                raise HTTPException(404, "no such cargo lot")
            revenue = body.price_per_ton * lot["tons"]
            brokered = (" -- {} brokering at Broker-{}".format(
                broker, broker_skill) if broker else "")
            if payee is not None:
                bal = state.repo.adjust_character_credits(payee["id"], revenue)
                state.repo.record_event(
                    cid, "ledger",
                    "{} +{:,} cr (sold {}t {}{}) -- balance Cr{:,}".format(
                        payee["name"], revenue, lot["tons"], lot["good"],
                        brokered, bal))
                state.repo.record_event(
                    cid, "trade",
                    "Sold {}t {} @ Cr{:,}/t{}".format(
                        lot["tons"], lot["good"], body.price_per_ton, brokered))
                who = payee["name"]
            else:
                state.repo.record_transaction(
                    cid, revenue, "trade",
                    "Sold {}t {} @ Cr{:,}/t{}".format(
                        lot["tons"], lot["good"], body.price_per_ton, brokered),
                    "cargo_lot", body.cargo_lot_id)
                bal = state.repo.balance(cid)
                who = "party"
            state.repo.write_receipt(
                cid, "trade_sell", body.dict(),
                {"revenue": revenue, "balance": bal, "payee": who,
                 "broker": broker, "broker_skill": broker_skill},
                source="player",
                summary="sold {}t {} @ Cr{:,}/t -- {} paid{}".format(
                    lot["tons"], lot["good"], body.price_per_ton, who,
                    ", {} brokered".format(broker) if broker
                    and broker != who else ""))
        await state.manager.broadcast(cid, {"type": "trade", "action": "sell", "balance": bal})
        return {"revenue": revenue, "balance": bal, "payee": who,
                "broker": broker, "broker_skill": broker_skill}

    @app.post("/api/campaigns/{cid}/transfer")
    async def transfer(cid: int, body: TransferReq):
        """One player stakes another, or the pot pays out. Straight through
        dispatch so the tape sees it -- a payment the ledger can't show is
        the same as a payment that didn't happen."""
        from referee.tools import RefereeContext, dispatch
        with state.campaign_lock(cid):
            res = dispatch("transfer_funds",
                           {"source": body.source, "target": body.target,
                            "amount": body.amount, "reason": body.reason or ""},
                           RefereeContext(repo=state.repo, campaign_id=cid),
                           source="player")
        await state.manager.broadcast(cid, {"type": "trade", "action": "transfer",
                                            "balance": state.repo.balance(cid)})
        return res

    @app.get("/api/campaigns/{cid}/cargo")
    def cargo(cid: int):
        return _rows(state.repo.list_cargo(cid))

    @app.get("/api/campaigns/{cid}/balance")
    def balance(cid: int):
        return {"balance": state.repo.balance(cid)}

    # --- combat ---
    @app.get("/api/personal_weapons")
    def personal_weapons():
        from engine import equipment as eq
        return [{"name": n, "melee": eq.weapon(n).is_melee} for n in eq.weapon_names()]

    @app.get("/api/armor_types")
    def armor_types():
        from engine import equipment as eq
        return eq.armor_names()

    @app.get("/api/ship_weapons")
    def ship_weapons():
        from engine import spacecombat as sc
        out = []
        for n, w in sc.WEAPONS.items():
            dv = w.damage_value()
            out.append({"name": n, "damage": (str(dv) + "D6") if dv else "special",
                        "mount": w.mount})
        return out

    @app.post("/api/campaigns/{cid}/combat/personal")
    async def combat_personal(cid: int, body: PersonalCombat):
        import json
        from engine import combat, equipment as eq
        from engine.characteristics import Characteristics, Characteristic
        ra = state.repo.get_character(body.a_id)
        rb = state.repo.get_character(body.b_id)
        if not ra or not rb:
            raise HTTPException(404, "combatant not found")
        rng = next((r for r in combat.Range if r.value == body.range), combat.Range.SHORT)

        def mk(row, weapon, armor):
            return combat.Combatant(
                name=row["name"], chars=Characteristics.from_upp(row["upp"]),
                skills=json.loads(row["skills_json"] or "{}"),
                weapon=eq.weapon(weapon),
                armor=eq.armor(armor) if armor else None)
        a = mk(ra, body.a_weapon, body.a_armor)
        b = mk(rb, body.b_weapon, body.b_armor)
        combat.initiative(a); combat.initiative(b)
        order = sorted([a, b], key=lambda c: (-c.initiative,
                                              -c.chars.dm(Characteristic.DEX)))
        log = []
        for rnd in range(1, body.rounds + 1):
            log.append("-- Round {} --".format(rnd))
            for atk in order:
                dfn = b if atk is a else a
                if not atk.conscious or not dfn.conscious:
                    continue
                r = combat.attack(atk, dfn, rng)
                log.append("{} -> {}: {}".format(atk.name, dfn.name, r))
            if not a.conscious or not b.conscious:
                break
        winner = (a.name if a.conscious and not b.conscious
                  else b.name if b.conscious and not a.conscious else "draw/timeout")
        summary = "Personal combat: {} vs {} -- winner {}".format(a.name, b.name, winner)
        state.repo.record_event(cid, "combat", summary, {"log": log})
        await state.manager.broadcast(cid, {"type": "combat", "summary": summary})
        return {"winner": winner, "log": log,
                "a": {"name": a.name, "conscious": a.conscious, "alive": a.alive},
                "b": {"name": b.name, "conscious": b.conscious, "alive": b.alive}}

    @app.post("/api/campaigns/{cid}/combat/ship")
    async def combat_ship(cid: int, body: ShipCombat):
        from engine import spacecombat as sc
        ra = state.repo.get_ship(body.a_ship_id)
        rb = state.repo.get_ship(body.b_ship_id)
        if not ra or not rb:
            raise HTTPException(404, "ship not found")
        rng = next((r for r in sc.Range if r.value == body.range), sc.Range.MEDIUM)

        def mk(row, weapons, gunner):
            return sc.ShipCombatant(
                name=row["name"], tonnage=row["tonnage"] or 100,
                armor=row["armor"] or 0, thrust=row["thrust"] or 1,
                weapons=[sc.WEAPONS[w] for w in weapons if w in sc.WEAPONS],
                gunner_skill=gunner, hull=row["hull"], structure=row["structure"])
        a = mk(ra, body.a_weapons, body.a_gunner)
        b = mk(rb, body.b_weapons, body.b_gunner)
        sc.initiative(a, b.thrust); sc.initiative(b, a.thrust)
        order = sorted([a, b], key=lambda c: (-c.initiative, -c.thrust))
        log = []
        for t in range(1, body.max_turns + 1):
            log.append("-- Turn {} --".format(t))
            for atk in order:
                dfn = b if atk is a else a
                if atk.destroyed:
                    continue
                for w in atk.weapons:
                    if dfn.destroyed:
                        break
                    if w.mount == "turret" and w.name == "Sandcaster":
                        continue
                    r = sc.attack(atk, dfn, w, rng)
                    log.append("{} fires {}: {}".format(atk.name, w.name, r))
                if dfn.destroyed:
                    log.append("{} DESTROYED".format(dfn.name))
                    break
            if a.destroyed or b.destroyed:
                break
        winner = (a.name if not a.destroyed and b.destroyed
                  else b.name if not b.destroyed and a.destroyed else "stalemate")
        summary = "Ship combat: {} vs {} -- winner {}".format(a.name, b.name, winner)
        state.repo.record_event(cid, "combat", summary, {"log": log})
        await state.manager.broadcast(cid, {"type": "combat", "summary": summary})
        return {"winner": winner, "log": log,
                "a": {"name": a.name, "hull": a.hull, "structure": a.structure, "destroyed": a.destroyed},
                "b": {"name": b.name, "hull": b.hull, "structure": b.structure, "destroyed": b.destroyed}}

    @app.get("/api/campaigns/{cid}/events")
    def events(cid: int, limit: int = 50):
        return _rows(state.repo.events(cid, limit=limit))

    def _ship_positions(cid: int) -> Dict[str, str]:
        """{hex: ship name} from the ships' own records -- the engine's truth
        about where the party is, not whatever is typed in a box. Resolves a
        world NAME too, so 'docked at Luna' still puts a ship on the map."""
        out: Dict[str, str] = {}
        for s in state.repo.list_ships(cid):
            h = state.repo.hex_from_location(cid, s["location_hex"])
            if not h:
                continue
            out[h] = (out[h] + " + " + s["name"]) if h in out else s["name"]
        return out

    @app.get("/api/campaigns/{cid}/position")
    def party_position(cid: int):
        """Where the party is right now, for the interface to follow."""
        ships = _ship_positions(cid)
        if not ships:      # no ship placed yet? follow the crew instead
            for ch in state.repo.list_characters(cid, include_npcs=False):
                h = state.repo.hex_from_location(cid, ch["location_hex"])
                if h:
                    ships = {h: ch["name"]}
                    break
        first = next(iter(ships.items()), (None, None))
        world = (state.repo.find_world_by_hex(cid, first[0])
                 if first[0] else None)
        return {"hex": first[0], "ship": first[1],
                "world": world["name"] if world else None,
                "ships": [{"hex": h, "name": n} for h, n in ships.items()]}

    # --- the Field Desk: the fight belongs to the player ------------------

    def _desk(cid):
        from referee.tools import RefereeContext
        return RefereeContext(repo=state.repo, campaign_id=cid)

    @app.get("/api/campaigns/{cid}/battle")
    def battle_status(cid: int):
        from referee.tools import dispatch
        return dispatch("combat_status", {}, _desk(cid))

    @app.post("/api/campaigns/{cid}/battle/start")
    async def battle_start(cid: int, body: BattleStart):
        from referee.tools import dispatch
        with state.campaign_lock(cid):
            res = dispatch("start_combat",
                           {"combatants": body.combatants,
                            "range_band": body.range_band, "note": body.note},
                           _desk(cid), source="player")
        await state.manager.broadcast(cid, {"type": "combat",
                                            "summary": "combat begins"})
        return res

    @app.post("/api/campaigns/{cid}/battle/attack")
    async def battle_attack(cid: int, body: BattleAttack):
        """The player's own dice are honoured here and NOWHERE else."""
        from referee.tools import dispatch
        with state.campaign_lock(cid):
            res = dispatch("combat_attack",
                           {"attacker": body.attacker, "target": body.target,
                            "roll": body.roll, "other_dm": body.other_dm},
                           _desk(cid), source="player")
        await state.manager.broadcast(cid, {"type": "combat",
                                            "summary": res.get("line", "")})
        return res

    @app.post("/api/campaigns/{cid}/battle/next")
    async def battle_next(cid: int):
        from referee.tools import dispatch
        with state.campaign_lock(cid):
            return dispatch("combat_next", {}, _desk(cid), source="player")

    @app.post("/api/campaigns/{cid}/battle/end")
    async def battle_end(cid: int, body: StrikeReq):
        from referee.tools import dispatch
        with state.campaign_lock(cid):
            res = dispatch("end_combat", {"note": body.reason or ""},
                           _desk(cid), source="player")
        await state.manager.broadcast(cid, {"type": "combat", "summary": "combat ends"})
        return res

    @app.post("/api/campaigns/{cid}/battle/intent")
    async def battle_intent(cid: int, body: StrikeReq):
        """Ask the AI the ONE question it is good for in a fight: what does
        the enemy do? It never decides whether a blow lands."""
        loop = asyncio.get_event_loop()
        from referee.tools import dispatch
        board = dispatch("combat_status", {}, _desk(cid))
        if not board.get("battle_id"):
            raise HTTPException(400, "no fight in progress")
        ask = ("[FIELD DESK] The engine is running this fight and has already "
               "rolled initiative. Board: {}. It is {}'s turn. In two "
               "sentences, say what this combatant DOES -- their intent and "
               "manner only. Do NOT roll, do not decide whether anything "
               "hits, do not state damage: the Desk resolves all of that. "
               "{}".format(json.dumps(board["combatants"]), board.get("active"),
                           body.reason or ""))

        def run():
            with state.campaign_lock(cid):
                return state.referee(cid, "ai").take_turn(ask, actor=None)
        try:
            res = await loop.run_in_executor(None, run)
            return {"intent": res.narration}
        except Exception as e:
            return {"intent": "", "error": str(e)}

    @app.get("/api/campaigns/{cid}/market")
    def market_board(cid: int, trader: Optional[str] = None,
                     broker_hired: int = 0):
        """The port board. A read -- it stamps no receipt, and the day's
        prices are held so a reload is not a re-roll."""
        from referee.tools import RefereeContext, dispatch
        out = dispatch("market_board",
                       {"trader": trader, "broker_hired": broker_hired},
                       RefereeContext(repo=state.repo, campaign_id=cid),
                       source="player")
        if isinstance(out, dict) and trader and not out.get("error"):
            out["trader_id"] = trader
        return out

    @app.get("/market")
    def market_page():
        return FileResponse(os.path.join(STATIC, "market.html"))

    @app.get("/battle")
    def battle_page():
        return FileResponse(os.path.join(STATIC, "battle.html"))

    @app.get("/api/campaigns/{cid}/lore")
    def list_lore(cid: int, status: Optional[str] = None):
        return [dict(r) for r in state.repo.list_lore(cid, status)]

    @app.post("/api/campaigns/{cid}/lore")
    async def add_lore(cid: int, body: LoreReq):
        """A player writing lore IS the authority: it is canon on arrival."""
        with state.campaign_lock(cid):
            res = state.repo.add_lore(cid, body.title, body.body,
                                      body.category or "fact",
                                      proposed_by="player")
        return res

    @app.post("/api/campaigns/{cid}/lore/{lid}/decide")
    async def decide_lore(cid: int, lid: int, body: LoreDecision):
        with state.campaign_lock(cid):
            res = state.repo.decide_lore(cid, lid, body.approve,
                                         body.reason or "")
        if res is None:
            raise HTTPException(404, "no such lore entry")
        await state.manager.broadcast(cid, {"type": "lore",
                                            "summary": "{} {}".format(
                                                res["status"], res["title"])})
        return res

    @app.post("/api/campaigns/{cid}/events/{eid}/strike")
    async def strike_event(cid: int, eid: int, body: StrikeReq):
        """The table's veto over the RECORD (the ✗ button vetoes prose; this
        vetoes a thing that supposedly happened)."""
        with state.campaign_lock(cid):
            res = state.repo.strike_event(cid, eid, body.reason or "")
        if res is None:
            raise HTTPException(404, "no such event in this campaign")
        await state.manager.broadcast(cid, {"type": "correction",
                                            "summary": "struck event #{}".format(eid)})
        return res

    @app.post("/api/campaigns/{cid}/receipts/{seq}/strike")
    async def strike_receipt(cid: int, seq: int, body: StrikeReq):
        with state.campaign_lock(cid):
            res = state.repo.strike_receipt(cid, seq, body.reason or "")
        if res is None:
            raise HTTPException(404, "no such receipt on this tape")
        return res

    @app.post("/api/campaigns/{cid}/ledger/{lid}/reverse")
    async def reverse_txn(cid: int, lid: int, body: StrikeReq):
        with state.campaign_lock(cid):
            res = state.repo.reverse_transaction(cid, lid, body.reason or "")
        if res is None:
            raise HTTPException(404, "no such ledger entry")
        await state.manager.broadcast(cid, {"type": "trade", "action": "reversal",
                                            "balance": res["balance"]})
        return res

    @app.post("/api/campaigns/{cid}/date")
    async def set_date(cid: int, body: DateReq):
        """Forward or BACK. Time taken without leave can be given back."""
        if not state.repo.get_campaign(cid):
            raise HTTPException(404, "no such campaign")
        with state.campaign_lock(cid):
            return state.repo.set_current_date_recorded(cid, body.date,
                                                        body.reason or "")

    @app.get("/api/campaigns/{cid}/receipts")
    def receipts(cid: int, limit: int = 50, since_seq: int = 0):
        """The receipt tape: every mechanical act, numbered, with gaps flagged.
        Players can read it -- that is the point of it existing."""
        rows = state.repo.receipts(cid, limit=limit, since_seq=since_seq)
        gaps = state.repo.receipt_gaps(cid)
        return {"receipts": [dict(r) for r in rows], "gaps": gaps,
                "intact": not gaps}

    @app.get("/api/campaigns/{cid}/transcript")
    def transcript(cid: int):
        """The whole session as one plain-text file: the STORY (every event, in
        the order it happened) followed by the RECORD (the receipt tape). A
        player can download it to argue a point with the GM, keep an archive,
        or paste it back to the referee to remind it what actually happened."""
        camp = state.repo.get_campaign(cid)
        if not camp:
            raise HTTPException(404, "no such campaign")
        L = ["EMPOROS — SESSION TRANSCRIPT",
             "Campaign: {}".format(camp["name"])]
        if camp["current_date"]:
            L.append("In-game date: {}".format(camp["current_date"]))
        L += ["", "=" * 60, "THE STORY", "=" * 60, ""]
        # events() is newest-first; reverse for the order it was actually lived.
        evs = list(state.repo.events(cid, limit=100000, include_struck=True))
        for e in reversed(evs):
            date = "[{}] ".format(e["in_game_date"]) if e["in_game_date"] else ""
            kind = "({}) ".format(e["kind"]) if e["kind"] else ""
            struck = ("   — STRUCK: {}".format(e["struck_reason"] or "vetoed")
                      if e["struck"] else "")
            L.append("{}{}{}{}".format(date, kind, e["summary"] or "", struck))
        L += ["", "=" * 60, "THE RECORD  (receipt tape — every mechanical act)",
              "=" * 60, ""]
        recs = list(state.repo.receipts(cid, limit=100000))
        for r in reversed(recs):
            nums = "  [{}]".format(r["numbers"]) if r["numbers"] else ""
            struck = ("   — STRUCK: {}".format(r["struck_reason"] or "voided")
                      if r["struck"] else "")
            L.append("#{} {} — {}{}{}".format(
                r["seq"], r["tool"], r["summary"] or "", nums, struck))
        if not recs:
            L.append("(nothing on the tape yet)")
        return Response("\n".join(L) + "\n",
                        media_type="text/plain; charset=utf-8")

    @app.get("/api/campaigns/{cid}/jump/options")
    def jump_options(cid: int, ship_id: Optional[int] = None):
        """Where can we go? Computed by the engine from the real map."""
        from engine import travel
        ships = state.repo.list_ships(cid)
        ship = (state.repo.get_ship(ship_id) if ship_id
                else (ships[0] if ships else None))
        if not ship:
            return {"error": "no ship in this campaign", "destinations": []}
        origin = state.repo.hex_from_location(cid, ship["location_hex"])
        out = travel.plan(state.repo, cid, ship, origin)
        world = state.repo.find_world_by_hex(cid, origin) if origin else None
        out.update({"ship": ship["name"], "ship_id": ship["id"],
                    "origin_world": world["name"] if world else None,
                    "refined": bool(ship["fuel_refined"]),
                    "refuel": travel.refuel_options(world, ship) if world else [],
                    "ships": [{"id": s["id"], "name": s["name"]} for s in ships]})
        return out

    @app.post("/api/campaigns/{cid}/jump")
    async def do_jump(cid: int, body: JumpReq):
        """The player jumps. No model in this path -- the engine decides."""
        from referee.tools import RefereeContext, dispatch
        ship = state.repo.get_ship(body.ship_id)
        if not ship or ship["campaign_id"] != cid:
            raise HTTPException(404, "no such ship in this campaign")
        dest = (state.repo.find_world_by_hex(cid, body.destination)
                or state.repo.find_world(cid, body.destination))
        if not dest:
            raise HTTPException(404, "no such world: {}".format(body.destination))
        # ONE DOOR: the player's jump goes through the very same tool the
        # referee calls, so it lands on the receipt tape exactly the same way.
        with state.campaign_lock(cid):
            res = dispatch("jump_ship",
                           {"ship_id": body.ship_id,
                            "destination": dest["hex"],
                            "crew_ids": body.crew_ids},
                           RefereeContext(repo=state.repo, campaign_id=cid),
                           source="player")
        await state.manager.broadcast(cid, {"type": "travel",
                                            "summary": res.get("summary")
                                            or res.get("reason", "")})
        return res

    @app.post("/api/campaigns/{cid}/refuel")
    async def do_refuel(cid: int, body: RefuelReq):
        from referee.tools import RefereeContext, dispatch
        ship = state.repo.get_ship(body.ship_id)
        if not ship or ship["campaign_id"] != cid:
            raise HTTPException(404, "no such ship in this campaign")
        with state.campaign_lock(cid):
            res = dispatch("refuel_ship",
                           {"ship_id": body.ship_id, "tons": body.tons,
                            "kind": body.kind, "payer": body.payer or "party"},
                           RefereeContext(repo=state.repo, campaign_id=cid),
                           source="player")
        await state.manager.broadcast(cid, {"type": "trade", "action": "fuel",
                                            "balance": state.repo.balance(cid)})
        return res

    @app.get("/api/campaigns/{cid}/map")
    def world_map(cid: int, ss: str = "C", sector: str = "",
                  jump: int = 0, highlight: str = "", full: bool = False,
                  ships: bool = True, reach: bool = True):
        rows = state.repo.list_worlds(cid)
        shipmarks = _ship_positions(cid) if ships else {}
        reachable = set()
        if reach and shipmarks:
            from engine import hexes as _hx
            fleet = state.repo.list_ships(cid)
            for h, _n in shipmarks.items():
                sh = next((x for x in fleet if state.repo.hex_from_location(
                    cid, x["location_hex"]) == h), None)
                if sh and int(sh["jump"] or 0) > 0:
                    reachable |= set(_hx.within(h, int(sh["jump"])))
            reachable &= {r["hex"] for r in rows}
        if not sector:      # title the map with the campaign's OWN sector
            sector = rows[0]["sector"] if rows else "Uncharted Space"
        # NOTE for the crowded future: full-sector SVGs re-render per request;
        # when concurrent players make this hot, add a short-TTL cache keyed
        # on (cid, ss, jump, highlight, full).
        if full:
            svg = svgmap.render_sector(rows, sector, highlight_hex=highlight or None,
                                       jump=jump, ships=shipmarks,
                                       reach=reachable)
        else:
            svg = svgmap.render_subsector(rows, ss, sector,
                                          highlight_hex=highlight or None,
                                          jump=jump, ships=shipmarks,
                                          reach=reachable)
        return Response(svg, media_type="image/svg+xml")

    @app.post("/api/campaigns/{cid}/tool")
    async def call_tool(cid: int, body: ToolReq):
        with state.lock:
            result = state.referee(cid, "human").call_tool(body.name, body.arguments)
        await state.manager.broadcast(cid, {"type": "tool", "name": body.name,
                                            "result": result})
        return {"result": result}

    @app.post("/api/campaigns/{cid}/reject")
    async def reject_turn(cid: int, body: RejectReq):
        """The table veto: re-narrate the last turn (dice and state stand);
        the rejected prose is replaced in the record."""
        loop = asyncio.get_event_loop()

        def run():
            with state.campaign_lock(cid):
                return state.referee(cid, "ai").reject(body.note)
        try:
            text = await loop.run_in_executor(None, run)
        except Exception as e:
            return {"narration": "[Referee error] {}".format(e), "error": str(e)}
        await state.manager.broadcast(cid, {"type": "turn", "actor": None,
                                            "narration": "✗ re-narrated: " + text,
                                            "tools": []})
        return {"narration": text}

    @app.post("/api/campaigns/{cid}/turn")
    async def turn(cid: int, body: TurnReq):
        loop = asyncio.get_event_loop()
        try:
            if body.mode == "assist":
                resp = await loop.run_in_executor(
                    None, lambda: state.referee(cid, "assist").suggest(body.input))
                return {"mode": "assist", "proposal": resp.text,
                        "proposed_tools": [tc.name for tc in resp.tool_calls]}

            def run():
                # Per-campaign lock: this table's turns are serialized, but
                # no other table (and no read anywhere) waits on this model.
                with state.campaign_lock(cid):
                    return state.referee(cid, "ai").take_turn(body.input,
                                                              actor=body.actor)
            res = await loop.run_in_executor(None, run)
        except Exception as e:
            msg = "[Referee error] {}".format(e)
            await state.manager.broadcast(cid, {"type": "turn", "actor": body.actor,
                                                "narration": msg, "tools": []})
            return {"narration": msg, "tool_trace": [], "event_ids": [],
                    "error": str(e)}
        payload = {"type": "turn", "actor": body.actor, "narration": res.narration,
                   "tools": [t["tool"] for t in res.tool_trace]}
        await state.manager.broadcast(cid, payload)
        return {"narration": res.narration, "tool_trace": res.tool_trace,
                "event_ids": res.event_ids}

    @app.websocket("/ws/{cid}")
    async def ws(websocket: WebSocket, cid: int):
        uid = _uid_from_token(websocket.cookies.get(SESSION_COOKIE))
        if uid is None or not state.repo.get_user(uid):
            await websocket.close(code=1008)
            return
        stored = state.repo.campaign_password_hash(cid)
        if stored and websocket.cookies.get(_camp_cookie(cid)) != stored:
            await websocket.close(code=1008)
            return
        await state.manager.connect(cid, websocket)
        try:
            await websocket.send_json({"type": "connected", "campaign": cid})
            while True:
                await websocket.receive_text()      # keepalive / ignore inbound
        except WebSocketDisconnect:
            state.manager.disconnect(cid, websocket)

    return app


def app_factory() -> FastAPI:
    """Entry point for `uvicorn web.app:app_factory --factory`."""
    return create_app(os.environ.get("CEPHEUS_DB", "cepheus.db"))
