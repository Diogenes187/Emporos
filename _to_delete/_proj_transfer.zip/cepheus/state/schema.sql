-- Cepheus campaign state schema (SQLite).
-- The database is the source of truth: every meaningful change is written here,
-- and mutations also append to the `event` log.

PRAGMA foreign_keys = ON;

-- Player accounts. Passwords are salted PBKDF2 hashes; plaintext is never stored.
CREATE TABLE IF NOT EXISTS user (
    id            INTEGER PRIMARY KEY,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    pw_salt       TEXT NOT NULL,
    pw_hash       TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS campaign (
    id            INTEGER PRIMARY KEY,
    name          TEXT NOT NULL,
    universe      TEXT NOT NULL DEFAULT 'Official Charted Space',
    current_date  TEXT,                      -- in-game date, e.g. '1105-001'
    notes         TEXT DEFAULT '',
    scenario_notes TEXT DEFAULT '',           -- loaded module: REFEREE EYES ONLY
    scenario_hook  TEXT DEFAULT '',           -- loaded module: the player-safe hook
    password_hash TEXT,                       -- per-campaign lock; NULL = open campaign
    owner_user_id INTEGER REFERENCES user(id), -- NULL = legacy (pre-accounts) campaign
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Worlds, in the T5 schema (official or generated), plus a campaign overlay.
CREATE TABLE IF NOT EXISTS world (
    id            INTEGER PRIMARY KEY,
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    sector        TEXT NOT NULL,
    ss            TEXT,                       -- subsector A-P
    hex           TEXT NOT NULL,              -- 'CCRR'
    name          TEXT,
    uwp           TEXT,
    bases         TEXT,
    remarks       TEXT,                       -- trade codes + notes
    zone          TEXT,                       -- '', 'A', 'R'
    pbg           TEXT,
    allegiance    TEXT,
    stars         TEXT,
    ix            TEXT, ex TEXT, cx TEXT,      -- {Ix} (Ex) [Cx]
    nobility      TEXT, w TEXT, ru TEXT,
    source        TEXT NOT NULL DEFAULT 'official',  -- official | generated
    visited       INTEGER NOT NULL DEFAULT 0,
    control       TEXT DEFAULT '',            -- controlling faction (campaign)
    notes         TEXT DEFAULT '',
    UNIQUE(campaign_id, sector, hex)
);
CREATE INDEX IF NOT EXISTS idx_world_campaign ON world(campaign_id);
CREATE INDEX IF NOT EXISTS idx_world_loc ON world(campaign_id, sector, hex);

CREATE TABLE IF NOT EXISTS character (
    id            INTEGER PRIMARY KEY,
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    upp           TEXT,
    skills_json   TEXT DEFAULT '{}',
    careers_json  TEXT DEFAULT '[]',
    gear_json     TEXT DEFAULT '[]',
    credits       INTEGER NOT NULL DEFAULT 0,
    age           INTEGER,
    location_hex  TEXT,                       -- 'Spin 1910' style or hex
    status        TEXT DEFAULT 'ok',          -- ok | injured | unconscious ...
    damage        INTEGER NOT NULL DEFAULT 0, -- cumulative wounds taken
    alive         INTEGER NOT NULL DEFAULT 1,
    is_npc        INTEGER NOT NULL DEFAULT 0,
    owner_user_id INTEGER REFERENCES user(id), -- NULL = unclaimed / legacy / NPC
    notes         TEXT DEFAULT '',
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_char_campaign ON character(campaign_id);

CREATE TABLE IF NOT EXISTS ship (
    id               INTEGER PRIMARY KEY,
    campaign_id      INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    name             TEXT NOT NULL,
    ship_class       TEXT,                    -- e.g. 'Merchant Trader'
    tonnage          INTEGER,
    jump             INTEGER,
    thrust           INTEGER,
    armor            INTEGER DEFAULT 0,
    hull             INTEGER,
    structure        INTEGER,
    fuel             INTEGER DEFAULT 0,   -- tons aboard
    fuel_capacity    INTEGER DEFAULT 0,   -- tankage (SRD: per the class design)
    fuel_refined     INTEGER DEFAULT 1,   -- 0 = unrefined: -2 on the jump roll
    cargo_json       TEXT DEFAULT '[]',
    mortgage_balance INTEGER DEFAULT 0,
    location_hex     TEXT,
    crew_json        TEXT DEFAULT '{}',
    status           TEXT DEFAULT 'operational',
    notes            TEXT DEFAULT '',
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ship_campaign ON ship(campaign_id);

-- Speculative-trade cargo lots in transit / held.
CREATE TABLE IF NOT EXISTS cargo_lot (
    id                INTEGER PRIMARY KEY,
    campaign_id       INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    ship_id           INTEGER REFERENCES ship(id) ON DELETE SET NULL,
    good              TEXT NOT NULL,
    tons              INTEGER NOT NULL,
    buy_price_per_ton INTEGER,
    origin_hex        TEXT,
    status            TEXT DEFAULT 'held',     -- held | sold | jettisoned
    notes             TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_cargo_campaign ON cargo_lot(campaign_id);

-- Every credit movement.
CREATE TABLE IF NOT EXISTS ledger (
    id            INTEGER PRIMARY KEY,
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    ts            TEXT NOT NULL DEFAULT (datetime('now')),
    amount        INTEGER NOT NULL,            -- + income, - expense
    kind          TEXT,                        -- trade | salary | fuel | fee ...
    description   TEXT DEFAULT '',
    ref_table     TEXT, ref_id INTEGER
);
CREATE INDEX IF NOT EXISTS idx_ledger_campaign ON ledger(campaign_id);

-- Append-only narrative/event spine: the "write it down" backbone.
CREATE TABLE IF NOT EXISTS event (
    id            INTEGER PRIMARY KEY,
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    ts            TEXT NOT NULL DEFAULT (datetime('now')),
    in_game_date  TEXT,
    kind          TEXT,                        -- jump | combat | trade | note ...
    summary       TEXT NOT NULL,
    detail_json   TEXT DEFAULT '{}',
    struck        INTEGER NOT NULL DEFAULT 0,  -- vetoed: kept, but not true
    struck_reason TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_event_campaign ON event(campaign_id);

-- THE RECEIPT TAPE. Every mechanical act -- a die rolled, a check made, money
-- moved, a wound applied, a record written -- leaves exactly one numbered
-- receipt BEFORE its result returns. Pure reads leave none. Failed calls leave
-- none. The sequence is per-campaign and contiguous, so a GAP is detectable:
-- the narrator cannot assert a mechanical fact the tape can't back.
CREATE TABLE IF NOT EXISTS receipt (
    id            INTEGER PRIMARY KEY,
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    seq           INTEGER NOT NULL,           -- 1,2,3... per campaign
    ts            TEXT NOT NULL DEFAULT (datetime('now')),
    tool          TEXT NOT NULL,
    author        TEXT NOT NULL DEFAULT 'engine',   -- engine | human (who rolled)
    source        TEXT NOT NULL DEFAULT 'referee',  -- referee | player (who asked)
    args_json     TEXT DEFAULT '{}',
    result_json   TEXT DEFAULT '{}',
    numbers       TEXT DEFAULT '',            -- every number this act produced
    summary       TEXT DEFAULT '',
    struck        INTEGER NOT NULL DEFAULT 0,  -- voided by the table's veto
    struck_reason TEXT DEFAULT '',
    UNIQUE (campaign_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_receipt_campaign ON receipt(campaign_id, seq);

-- THE APPROVAL GATE. The referee may invent freely in the moment, but nothing
-- it invents becomes permanent until the table says so. AI-proposed entries
-- land here as 'pending' and only 'canon' rows are fed back as established
-- fact. Player-authored entries are canon on arrival: the player IS the
-- authority. (The 'Rimmerian Republic' was invented out of a two-letter
-- allegiance code on 2026-07-26 and would have hardened into canon unchecked.)
CREATE TABLE IF NOT EXISTS lore (
    id            INTEGER PRIMARY KEY,
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    title         TEXT NOT NULL,
    body          TEXT NOT NULL DEFAULT '',
    category      TEXT DEFAULT 'fact',   -- faction | person | place | custom | rumour | fact
    status        TEXT NOT NULL DEFAULT 'pending',  -- pending | canon | rejected
    proposed_by   TEXT NOT NULL DEFAULT 'referee',  -- referee | player
    decided_reason TEXT DEFAULT '',
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    decided_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_lore_campaign ON lore(campaign_id, status);

-- THE FIELD DESK. A fight is a persistent, resumable thing: the engine keeps
-- the schedule, the player rolls their own dice, and the AI is asked only what
-- the enemy INTENDS. Combatants point at real character rows so wounds land in
-- the same ledger as everything else.
CREATE TABLE IF NOT EXISTS battle (
    id           INTEGER PRIMARY KEY,
    campaign_id  INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    status       TEXT NOT NULL DEFAULT 'active',   -- active | ended
    round        INTEGER NOT NULL DEFAULT 1,
    range_band   TEXT NOT NULL DEFAULT 'Short',
    turn_index   INTEGER NOT NULL DEFAULT 0,
    note         TEXT DEFAULT '',
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_battle_campaign ON battle(campaign_id, status);

CREATE TABLE IF NOT EXISTS battle_combatant (
    id           INTEGER PRIMARY KEY,
    battle_id    INTEGER NOT NULL REFERENCES battle(id) ON DELETE CASCADE,
    character_id INTEGER REFERENCES character(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    side         TEXT NOT NULL DEFAULT 'crew',     -- crew | foe
    weapon       TEXT DEFAULT 'Unarmed Strike',
    armor        TEXT DEFAULT '',
    initiative   INTEGER NOT NULL DEFAULT 0,
    acted        INTEGER NOT NULL DEFAULT 0,
    ord          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_bc_battle ON battle_combatant(battle_id);

-- The port board. Availability and asking prices are rolled once per world
-- per day and HELD -- otherwise a reload is a re-roll and the market is a slot
-- machine. (SRD: a rejected supplier will not deal again for a week.)
-- A port's market for one in-game day, in THREE honest tables instead of one
-- JSON blob. The blob (market_survey.board_json) abused its `hex` column as a
-- string key -- "1910|stock", "1910|3|1" -- to cram the shared quay and every
-- negotiator's prices into one row, and decremented stock by loading the blob,
-- editing it, and writing it back (a lost-update waiting to happen).
--
-- market_day     : did we roll this port today? (empty quay != un-surveyed)
-- market_stock   : the shared quay -- one row per good, tons drained atomically
-- market_quote   : the held price per (negotiator, good, side); dice roll once
CREATE TABLE IF NOT EXISTS market_day (
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    hex           TEXT NOT NULL,
    day           TEXT NOT NULL,
    PRIMARY KEY (campaign_id, hex, day)
);

CREATE TABLE IF NOT EXISTS market_stock (
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    hex           TEXT NOT NULL,
    day           TEXT NOT NULL,
    d66           TEXT NOT NULL,
    ord           INTEGER NOT NULL,          -- the order goods were rolled, for display
    tons          INTEGER NOT NULL,          -- what is LEFT; drained by stock_take
    PRIMARY KEY (campaign_id, hex, day, d66)
);

CREATE TABLE IF NOT EXISTS market_quote (
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    hex           TEXT NOT NULL,
    day           TEXT NOT NULL,
    skill         INTEGER NOT NULL,          -- the negotiator's Broker skill
    cdm           INTEGER NOT NULL,          -- their INT/SOC characteristic DM
    d66           TEXT NOT NULL,
    side          TEXT NOT NULL,             -- 'buy' | 'sell'
    price_per_ton INTEGER NOT NULL,
    percent       INTEGER NOT NULL,
    PRIMARY KEY (campaign_id, hex, day, skill, cdm, d66, side)
);

-- In-progress character creation. Persisted so an interactive lifepath build
-- survives server restarts / redeploys: we store the seed and the ordered list
-- of choices, then deterministically replay them to rebuild the live session.
CREATE TABLE IF NOT EXISTS chargen_session (
    id            TEXT PRIMARY KEY,             -- opaque session id (uuid hex)
    campaign_id   INTEGER NOT NULL REFERENCES campaign(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,                -- character name being built
    seed          INTEGER NOT NULL,             -- RNG seed for deterministic replay
    choices_json  TEXT NOT NULL DEFAULT '[]',   -- ordered list of choice payloads
    location_hex  TEXT,                         -- where the PC will start
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_chargen_campaign ON chargen_session(campaign_id);

-- ---- reference catalogues (seeded from the authored SRD data, read-only) ----
-- These are the same for every campaign and never change in play, so they are
-- seeded ONCE from engine/data/*.json (the git-authored, book-audited source)
-- into real tables here -- so the market is queryable in SQL alongside campaign
-- state, instead of only reachable by parsing a dict in a Python module. The
-- authored JSON stays the source of truth; state.db._seed_catalogues fills
-- these to match it, and a test pins table == source so they cannot drift.
CREATE TABLE IF NOT EXISTS trade_good (
    d66         TEXT PRIMARY KEY,               -- the good's D66 code, e.g. '25'
    name        TEXT NOT NULL,
    base_price  INTEGER,                        -- Cr per ton at 100%; NULL = 'special' (good 66)
    tons_expr   TEXT NOT NULL,                  -- availability dice, e.g. '1D6x5'
    illegal     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS trade_good_dm (
    d66         TEXT NOT NULL REFERENCES trade_good(d66) ON DELETE CASCADE,
    code        TEXT NOT NULL,                  -- world trade code, e.g. 'Ag'
    side        TEXT NOT NULL,                  -- 'purchase' | 'sale'
    dm          INTEGER NOT NULL,
    PRIMARY KEY (d66, code, side)
);
CREATE INDEX IF NOT EXISTS idx_trade_good_dm_code ON trade_good_dm(code, side);

-- A character's skills as real rows, so "who here can broker?" is a query, not
-- a scan of a JSON string. character.skills_json stays as the whole-character
-- skill list (the natural shape for loading one PC into combat); this table is
-- the cross-character INDEX, maintained at every character write and backfilled
-- from skills_json for characters created before it existed.
CREATE TABLE IF NOT EXISTS character_skill (
    character_id  INTEGER NOT NULL REFERENCES character(id) ON DELETE CASCADE,
    skill         TEXT NOT NULL,
    level         INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (character_id, skill)
);
CREATE INDEX IF NOT EXISTS idx_character_skill_name ON character_skill(skill);
