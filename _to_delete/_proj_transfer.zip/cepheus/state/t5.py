"""t5.py -- parse and emit Traveller T5 sector data (tab-delimited).

T5 is the canonical sector interchange format used by TravellerMap. Files are
tab-delimited with a header row naming the columns; lines beginning with '#'
are comments. See https://travellermap.com/doc/fileformats .

We parse header-first so column order/extra columns don't matter, and emit in
the standard column order so our generated sectors and official Charted Space
data share one format.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

# Canonical T5 column order for emitting.
COLUMNS = ["Sector", "SS", "Hex", "Name", "UWP", "Bases", "Remarks", "Zone",
           "PBG", "Allegiance", "Stars", "{Ix}", "(Ex)", "[Cx]", "Nobility",
           "W", "RU"]


@dataclass
class WorldRecord:
    hex: str = ""
    name: str = ""
    uwp: str = ""
    bases: str = ""
    remarks: str = ""          # trade codes + notes (the T5 'Remarks' column)
    zone: str = ""             # '', 'A' (amber), 'R' (red)
    pbg: str = ""
    allegiance: str = ""
    sector: str = ""
    ss: str = ""               # subsector letter A-P
    stars: str = ""
    ix: str = ""               # {Ix} importance
    ex: str = ""               # (Ex) economic
    cx: str = ""               # [Cx] cultural
    nobility: str = ""
    w: str = ""                # worlds in system
    ru: str = ""               # resource units
    extra: Dict[str, str] = field(default_factory=dict)

    @property
    def trade_codes(self) -> List[str]:
        """The 2-letter trade codes from Remarks (drops parenthetical detail)."""
        codes = []
        for tok in self.remarks.split():
            if len(tok) == 2 and tok[0].isupper() and tok.isalpha():
                codes.append(tok)
        return codes

    def to_row(self) -> Dict[str, str]:
        return {
            "Sector": self.sector, "SS": self.ss, "Hex": self.hex,
            "Name": self.name, "UWP": self.uwp, "Bases": self.bases,
            "Remarks": self.remarks, "Zone": self.zone, "PBG": self.pbg,
            "Allegiance": self.allegiance, "Stars": self.stars,
            "{Ix}": self.ix, "(Ex)": self.ex, "[Cx]": self.cx,
            "Nobility": self.nobility, "W": self.w, "RU": self.ru,
        }


# Map T5 header names to WorldRecord attribute names.
_FIELD_MAP = {
    "Sector": "sector", "SS": "ss", "Hex": "hex", "Name": "name", "UWP": "uwp",
    "Bases": "bases", "Remarks": "remarks", "Zone": "zone", "PBG": "pbg",
    "Allegiance": "allegiance", "Stars": "stars", "{Ix}": "ix", "(Ex)": "ex",
    "[Cx]": "cx", "Nobility": "nobility", "W": "w", "RU": "ru",
}


def parse_lines(lines: List[str]) -> List[WorldRecord]:
    """Parse T5 tab-delimited lines into WorldRecords. Skips '#' comment lines."""
    header = None
    records = []
    for raw in lines:
        line = raw.rstrip("\n").rstrip("\r")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        cols = line.split("\t")
        if header is None:
            header = [c.strip() for c in cols]
            continue
        # Some legacy lines use a row of dashes under the header; skip them.
        if all(set(c.strip()) <= {"-"} for c in cols if c.strip()):
            continue
        values = [c.strip() for c in cols]
        rec = WorldRecord()
        for i, colname in enumerate(header):
            if i >= len(values):
                break
            attr = _FIELD_MAP.get(colname)
            if attr:
                setattr(rec, attr, values[i])
            else:
                rec.extra[colname] = values[i]
        if rec.hex and rec.name:
            records.append(rec)
    return records


def parse_file(path: str) -> List[WorldRecord]:
    with open(path, encoding="utf-8") as f:
        return parse_lines(f.readlines())


def emit(records: List[WorldRecord], columns: Optional[List[str]] = None) -> str:
    """Emit records as a T5 tab-delimited string (header + rows)."""
    cols = columns or COLUMNS
    out = ["\t".join(cols)]
    for rec in records:
        row = rec.to_row()
        out.append("\t".join(row.get(c, "") for c in cols))
    return "\n".join(out) + "\n"
