"""repo.py -- the campaign state API.

One interface that the rules engine, the (future) LLM referee and the web UI
all call. The database is the source of truth: every meaningful mutation also
writes an `event` row, so nothing changes without being recorded.

Engine objects (chargen.Character, ships.Ship, worlds.World / t5.WorldRecord)
are serialized to/from rows by the adapter helpers, so the engine we built
plugs straight in without importing this layer.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import threading
from typing import Any, Dict, List, Optional

from . import db
from . import t5

# User-account passwords: salted PBKDF2 (campaign passwords keep their legacy
# scheme below so existing world locks continue to work unchanged).
PBKDF2_ITERS = 300_000


def user_hash_password(password: str, salt: Optional[str] = None):
    """Return (salt_hex, hash_hex) for a user account password."""
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"),
                             bytes.fromhex(salt), PBKDF2_ITERS)
    return salt, dk.hex()


def hash_password(password: str) -> str:
    """One-way hash for a campaign password. Same scheme as the site gate:
    a plain password is never stored, only this digest. An empty/blank
    password hashes to None (an open, unlocked campaign)."""
    password = (password or "").strip()
    if not password:
        return None
    return hashlib.sha256(("cepheus-campaign::" + password).encode()).hexdigest()


# ---------------------------------------------------------------------------
# adapters: engine objects -> row dicts (duck-typed, no hard engine import)
# ---------------------------------------------------------------------------

def character_row(char: Any, is_npc: bool = False,
                  location: Optional[str] = None) -> Dict[str, Any]:
    """Serialize a chargen.Character (or anything with the same attributes)."""
    careers = [{"career": s.career, "terms": s.terms, "rank": s.rank}
               for s in getattr(char, "history", [])]
    return {
        "name": char.name,
        "upp": char.chars.upp,
        "skills_json": json.dumps(char.skills),
        "careers_json": json.dumps(careers),
        "gear_json": json.dumps(list(getattr(char, "benefits", []))),
        "credits": int(getattr(char, "credits", 0)),
        "age": int(getattr(char, "age", 0)),
        "location_hex": location,
        "status": "ok" if getattr(char, "alive", True) else "dead",
        "alive": 1 if getattr(char, "alive", True) else 0,
        "is_npc": 1 if is_npc else 0,
    }


def _fuel_cap(ship_class, tonnage, jump) -> int:
    from engine.travel import fuel_capacity
    return fuel_capacity(ship_class, tonnage, jump)


def ship_row(ship: Any, name: Optional[str] = None, armor: int = 0,
             fuel: int = 0, location: Optional[str] = None,
             mortgage_balance: Optional[int] = None) -> Dict[str, Any]:
    """Serialize a ships.Ship design into a ship row (with live-state overrides).
    A new ship leaves the yard with full tanks of refined fuel."""
    tonnage = getattr(ship, "tonnage", None) or 0
    return {
        "name": name or ship.name,
        "ship_class": ship.name,
        "tonnage": tonnage,
        "jump": getattr(ship, "jump", None),
        "thrust": getattr(ship, "maneuver_g", None),
        "armor": armor,
        "hull": tonnage // 50,
        "structure": max(tonnage // 50, 1),
        "fuel": fuel,
        "fuel_capacity": _fuel_cap(ship.name, tonnage,
                                   getattr(ship, "jump", None) or 1),
        "fuel_refined": 1,
        "mortgage_balance": (ship.monthly_mortgage() * 240
                             if mortgage_balance is None and ship.cost_cr
                             else (mortgage_balance or 0)),
        "location_hex": location,
    }


def world_row(rec: t5.WorldRecord, source: str = "official") -> Dict[str, Any]:
    return {
        "sector": rec.sector, "ss": rec.ss, "hex": rec.hex, "name": rec.name,
        "uwp": rec.uwp, "bases": rec.bases, "remarks": rec.remarks,
        "zone": rec.zone, "pbg": rec.pbg, "allegiance": rec.allegiance,
        "stars": rec.stars, "ix": rec.ix, "ex": rec.ex, "cx": rec.cx,
        "nobility": rec.nobility, "w": rec.w, "ru": rec.ru, "source": source,
    }


def _insert(conn, table: str, row: Dict[str, Any]) -> int:
    cols = ", ".join(row)
    qs = ", ".join("?" for _ in row)
    cur = conn.execute("INSERT INTO {} ({}) VALUES ({})".format(table, cols, qs),
                       tuple(row.values()))
    return cur.lastrowid


# ---------------------------------------------------------------------------
# Repo
# ---------------------------------------------------------------------------

class Repo:
    """Thin data-access layer over a campaign SQLite database.

    Two modes:
      * Repo(conn)      -- one fixed connection (tests, scripts, :memory:).
      * Repo.open(path) -- file-backed: each THREAD gets its own connection
        (WAL journal), so a slow referee turn on one thread never makes the
        map, the panels, or another table's turn wait on the database.
    """

    def __init__(self, conn: Optional[sqlite3.Connection] = None,
                 path: Optional[str] = None):
        self._fixed = conn
        self._path = path
        self._local = threading.local()

    @property
    def conn(self) -> sqlite3.Connection:
        if self._fixed is not None:
            return self._fixed
        c = getattr(self._local, "conn", None)
        if c is None:
            c = db.connect(self._path)
            self._local.conn = c
        return c

    @classmethod
    def open(cls, path: str) -> "Repo":
        if path == ":memory:":
            return cls(conn=db.connect_memory())
        r = cls(path=path)
        r.conn  # eagerly connect once so schema/migrations run at boot
        return r

    @classmethod
    def memory(cls) -> "Repo":
        return cls(conn=db.connect_memory())

    def close(self):
        for c in (self._fixed, getattr(self._local, "conn", None)):
            if c is not None:
                try:
                    c.commit()
                    c.close()
                except Exception:
                    pass
        self._fixed = None
        if hasattr(self._local, "conn"):
            self._local.conn = None

    # ---- events (the source-of-truth backbone) -------------------------

    def record_event(self, campaign_id: int, kind: str, summary: str,
                     detail: Optional[dict] = None,
                     in_game_date: Optional[str] = None) -> int:
        eid = _insert(self.conn, "event", {
            "campaign_id": campaign_id, "kind": kind, "summary": summary,
            "detail_json": json.dumps(detail or {}),
            "in_game_date": in_game_date,
        })
        self.conn.commit()
        return eid

    def events(self, campaign_id: int, limit: int = 100,
               include_struck: bool = False) -> List[sqlite3.Row]:
        q = "SELECT * FROM event WHERE campaign_id=?"
        if not include_struck:
            q += " AND struck=0"        # struck history must not haunt the story
        return self.conn.execute(
            q + " ORDER BY id DESC LIMIT ?", (campaign_id, limit)).fetchall()

    # ---- the port board -------------------------------------------------

    # ---- reference catalogues (read-only, seeded from the SRD data) -----
    def catalog_goods(self):
        """Every trade good, from the trade_good table -- the queryable copy of
        the authored catalogue. Each good carries its per-code purchase/sale
        DMs assembled from trade_good_dm."""
        dms = {}
        for r in self.conn.execute(
                "SELECT d66, code, side, dm FROM trade_good_dm"):
            slot = dms.setdefault(r["d66"], {"purchase": {}, "sale": {}})
            slot[r["side"]][r["code"]] = int(r["dm"])
        out = []
        for r in self.conn.execute(
                "SELECT d66, name, base_price, tons_expr, illegal "
                "FROM trade_good ORDER BY d66"):
            d = dms.get(r["d66"], {"purchase": {}, "sale": {}})
            out.append({
                "d66": r["d66"], "name": r["name"],
                "base_price": (None if r["base_price"] is None
                               else int(r["base_price"])),
                "tons": r["tons_expr"],
                "illegal": bool(r["illegal"]),
                "purchase_dms": d["purchase"], "sale_dms": d["sale"]})
        return out

    def goods_wanted_here(self, codes):
        """The queryability payoff: which goods this port's trade codes make it
        pay dear for (positive net sale DM), answered in SQL rather than by
        parsing a dict. `codes` is the world's trade-code list."""
        codes = list(codes or [])
        if not codes:
            return []
        qs = ",".join("?" * len(codes))
        # MAX, not SUM: the engine takes the single BEST matching DM per side
        # (engine.trade._best_dm), so the query must too or it would disagree
        # with the price the till charges.
        rows = self.conn.execute(
            "SELECT g.d66, g.name, g.base_price, "
            "  COALESCE(MAX(CASE WHEN dm.side='sale'     THEN dm.dm END),0) "
            "  - COALESCE(MAX(CASE WHEN dm.side='purchase' THEN dm.dm END),0) "
            "    AS net_sale_dm "
            "FROM trade_good g LEFT JOIN trade_good_dm dm "
            "  ON dm.d66=g.d66 AND dm.code IN ({}) "
            "WHERE g.illegal=0 AND g.base_price IS NOT NULL "
            "GROUP BY g.d66 HAVING net_sale_dm > 0 "
            "ORDER BY net_sale_dm DESC, g.base_price DESC".format(qs),
            codes).fetchall()
        return [{"d66": r["d66"], "name": r["name"],
                 "base_price": int(r["base_price"]),
                 "sell_dm": int(r["net_sale_dm"])} for r in rows]

    # ---- the day's market: quay + held prices, in real tables ----------
    def market_surveyed(self, campaign_id: int, hex: str, day: str) -> bool:
        """Has this port's quay been rolled today? (An empty quay is still a
        survey -- this is what tells it apart from a port not yet visited.)"""
        return self.conn.execute(
            "SELECT 1 FROM market_day WHERE campaign_id=? AND hex=? AND day=?",
            (campaign_id, hex, day)).fetchone() is not None

    def seed_stock(self, campaign_id: int, hex: str, day: str, pairs) -> None:
        """Record today's survey and lay out the quay. `pairs` is an ordered
        list of (d66, tons)."""
        self.conn.execute(
            "INSERT OR IGNORE INTO market_day(campaign_id, hex, day) "
            "VALUES (?,?,?)", (campaign_id, hex, day))
        for ordinal, (d66, tons) in enumerate(pairs):
            self.conn.execute(
                "INSERT OR IGNORE INTO market_stock"
                "(campaign_id, hex, day, d66, ord, tons) VALUES (?,?,?,?,?,?)",
                (campaign_id, hex, day, str(d66), ordinal, int(tons)))
        self.conn.commit()

    def stock_rows(self, campaign_id: int, hex: str, day: str):
        """The quay, in display order: [(d66, tons)]."""
        return [(r["d66"], int(r["tons"])) for r in self.conn.execute(
            "SELECT d66, tons FROM market_stock WHERE campaign_id=? AND hex=? "
            "AND day=? ORDER BY ord", (campaign_id, hex, day)).fetchall()]

    def stock_remaining(self, campaign_id: int, hex: str, day: str,
                        d66: str) -> int:
        row = self.conn.execute(
            "SELECT tons FROM market_stock WHERE campaign_id=? AND hex=? AND "
            "day=? AND d66=?", (campaign_id, hex, day, str(d66))).fetchone()
        return int(row["tons"]) if row else 0

    def stock_take(self, campaign_id: int, hex: str, day: str, d66: str,
                   want: int):
        """Spend `want` tons off the quay ATOMICALLY. The `tons >= want` guard
        lives inside the UPDATE, so two buyers racing for the last lot cannot
        both pass a read and overdraw -- one wins, the other gets None. Returns
        the tons remaining, or None if there was not enough (or no such good)."""
        cur = self.conn.execute(
            "UPDATE market_stock SET tons = tons - ? WHERE campaign_id=? AND "
            "hex=? AND day=? AND d66=? AND tons >= ?",
            (int(want), campaign_id, hex, day, str(d66), int(want)))
        self.conn.commit()
        if cur.rowcount == 0:
            return None
        return self.stock_remaining(campaign_id, hex, day, d66)

    def quote_get(self, campaign_id: int, hex: str, day: str, skill: int,
                  cdm: int, d66: str, side: str):
        """The held (price_per_ton, percent) for one negotiator, good and side
        -- or None if it has not been rolled yet today."""
        row = self.conn.execute(
            "SELECT price_per_ton, percent FROM market_quote WHERE "
            "campaign_id=? AND hex=? AND day=? AND skill=? AND cdm=? AND "
            "d66=? AND side=?",
            (campaign_id, hex, day, int(skill), int(cdm), str(d66),
             side)).fetchone()
        return (int(row["price_per_ton"]), int(row["percent"])) if row else None

    def quote_set(self, campaign_id: int, hex: str, day: str, skill: int,
                  cdm: int, d66: str, side: str, price: int,
                  percent: int) -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO market_quote(campaign_id, hex, day, skill, "
            "cdm, d66, side, price_per_ton, percent) VALUES (?,?,?,?,?,?,?,?,?)",
            (campaign_id, hex, day, int(skill), int(cdm), str(d66), side,
             int(price), int(percent)))
        self.conn.commit()

    # ---- the Field Desk -------------------------------------------------

    def start_battle(self, campaign_id: int, range_band: str = "Short",
                     note: str = "") -> int:
        self.conn.execute(
            "UPDATE battle SET status='ended', ended_at=datetime('now') "
            "WHERE campaign_id=? AND status='active'", (campaign_id,))
        bid = _insert(self.conn, "battle", {
            "campaign_id": campaign_id, "range_band": range_band, "note": note})
        self.conn.commit()
        return bid

    def active_battle(self, campaign_id: int):
        return self.conn.execute(
            "SELECT * FROM battle WHERE campaign_id=? AND status='active' "
            "ORDER BY id DESC LIMIT 1", (campaign_id,)).fetchone()

    def get_battle(self, battle_id: int):
        return self.conn.execute("SELECT * FROM battle WHERE id=?",
                                 (int(battle_id),)).fetchone()

    def add_combatant(self, battle_id: int, name: str, side: str = "crew",
                      character_id: Optional[int] = None,
                      weapon: str = "Unarmed Strike", armor: str = "",
                      initiative: int = 0) -> int:
        cid = _insert(self.conn, "battle_combatant", {
            "battle_id": int(battle_id), "character_id": character_id,
            "name": name, "side": side, "weapon": weapon or "Unarmed Strike",
            "armor": armor or "", "initiative": int(initiative)})
        self.conn.commit()
        return cid

    def combatants(self, battle_id: int) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM battle_combatant WHERE battle_id=? ORDER BY ord, id",
            (int(battle_id),)).fetchall()

    def set_battle(self, battle_id: int, **fields):
        if not fields:
            return
        sets = ", ".join("{}=?".format(k) for k in fields)
        self.conn.execute("UPDATE battle SET {} WHERE id=?".format(sets),
                          tuple(fields.values()) + (int(battle_id),))
        self.conn.commit()

    def set_combatant(self, combatant_id: int, **fields):
        if not fields:
            return
        sets = ", ".join("{}=?".format(k) for k in fields)
        self.conn.execute(
            "UPDATE battle_combatant SET {} WHERE id=?".format(sets),
            tuple(fields.values()) + (int(combatant_id),))
        self.conn.commit()

    def end_battle(self, battle_id: int):
        self.conn.execute(
            "UPDATE battle SET status='ended', ended_at=datetime('now') "
            "WHERE id=?", (int(battle_id),))
        self.conn.commit()

    # ---- the approval gate ---------------------------------------------
    # The referee proposes; the table disposes. Only 'canon' rows are ever
    # fed back as established fact.

    def add_lore(self, campaign_id: int, title: str, body: str = "",
                 category: str = "fact", proposed_by: str = "referee"
                 ) -> Dict[str, Any]:
        title = (title or "").strip()
        if not title:
            return {"error": "lore needs a title"}
        existing = self.conn.execute(
            "SELECT * FROM lore WHERE campaign_id=? AND lower(title)=lower(?) "
            "AND status!='rejected'", (campaign_id, title)).fetchone()
        if existing:
            return {"already_exists": True, "id": existing["id"],
                    "title": existing["title"], "status": existing["status"],
                    "body": existing["body"]}
        status = "canon" if proposed_by == "player" else "pending"
        lid = _insert(self.conn, "lore", {
            "campaign_id": campaign_id, "title": title, "body": body or "",
            "category": category or "fact", "status": status,
            "proposed_by": proposed_by,
            "decided_at": "now" if status == "canon" else None})
        self.conn.commit()
        self.record_event(
            campaign_id, "lore",
            "{} lore: {}".format(
                "Canon" if status == "canon" else "Proposed", title))
        return {"id": lid, "title": title, "status": status,
                "category": category, "proposed_by": proposed_by}

    def list_lore(self, campaign_id: int, status: Optional[str] = None
                  ) -> List[sqlite3.Row]:
        q = "SELECT * FROM lore WHERE campaign_id=?"
        args: List[Any] = [campaign_id]
        if status:
            q += " AND status=?"
            args.append(status)
        return self.conn.execute(q + " ORDER BY id DESC", tuple(args)).fetchall()

    def decide_lore(self, campaign_id: int, lore_id: int, approve: bool,
                    reason: str = "") -> Optional[Dict[str, Any]]:
        row = self.conn.execute(
            "SELECT * FROM lore WHERE id=? AND campaign_id=?",
            (int(lore_id), campaign_id)).fetchone()
        if not row:
            return None
        status = "canon" if approve else "rejected"
        self.conn.execute(
            "UPDATE lore SET status=?, decided_reason=?, "
            "decided_at=datetime('now') WHERE id=?",
            (status, reason or "", int(lore_id)))
        self.conn.commit()
        self.record_event(campaign_id, "lore",
                          "{} lore: {}{}".format(
                              "Approved" if approve else "Rejected",
                              row["title"],
                              " -- {}".format(reason) if reason else ""))
        return {"id": int(lore_id), "title": row["title"], "status": status,
                "reason": reason}

    # ---- the correction editors ----------------------------------------
    # Born 2026-07-26, after a referee spent Cr92,000 nobody authorised and
    # the only remedy was compensating entries -- accounting fiction. Nothing
    # here DELETES: the record keeps its shape and gains a line saying what
    # was struck and why, so an audit can still see the whole story.

    def strike_event(self, campaign_id: int, event_id: int,
                     reason: str = "") -> Optional[Dict[str, Any]]:
        row = self.conn.execute(
            "SELECT * FROM event WHERE id=? AND campaign_id=?",
            (int(event_id), campaign_id)).fetchone()
        if not row:
            return None
        if row["struck"]:
            return {"already_struck": True, "event_id": int(event_id),
                    "summary": row["summary"]}
        self.conn.execute(
            "UPDATE event SET struck=1, struck_reason=? WHERE id=?",
            (reason or "struck by the table", int(event_id)))
        self.conn.commit()
        self.record_event(campaign_id, "correction",
                          "STRUCK #{}: {}{}".format(
                              event_id, row["summary"][:160],
                              " -- {}".format(reason) if reason else ""))
        return {"event_id": int(event_id), "struck": True,
                "was": row["summary"], "reason": reason}

    def strike_receipt(self, campaign_id: int, seq: int,
                       reason: str = "") -> Optional[Dict[str, Any]]:
        """Void a mechanical act on the tape. The receipt STAYS -- deleting it
        would open a gap, and a gap means tampering. It is marked void."""
        row = self.conn.execute(
            "SELECT * FROM receipt WHERE campaign_id=? AND seq=?",
            (campaign_id, int(seq))).fetchone()
        if not row:
            return None
        self.conn.execute(
            "UPDATE receipt SET struck=1, struck_reason=? "
            "WHERE campaign_id=? AND seq=?",
            (reason or "voided by the table", campaign_id, int(seq)))
        self.conn.commit()
        self.record_event(campaign_id, "correction",
                          "VOIDED receipt #{} ({}){}".format(
                              seq, row["tool"],
                              " -- {}".format(reason) if reason else ""))
        return {"seq": int(seq), "tool": row["tool"], "struck": True,
                "reason": reason}

    def reverse_transaction(self, campaign_id: int, ledger_id: int,
                            reason: str = "") -> Optional[Dict[str, Any]]:
        """Undo money. Posts the exact inverse, linked to the original, so the
        balance is right AND the history shows what happened."""
        row = self.conn.execute(
            "SELECT * FROM ledger WHERE id=? AND campaign_id=?",
            (int(ledger_id), campaign_id)).fetchone()
        if not row:
            return None
        amount = -int(row["amount"])
        tid = _insert(self.conn, "ledger", {
            "campaign_id": campaign_id, "amount": amount, "kind": "reversal",
            "description": "REVERSAL of #{}: {}{}".format(
                ledger_id, row["description"] or row["kind"],
                " -- {}".format(reason) if reason else ""),
            "ref_table": "ledger", "ref_id": int(ledger_id)})
        self.conn.commit()
        self.record_event(campaign_id, "correction",
                          "Reversed ledger #{}: {}{:+,} cr".format(
                              ledger_id, "", amount))
        return {"reversal_id": tid, "reversed": int(ledger_id),
                "amount": amount, "balance": self.balance(campaign_id)}

    def set_current_date_recorded(self, campaign_id: int, date: str,
                                  reason: str = "") -> Dict[str, Any]:
        """The calendar, forward OR BACK, with the correction chronicled."""
        c = self.get_campaign(campaign_id)
        was = (c["current_date"] if c else None) or "unset"
        self.set_current_date(campaign_id, date)
        self.record_event(campaign_id, "correction",
                          "Calendar set: {} -> {}{}".format(
                              was, date,
                              " ({})".format(reason) if reason else ""))
        return {"date": date, "was": was, "reason": reason}

    def recent_turns(self, campaign_id: int, limit: int = 6) -> List[Dict[str, Any]]:
        """The last few narrated turns, oldest first, as {player_input,
        narration} pairs -- the referee replays these as conversation memory
        so continuity survives the stateless model calls."""
        rows = self.conn.execute(
            "SELECT id, detail_json FROM event WHERE campaign_id=? AND "
            "kind='narration' ORDER BY id DESC LIMIT ?",
            (campaign_id, limit)).fetchall()
        out: List[Dict[str, Any]] = []
        for row in reversed(rows):
            d = json.loads(row["detail_json"] or "{}")
            out.append({"id": row["id"],
                        "player_input": d.get("player_input", ""),
                        "narration": d.get("full", "")})
        return out

    def replace_narration(self, event_id: int, new_text: str) -> bool:
        """Replace a narration event's prose in place (the table veto). The
        rejected text is overwritten so it can never feed a future turn's
        context; the player's input and the event's identity are preserved."""
        row = self.conn.execute(
            "SELECT detail_json FROM event WHERE id=? AND kind='narration'",
            (event_id,)).fetchone()
        if not row:
            return False
        d = json.loads(row["detail_json"] or "{}")
        d["full"] = new_text
        summary = new_text[:200] + ("..." if len(new_text) > 200 else "")
        self.conn.execute("UPDATE event SET detail_json=?, summary=? WHERE id=?",
                          (json.dumps(d), summary, event_id))
        self.conn.commit()
        return True

    # ---- users (player accounts) ---------------------------------------

    def create_user(self, username: str, password: str) -> Optional[int]:
        """Create an account. Returns the user id, or None if the name is taken."""
        username = (username or "").strip()
        if not username or not str(password).strip():
            return None
        salt, ph = user_hash_password(password)
        try:
            uid = _insert(self.conn, "user", {
                "username": username, "pw_salt": salt, "pw_hash": ph})
        except sqlite3.IntegrityError:
            return None
        self.conn.commit()
        return uid

    def verify_user(self, username: str, password: str) -> Optional[sqlite3.Row]:
        """Constant-time password check. Returns the user row or None."""
        row = self.conn.execute(
            "SELECT * FROM user WHERE username=? COLLATE NOCASE",
            ((username or "").strip(),)).fetchone()
        if not row:
            return None
        _, ph = user_hash_password(password, row["pw_salt"])
        return row if hmac.compare_digest(ph, row["pw_hash"]) else None

    def get_user(self, user_id: int) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM user WHERE id=?",
                                 (user_id,)).fetchone()

    # ---- campaigns -----------------------------------------------------

    def create_campaign(self, name: str,
                        universe: str = "Official Charted Space",
                        current_date: Optional[str] = None,
                        password: Optional[str] = None,
                        owner_user_id: Optional[int] = None) -> int:
        cid = _insert(self.conn, "campaign", {
            "name": name, "universe": universe, "current_date": current_date,
            "password_hash": hash_password(password),
            "owner_user_id": owner_user_id})
        self.record_event(cid, "campaign", "Campaign created: {}".format(name))
        return cid

    def campaign_owner(self, campaign_id: int) -> Optional[int]:
        row = self.conn.execute(
            "SELECT owner_user_id FROM campaign WHERE id=?",
            (campaign_id,)).fetchone()
        return row["owner_user_id"] if row else None

    # ---- the receipt tape ----------------------------------------------

    def write_receipt(self, campaign_id: int, tool: str, args: Any,
                      result: Any, author: str = "engine",
                      summary: str = "", source: str = "referee") -> Dict[str, Any]:
        """Stamp one numbered receipt. Called BEFORE a mechanical result is
        returned, so no narration can outrun the tape."""
        def _trim(o, limit=2000):
            try:
                s = json.dumps(o, default=str)
            except Exception:
                s = str(o)
            return s[:limit]

        # Both the signed token and its magnitude: the validator has to match
        # "-48000" on the tape against "Cr48,000" in the prose.
        found = re.findall(r"-?\d+", _trim(result, 4000))
        nums = sorted(set(found) | {n.lstrip("-") for n in found})
        row = self.conn.execute(
            "SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM receipt WHERE campaign_id=?",
            (campaign_id,)).fetchone()
        seq = int(row["n"])
        self.conn.execute(
            "INSERT INTO receipt(campaign_id, seq, tool, author, source, "
            "args_json, result_json, numbers, summary) VALUES (?,?,?,?,?,?,?,?,?)",
            (campaign_id, seq, tool, author, source, _trim(args), _trim(result),
             " ".join(nums[:200]), summary[:300]))
        self.conn.commit()
        return {"seq": seq, "tool": tool, "author": author, "source": source}

    def receipts(self, campaign_id: int, limit: int = 50,
                 since_seq: int = 0) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM receipt WHERE campaign_id=? AND seq>? "
            "ORDER BY seq DESC LIMIT ?",
            (campaign_id, int(since_seq), int(limit))).fetchall()

    def receipt_gaps(self, campaign_id: int) -> List[int]:
        """Missing sequence numbers -- evidence that something was deleted."""
        seqs = [r["seq"] for r in self.conn.execute(
            "SELECT seq FROM receipt WHERE campaign_id=? ORDER BY seq",
            (campaign_id,))]
        if not seqs:
            return []
        return [n for n in range(1, seqs[-1] + 1) if n not in set(seqs)]

    def hex_from_location(self, campaign_id: int,
                          text: Optional[str]) -> Optional[str]:
        """Best effort: where does this free-text location actually sit?

        Locations are prose ('Luna (1914)', 'docked at Kaupang', 'Luna'), so a
        bare hex match is not enough -- a referee who writes 'Luna Highport'
        must not make the party vanish off the map. Try the hex, then the
        longest campaign world name mentioned in the text.
        """
        if not text:
            return None
        m = re.search(r"\b(\d{4})\b", str(text))
        if m:
            return m.group(1)
        low = str(text).lower()
        best_name, best_hex = "", None
        for w in self.list_worlds(campaign_id):
            n = (w["name"] or "").strip().lower()
            if n and len(n) > len(best_name) and re.search(
                    r"\b{}\b".format(re.escape(n)), low):
                best_name, best_hex = n, w["hex"]
        return best_hex

    def get_campaign(self, campaign_id: int) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM campaign WHERE id=?",
                                 (campaign_id,)).fetchone()

    def list_campaigns(self) -> List[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM campaign ORDER BY id").fetchall()

    # ---- per-campaign passwords ----------------------------------------

    def campaign_password_hash(self, campaign_id: int) -> Optional[str]:
        """The stored hash, or None if the campaign is open (no password)."""
        row = self.conn.execute(
            "SELECT password_hash FROM campaign WHERE id=?",
            (campaign_id,)).fetchone()
        return row["password_hash"] if row else None

    def campaign_is_locked(self, campaign_id: int) -> bool:
        return bool(self.campaign_password_hash(campaign_id))

    def check_campaign_password(self, campaign_id: int, password: str) -> bool:
        """True if the campaign is open, or the password matches its hash."""
        stored = self.campaign_password_hash(campaign_id)
        if not stored:
            return True
        return hash_password(password) == stored

    def set_campaign_password(self, campaign_id: int,
                              password: Optional[str]) -> None:
        """Set (or clear, with a blank password) a campaign's password."""
        self.conn.execute("UPDATE campaign SET password_hash=? WHERE id=?",
                          (hash_password(password), campaign_id))
        self.conn.commit()

    def set_current_date(self, campaign_id: int, date: str):
        self.conn.execute("UPDATE campaign SET current_date=? WHERE id=?",
                          (date, campaign_id))
        self.conn.commit()

    # ---- worlds / sector import ----------------------------------------

    def import_sector_file(self, campaign_id: int, path: str,
                           source: str = "official") -> int:
        """Import a T5 sector file into the world table. Returns worlds added."""
        records = t5.parse_file(path)
        n = 0
        for rec in records:
            row = world_row(rec, source)
            row["campaign_id"] = campaign_id
            self.conn.execute(
                "INSERT OR REPLACE INTO world "
                "(campaign_id, sector, ss, hex, name, uwp, bases, remarks, zone,"
                " pbg, allegiance, stars, ix, ex, cx, nobility, w, ru, source) "
                "VALUES (:campaign_id,:sector,:ss,:hex,:name,:uwp,:bases,:remarks,"
                ":zone,:pbg,:allegiance,:stars,:ix,:ex,:cx,:nobility,:w,:ru,:source)",
                row)
            n += 1
        self.conn.commit()
        sector = records[0].sector if records else "?"
        self.record_event(campaign_id, "import",
                          "Imported {} worlds from sector {}".format(n, sector),
                          {"path": path, "count": n})
        return n

    def get_world(self, campaign_id: int, sector: str, hex: str):
        return self.conn.execute(
            "SELECT * FROM world WHERE campaign_id=? AND sector=? AND hex=?",
            (campaign_id, sector, hex)).fetchone()

    def find_world(self, campaign_id: int, name: str):
        return self.conn.execute(
            "SELECT * FROM world WHERE campaign_id=? AND name=? LIMIT 1",
            (campaign_id, name)).fetchone()

    def find_world_by_hex(self, campaign_id: int, hex: str):
        return self.conn.execute(
            "SELECT * FROM world WHERE campaign_id=? AND hex=? LIMIT 1",
            (campaign_id, hex)).fetchone()

    def add_world(self, campaign_id: int, sector: str, hex: str, name: str,
                  uwp: str = "", bases: str = "", remarks: str = "",
                  zone: str = "", pbg: str = "", allegiance: str = "Na",
                  source: str = "generated", notes: str = "") -> int:
        self.conn.execute(
            "INSERT OR REPLACE INTO world (campaign_id, sector, ss, hex, name, uwp,"
            " bases, remarks, zone, pbg, allegiance, source, notes) VALUES "
            "(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (campaign_id, sector, "", hex, name, uwp, bases, remarks, zone, pbg,
             allegiance, source, notes))
        self.conn.commit()
        row = self.conn.execute(
            "SELECT id FROM world WHERE campaign_id=? AND sector=? AND hex=?",
            (campaign_id, sector, hex)).fetchone()
        self.record_event(campaign_id, "world",
                          "Charted {} at {} {}".format(name, sector, hex),
                          {"uwp": uwp})
        return row["id"] if row else None

    def list_worlds(self, campaign_id: int, sector: Optional[str] = None):
        if sector:
            return self.conn.execute(
                "SELECT * FROM world WHERE campaign_id=? AND sector=? ORDER BY hex",
                (campaign_id, sector)).fetchall()
        return self.conn.execute(
            "SELECT * FROM world WHERE campaign_id=? ORDER BY sector, hex",
            (campaign_id,)).fetchall()

    def mark_visited(self, world_id: int):
        row = self.conn.execute("SELECT campaign_id, name FROM world WHERE id=?",
                                (world_id,)).fetchone()
        self.conn.execute("UPDATE world SET visited=1 WHERE id=?", (world_id,))
        self.conn.commit()
        if row:
            self.record_event(row["campaign_id"], "travel",
                              "Visited {}".format(row["name"]))

    # ---- notes & lookups (the living-world memory) ---------------------

    _NOTE_TABLES = {"character", "ship", "world"}

    def append_note(self, table: str, row_id: int, text: str) -> bool:
        """Append a note to a character/ship/world's running history."""
        if table not in self._NOTE_TABLES:
            return False
        row = self.conn.execute(
            "SELECT campaign_id, notes, name FROM {} WHERE id=?".format(table),
            (row_id,)).fetchone()
        if not row:
            return False
        existing = row["notes"] or ""
        merged = (existing + "\n" if existing else "") + "• " + text
        self.conn.execute("UPDATE {} SET notes=? WHERE id=?".format(table),
                          (merged, row_id))
        self.conn.commit()
        self.record_event(row["campaign_id"], "note",
                          "Note on {} {}: {}".format(table, row["name"], text))
        return True

    def remove_note(self, table: str, row_id: int, contains: str):
        """The companion to append_note: drop every note LINE containing
        `contains` (case-insensitive) from a character/ship/world's running
        history. Notes are stored one bullet per line, so this removes whole
        notes, not fragments. Returns (removed_lines, remaining_count), or
        (None, 0) if the table/row is invalid."""
        if table not in self._NOTE_TABLES:
            return None, 0
        row = self.conn.execute(
            "SELECT campaign_id, notes, name FROM {} WHERE id=?".format(table),
            (row_id,)).fetchone()
        if not row:
            return None, 0
        needle = (contains or "").strip().lower()
        lines = (row["notes"] or "").split("\n") if row["notes"] else []
        if not needle:
            return [], len(lines)
        kept, removed = [], []
        for line in lines:
            (removed if needle in line.lower() else kept).append(line)
        if removed:
            self.conn.execute("UPDATE {} SET notes=? WHERE id=?".format(table),
                              ("\n".join(kept), row_id))
            self.conn.commit()
            self.record_event(row["campaign_id"], "note",
                              "Removed {} note(s) from {} {}".format(
                                  len(removed), table, row["name"]))
        return removed, len(kept)

    def find_character_by_name(self, campaign_id: int, name: str):
        return self.conn.execute(
            "SELECT * FROM character WHERE campaign_id=? AND name LIKE ? LIMIT 1",
            (campaign_id, name)).fetchone()

    def find_ship_by_name(self, campaign_id: int, name: str):
        return self.conn.execute(
            "SELECT * FROM ship WHERE campaign_id=? AND name LIKE ? LIMIT 1",
            (campaign_id, name)).fetchone()

    # ---- characters ----------------------------------------------------

    def save_character(self, campaign_id: int, char: Any, is_npc: bool = False,
                       location: Optional[str] = None, notes: str = "",
                       owner_user_id: Optional[int] = None) -> int:
        row = character_row(char, is_npc=is_npc, location=location)
        row["campaign_id"] = campaign_id
        if notes:
            row["notes"] = notes
        if owner_user_id and not is_npc:
            row["owner_user_id"] = owner_user_id
        cid = _insert(self.conn, "character", row)
        self.conn.commit()
        # Keep the queryable skill index in step with the row's skills_json.
        self.set_character_skills(cid, getattr(char, "skills", {}) or {})
        self.record_event(campaign_id,
                          "npc" if is_npc else "character",
                          "Saved {}character {}".format(
                              "NPC " if is_npc else "", row["name"]),
                          {"character_id": cid, "upp": row["upp"]})
        return cid

    def get_character(self, character_id: int):
        return self.conn.execute("SELECT * FROM character WHERE id=?",
                                 (character_id,)).fetchone()

    def list_characters(self, campaign_id: int, include_npcs: bool = True):
        q = ("SELECT character.*, user.username AS owner_username "
             "FROM character LEFT JOIN user ON user.id=character.owner_user_id "
             "WHERE campaign_id=?")
        if not include_npcs:
            q += " AND is_npc=0"
        return self.conn.execute(q + " ORDER BY character.id",
                                 (campaign_id,)).fetchall()

    # ---- character skills, as a queryable index ------------------------
    def set_character_notes(self, character_id: int, text: str) -> bool:
        """Replace a character's notes -- the player's own editor, so the sheet
        stops being a scroll of everything the referee ever appended. Returns
        True if a row was updated."""
        cur = self.conn.execute("UPDATE character SET notes=? WHERE id=?",
                                (text or "", int(character_id)))
        self.conn.commit()
        return cur.rowcount > 0

    def set_character_skills(self, character_id: int, skills: dict) -> None:
        """Replace a character's skill rows to match `skills` ({name: level}).
        Called at every character write, so the index never drifts from the
        skills_json the character carries."""
        self.conn.execute("DELETE FROM character_skill WHERE character_id=?",
                          (character_id,))
        for name, level in (skills or {}).items():
            try:
                lvl = int(level)
            except (TypeError, ValueError):
                continue
            self.conn.execute(
                "INSERT OR REPLACE INTO character_skill"
                "(character_id, skill, level) VALUES (?,?,?)",
                (character_id, str(name), lvl))
        self.conn.commit()

    def character_skills(self, character_id: int) -> dict:
        return {r["skill"]: int(r["level"]) for r in self.conn.execute(
            "SELECT skill, level FROM character_skill WHERE character_id=?",
            (character_id,))}

    def broker_skill(self, character_id: int) -> int:
        """A character's Broker level, from the index -- SQL MAX over any skill
        whose name contains 'broker'. Same result the old json.loads scan gave,
        without parsing a string."""
        row = self.conn.execute(
            "SELECT MAX(level) AS lvl FROM character_skill "
            "WHERE character_id=? AND skill LIKE '%broker%' COLLATE NOCASE",
            (character_id,)).fetchone()
        return int(row["lvl"]) if row and row["lvl"] is not None else 0

    def characters_with_skill(self, campaign_id: int, needle: str,
                              min_level: int = 1):
        """The queryability payoff: who in this campaign has a skill matching
        `needle` at `min_level`+ -- one JOIN, instead of loading and parsing
        every character's skills blob."""
        rows = self.conn.execute(
            "SELECT c.id, c.name, cs.skill, cs.level FROM character_skill cs "
            "JOIN character c ON c.id = cs.character_id "
            "WHERE c.campaign_id=? AND cs.skill LIKE ? COLLATE NOCASE "
            "AND cs.level >= ? ORDER BY cs.level DESC, c.name",
            (campaign_id, "%{}%".format(needle), int(min_level))).fetchall()
        return [{"id": r["id"], "name": r["name"], "skill": r["skill"],
                 "level": int(r["level"])} for r in rows]

    def claim_character(self, character_id: int, user_id: int) -> bool:
        """Attach a legacy/unclaimed PC to an account. Fails if already owned,
        an NPC, or nonexistent."""
        row = self.get_character(character_id)
        if not row or row["is_npc"] or row["owner_user_id"]:
            return False
        self.conn.execute("UPDATE character SET owner_user_id=? WHERE id=?",
                          (user_id, character_id))
        self.conn.commit()
        u = self.get_user(user_id)
        self.record_event(row["campaign_id"], "character",
                          "{} claimed character {}".format(
                              u["username"] if u else "user", row["name"]))
        return True

    def adjust_character_credits(self, character_id: int, delta: int):
        """Apply a +/- change to a character's personal credits. The sheet is
        the truth: this column, not prose notes, is where money lives. Returns
        the new balance (negatives allowed -- debt is very Traveller)."""
        row = self.get_character(character_id)
        if not row:
            return None
        new = int(row["credits"] or 0) + int(delta)
        self.conn.execute("UPDATE character SET credits=? WHERE id=?",
                          (new, character_id))
        self.conn.commit()
        return new

    def update_character_status(self, character_id: int, status: str,
                                alive: Optional[bool] = None):
        if alive is None:
            self.conn.execute("UPDATE character SET status=? WHERE id=?",
                              (status, character_id))
        else:
            self.conn.execute(
                "UPDATE character SET status=?, alive=? WHERE id=?",
                (status, 1 if alive else 0, character_id))
        self.conn.commit()

    def delete_character(self, character_id: int) -> bool:
        row = self.conn.execute(
            "SELECT campaign_id, name FROM character WHERE id=?",
            (character_id,)).fetchone()
        if not row:
            return False
        self.conn.execute("DELETE FROM character WHERE id=?", (character_id,))
        self.conn.commit()
        self.record_event(row["campaign_id"], "character",
                          "Removed character {}".format(row["name"]))
        return True

    # ---- ships ---------------------------------------------------------

    def save_ship(self, campaign_id: int, ship: Any, name: Optional[str] = None,
                  armor: int = 0, fuel: int = 0,
                  location: Optional[str] = None, notes: str = "") -> int:
        row = ship_row(ship, name=name, armor=armor, fuel=fuel, location=location)
        row["campaign_id"] = campaign_id
        if not row.get("fuel"):          # out of the yard with full tanks
            row["fuel"] = row.get("fuel_capacity") or 0
        if notes:
            row["notes"] = notes
        sid = _insert(self.conn, "ship", row)
        self.conn.commit()
        self.record_event(campaign_id, "ship",
                          "Commissioned ship {} ({})".format(
                              row["name"], row["ship_class"]),
                          {"ship_id": sid})
        return sid

    def delete_ship(self, ship_id: int) -> bool:
        row = self.conn.execute(
            "SELECT campaign_id, name FROM ship WHERE id=?", (ship_id,)).fetchone()
        if not row:
            return False
        self.conn.execute("DELETE FROM ship WHERE id=?", (ship_id,))
        self.conn.commit()
        self.record_event(row["campaign_id"], "ship",
                          "Decommissioned ship {}".format(row["name"]))
        return True

    def get_ship(self, ship_id: int):
        return self.conn.execute("SELECT * FROM ship WHERE id=?",
                                 (ship_id,)).fetchone()

    def list_ships(self, campaign_id: int):
        return self.conn.execute(
            "SELECT * FROM ship WHERE campaign_id=? ORDER BY id",
            (campaign_id,)).fetchall()

    # ---- cargo + ledger ------------------------------------------------

    def add_cargo_lot(self, campaign_id: int, good: str, tons: int,
                      buy_price_per_ton: int, ship_id: Optional[int] = None,
                      origin_hex: Optional[str] = None) -> int:
        lid = _insert(self.conn, "cargo_lot", {
            "campaign_id": campaign_id, "ship_id": ship_id, "good": good,
            "tons": tons, "buy_price_per_ton": buy_price_per_ton,
            "origin_hex": origin_hex})
        self.conn.commit()
        self.record_event(campaign_id, "trade",
                          "Bought {}t {} @ Cr{:,}/t".format(
                              tons, good, buy_price_per_ton),
                          {"cargo_lot_id": lid})
        return lid

    def list_cargo(self, campaign_id: int, held_only: bool = True):
        q = "SELECT * FROM cargo_lot WHERE campaign_id=?"
        if held_only:
            q += " AND status='held'"
        return self.conn.execute(q + " ORDER BY id", (campaign_id,)).fetchall()

    def mark_cargo_sold(self, lot_id: int):
        row = self.conn.execute("SELECT * FROM cargo_lot WHERE id=?",
                                (lot_id,)).fetchone()
        if not row:
            return None
        self.conn.execute("UPDATE cargo_lot SET status='sold' WHERE id=?", (lot_id,))
        self.conn.commit()
        return row

    def record_transaction(self, campaign_id: int, amount: int, kind: str,
                           description: str = "", ref_table: Optional[str] = None,
                           ref_id: Optional[int] = None) -> int:
        tid = _insert(self.conn, "ledger", {
            "campaign_id": campaign_id, "amount": amount, "kind": kind,
            "description": description, "ref_table": ref_table, "ref_id": ref_id})
        self.conn.commit()
        self.record_event(campaign_id, "ledger",
                          "{} Cr{:,}: {}".format(
                              "+" if amount >= 0 else "-", abs(amount),
                              description or kind),
                          {"amount": amount, "kind": kind})
        return tid

    def balance(self, campaign_id: int) -> int:
        r = self.conn.execute(
            "SELECT COALESCE(SUM(amount),0) AS b FROM ledger WHERE campaign_id=?",
            (campaign_id,)).fetchone()
        return r["b"]
