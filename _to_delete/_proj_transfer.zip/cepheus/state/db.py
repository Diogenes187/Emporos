"""db.py -- SQLite connection and schema management for campaign state.

A single SQLite file is the campaign's source of truth. This module handles
connecting, initializing the schema, and giving callers a row-dict cursor.
"""
from __future__ import annotations

import os
import sqlite3
from typing import Optional

_SCHEMA = os.path.join(os.path.dirname(__file__), "schema.sql")


def connect(path: str) -> sqlite3.Connection:
    """Open (creating if needed) a campaign database and ensure the schema."""
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    if path != ":memory:":
        # WAL: readers never block behind a writer, writers queue politely.
        # This is what lets many tables play at once on one database file.
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    init_schema(conn)
    return conn


def connect_memory() -> sqlite3.Connection:
    """An in-memory database (tests / ephemeral use)."""
    return connect(":memory:")


def init_schema(conn: sqlite3.Connection) -> None:
    with open(_SCHEMA, encoding="utf-8") as f:
        conn.executescript(f.read())
    _migrate(conn)
    _seed_catalogues(conn)
    conn.commit()


def _seed_catalogues(conn: sqlite3.Connection) -> None:
    """Fill the read-only reference tables from the authored SRD data, once.

    The catalogue lives in engine/data/*.json (git-authored, book-audited) and
    is parsed into the engine's in-memory tables at import. Here we copy that
    same data into real DB tables so the market is queryable in SQL alongside
    campaign state -- the JSON stays the source of truth, and test_catalog pins
    the table to it so the two cannot drift. Guarded by a row check, so this is
    a no-op on every connect after the first."""
    if conn.execute("SELECT 1 FROM trade_good LIMIT 1").fetchone():
        return
    from engine import trade                       # lazy: no import cycle
    for g in trade.TRADE_GOODS.values():
        conn.execute(
            "INSERT OR IGNORE INTO trade_good"
            "(d66, name, base_price, tons_expr, illegal) VALUES (?,?,?,?,?)",
            (g.d66, g.name,
             None if g.base_price is None else int(g.base_price),
             g.tons_expr, 1 if g.illegal else 0))
        for side, dms in (("purchase", g.purchase_dms), ("sale", g.sale_dms)):
            for code, dm in (dms or {}).items():
                conn.execute(
                    "INSERT OR IGNORE INTO trade_good_dm"
                    "(d66, code, side, dm) VALUES (?,?,?,?)",
                    (g.d66, code, side, int(dm)))


def _migrate(conn: sqlite3.Connection) -> None:
    """Idempotent, additive migrations for databases created before a column
    existed. CREATE TABLE IF NOT EXISTS never alters an existing table, so any
    new column has to be added here for already-deployed campaign DBs."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(campaign)")}
    if "password_hash" not in cols:
        conn.execute("ALTER TABLE campaign ADD COLUMN password_hash TEXT")
    if "owner_user_id" not in cols:
        conn.execute("ALTER TABLE campaign ADD COLUMN owner_user_id INTEGER "
                     "REFERENCES user(id)")
    if "start_hex" not in cols:
        conn.execute("ALTER TABLE campaign ADD COLUMN start_hex TEXT")
        conn.execute("ALTER TABLE campaign ADD COLUMN start_world TEXT")
    if "scenario_notes" not in cols:
        conn.execute("ALTER TABLE campaign ADD COLUMN scenario_notes TEXT "
                     "DEFAULT ''")
        conn.execute("ALTER TABLE campaign ADD COLUMN scenario_hook TEXT "
                     "DEFAULT ''")
    ccols = {r["name"] for r in conn.execute("PRAGMA table_info(character)")}
    if "owner_user_id" not in ccols:
        conn.execute("ALTER TABLE character ADD COLUMN owner_user_id INTEGER "
                     "REFERENCES user(id)")
    if "damage" not in ccols:
        conn.execute("ALTER TABLE character ADD COLUMN damage INTEGER "
                     "NOT NULL DEFAULT 0")
    ecols = {r["name"] for r in conn.execute("PRAGMA table_info(event)")}
    if "struck" not in ecols:
        conn.execute("ALTER TABLE event ADD COLUMN struck INTEGER NOT NULL "
                     "DEFAULT 0")
        conn.execute("ALTER TABLE event ADD COLUMN struck_reason TEXT DEFAULT ''")
    rcols = {r["name"] for r in conn.execute("PRAGMA table_info(receipt)")}
    if rcols and "struck" not in rcols:
        conn.execute("ALTER TABLE receipt ADD COLUMN struck INTEGER NOT NULL "
                     "DEFAULT 0")
        conn.execute("ALTER TABLE receipt ADD COLUMN struck_reason TEXT "
                     "DEFAULT ''")
    if rcols and "source" not in rcols:
        conn.execute("ALTER TABLE receipt ADD COLUMN source TEXT NOT NULL "
                     "DEFAULT 'referee'")
    scols = {r["name"] for r in conn.execute("PRAGMA table_info(ship)")}
    if "fuel_capacity" not in scols:
        conn.execute("ALTER TABLE ship ADD COLUMN fuel_capacity INTEGER "
                     "DEFAULT 0")
        conn.execute("ALTER TABLE ship ADD COLUMN fuel_refined INTEGER "
                     "DEFAULT 1")
        # Existing ships were built before fuel was tracked: give every one
        # its class tankage, tanks full. Nobody gets stranded by an upgrade.
        try:
            from engine.travel import fuel_capacity as _cap
            for row in conn.execute(
                    "SELECT id, ship_class, tonnage, jump, fuel FROM ship"):
                cap = _cap(row["ship_class"], row["tonnage"], row["jump"])
                conn.execute(
                    "UPDATE ship SET fuel_capacity=?, fuel=? WHERE id=?",
                    (cap, cap if not row["fuel"] else min(row["fuel"], cap),
                     row["id"]))
        except Exception:
            pass

    # Backfill the character_skill index from skills_json for characters made
    # before the index existed. One-time: guarded by the index being empty, so
    # it runs once on an upgraded DB and never again (new characters get their
    # rows at write time via repo.set_character_skills).
    try:
        indexed = conn.execute(
            "SELECT 1 FROM character_skill LIMIT 1").fetchone()
        have_chars = conn.execute("SELECT 1 FROM character LIMIT 1").fetchone()
        if have_chars and not indexed:
            import json as _json
            for r in conn.execute("SELECT id, skills_json FROM character"):
                try:
                    sk = _json.loads(r["skills_json"] or "{}")
                except Exception:
                    sk = {}
                for name, level in sk.items():
                    try:
                        lvl = int(level)
                    except (TypeError, ValueError):
                        continue
                    conn.execute(
                        "INSERT OR IGNORE INTO character_skill"
                        "(character_id, skill, level) VALUES (?,?,?)",
                        (r["id"], str(name), lvl))
    except Exception:
        pass
